#include <jni.h>
#include <string>

// ARM64 JNI bridge scaffold for future Play! integration.
// This is NOT the Play! emulator and cannot boot PS2 games by itself.
extern "C" JNIEXPORT jstring JNICALL
Java_com_matrix_gaming_Ps2NativeBridge_nativeStatus(JNIEnv* env, jclass) {
    return env->NewStringUTF("ARM64 bridge loaded; Play! core is not linked yet");
}
