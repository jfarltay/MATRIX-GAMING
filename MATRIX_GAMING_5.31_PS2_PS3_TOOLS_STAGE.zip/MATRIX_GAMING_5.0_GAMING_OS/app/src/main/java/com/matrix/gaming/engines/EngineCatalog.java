package com.matrix.gaming.engines;

import java.util.*;

/** Central inventory. Status values deliberately distinguish working code from planned integrations. */
public final class EngineCatalog {
    private EngineCatalog() {}
    public enum Status { IMPLEMENTED, PARTIAL, INTEGRATION_REQUIRED, NOT_IMPLEMENTED }
    public static final class Entry {
        public final String id, title, detail; public final Status status;
        Entry(String i, String t, Status s, String d) { id=i; title=t; status=s; detail=d; }
    }
    public static List<Entry> all() {
        List<Entry> e = new ArrayList<>();
        e.add(new Entry("iso", "ISO File Engine", Status.IMPLEMENTED, "Split, merge, ISO9660 inspection and CRC32"));
        e.add(new Entry("sha256", "SHA-256 Engine", Status.IMPLEMENTED, "Streaming SHA-256 checksums"));
        e.add(new Entry("zip", "ZIP Engine", Status.IMPLEMENTED, "Streaming ZIP create/extract with path traversal protection"));
        e.add(new Entry("opl-folders", "OPL Folder Export", Status.PARTIAL, "ISO copy to CD/DVD folders exists; device testing remains"));
        e.add(new Entry("opl-ul", "OPL USBExtreme UL", Status.INTEGRATION_REQUIRED, "UL segments and ul.cfg writer/reader still required"));
        e.add(new Entry("ps2-armsx2", "ARMSX2 Android ARM64", Status.INTEGRATION_REQUIRED, "Open-source PCSX2-based Android emulator; native core, JNI, graphics surface, audio and input still need integration"));
        e.add(new Entry("ps2-armsx2-libretro", "ARMSX2 Libretro Core", Status.INTEGRATION_REQUIRED, "Alternative frontend path through Libretro; requires the matching core, resources, BIOS and tested RetroArch bridge"));
        e.add(new Entry("ps2-play", "Play! PS2", Status.INTEGRATION_REQUIRED, "Independent open-source PS2 emulator; Android core integration and game compatibility tests required"));
        e.add(new Entry("ps2-nethersx2", "NetherSX2", Status.INTEGRATION_REQUIRED, "External Android emulator option; do not redistribute its APK or claim it is embedded"));
        e.add(new Entry("ps2-nethersx2-classic", "NetherSX2 Classic 3668", Status.INTEGRATION_REQUIRED, "Legacy external build option; separate compatibility profile, not a second independent emulator core"));
        e.add(new Entry("ps2-aethersx2", "AetherSX2 (legacy)", Status.INTEGRATION_REQUIRED, "Legacy external emulator option; not embedded and not a recommended new integration base"));
        e.add(new Entry("ps2-pcsx2-desktop", "PCSX2 Desktop", Status.NOT_IMPLEMENTED, "Desktop emulator project; not an Android-ready in-process core for this app"));
        e.add(new Entry("chd-cso-zso", "CHD/CSO/ZSO codecs", Status.INTEGRATION_REQUIRED, "Use compatible codec libraries; extension renaming is not conversion"));
        e.add(new Entry("ps3-iso", "PS3 ISO File Engine", Status.PARTIAL, "Streaming ISO split/merge and ISO9660 inspection are available; PS3-specific filesystem extraction and folder-to-ISO authoring still require dedicated tested modules"));
        e.add(new Entry("ps3-pkg", "PS3 PKG Engine", Status.INTEGRATION_REQUIRED, "PKG metadata parser, package verifier and safe extractor are not yet integrated"));
        e.add(new Entry("ps3-folder", "PS3 Game Folder Tools", Status.PARTIAL, "Folder inventory and file management; game-specific validation and conversion still required"));
        e.add(new Entry("ps3-sfo", "PS3 PARAM.SFO Reader", Status.INTEGRATION_REQUIRED, "SFO parser and metadata editor require implementation and test fixtures"));
        e.add(new Entry("ps3-self", "PS3 SELF/ELF Inspector", Status.INTEGRATION_REQUIRED, "Read-only format identification and metadata inspection planned; no executable modification"));
        e.add(new Entry("ps3-update", "PS3 Update Package Tools", Status.INTEGRATION_REQUIRED, "Update package identification and integrity verification planned"));
        e.add(new Entry("game-converter", "Game Format Converter", Status.INTEGRATION_REQUIRED, "Format conversion must use real codec libraries; extension renaming is never conversion"));
        e.add(new Entry("bin-cue", "BIN/CUE Engine", Status.NOT_IMPLEMENTED, "Disc layout parser and tested conversion path required"));
        e.add(new Entry("ecm", "ECM Engine", Status.NOT_IMPLEMENTED, "ECM codec integration required"));
        return Collections.unmodifiableList(e);
    }
}
