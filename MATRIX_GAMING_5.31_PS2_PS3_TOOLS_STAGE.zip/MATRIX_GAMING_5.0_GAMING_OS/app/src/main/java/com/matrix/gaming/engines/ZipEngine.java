package com.matrix.gaming.engines;

import java.io.*;
import java.util.zip.*;

/** ZIP create/extract engine with streaming I/O and Zip-Slip protection. */
public final class ZipEngine {
    private ZipEngine() {}
    public interface Progress { void onProgress(long done, long total); }
    public static final class Result {
        public final boolean success; public final String message; public final long bytes;
        Result(boolean ok, String msg, long count) { success=ok; message=msg; bytes=count; }
    }

    public static Result create(File source, File zipFile, Progress progress) {
        if (source == null || !source.exists() || zipFile == null)
            return new Result(false, "Invalid source or output", 0);
        File base = source.isDirectory() ? source : source.getParentFile();
        long total = source.isFile() ? source.length() : directoryBytes(source);
        long[] done = {0}; byte[] buffer = new byte[64 * 1024];
        try (ZipOutputStream zip = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(zipFile)))) {
            if (source.isDirectory()) {
                String root = source.getName();
                if (!addDirectory(source, root, zip, buffer, done, total, progress))
                    return new Result(false, "Could not add directory", done[0]);
            } else {
                addFile(source, source.getName(), zip, buffer, done, total, progress);
            }
            zip.finish();
            return new Result(true, "ZIP archive created", done[0]);
        } catch (IOException e) {
            // Do not leave a partial archive looking successful.
            //noinspection ResultOfMethodCallIgnored
            zipFile.delete();
            return new Result(false, e.getMessage() == null ? e.toString() : e.getMessage(), done[0]);
        }
    }

    private static boolean addDirectory(File dir, String path, ZipOutputStream zip, byte[] buffer,
                                        long[] done, long total, Progress progress) throws IOException {
        File[] children = dir.listFiles();
        if (children == null) return false;
        if (children.length == 0) { zip.putNextEntry(new ZipEntry(path + "/")); zip.closeEntry(); }
        for (File child : children) {
            String childPath = path + "/" + child.getName();
            if (child.isDirectory()) {
                if (!addDirectory(child, childPath, zip, buffer, done, total, progress)) return false;
            } else addFile(child, childPath, zip, buffer, done, total, progress);
        }
        return true;
    }

    private static void addFile(File file, String path, ZipOutputStream zip, byte[] buffer,
                                long[] done, long total, Progress progress) throws IOException {
        zip.putNextEntry(new ZipEntry(path));
        try (InputStream in = new BufferedInputStream(new FileInputStream(file))) {
            int n; while ((n = in.read(buffer)) != -1) {
                zip.write(buffer, 0, n); done[0] += n;
                if (progress != null) progress.onProgress(done[0], total);
            }
        }
        zip.closeEntry();
    }

    public static Result extract(File zipFile, File destination, Progress progress) {
        if (zipFile == null || !zipFile.isFile() || destination == null)
            return new Result(false, "Invalid archive or destination", 0);
        if (!destination.exists() && !destination.mkdirs())
            return new Result(false, "Cannot create destination", 0);
        long done = 0; byte[] buffer = new byte[64 * 1024];
        try {
            String destinationCanonical = destination.getCanonicalPath();
            String root = destinationCanonical + File.separator;
            try (ZipInputStream zip = new ZipInputStream(new BufferedInputStream(new FileInputStream(zipFile)))) {
            ZipEntry entry;
            while ((entry = zip.getNextEntry()) != null) {
                File out = new File(destination, entry.getName());
                String canonical = out.getCanonicalPath();
                if (!canonical.equals(destinationCanonical) && !canonical.startsWith(root))
                    throw new IOException("Unsafe ZIP entry path: " + entry.getName());
                if (entry.isDirectory()) {
                    if (!out.isDirectory() && !out.mkdirs()) throw new IOException("Cannot create directory");
                } else {
                    File parent = out.getParentFile();
                    if (parent != null && !parent.isDirectory() && !parent.mkdirs())
                        throw new IOException("Cannot create output folder");
                    try (OutputStream os = new BufferedOutputStream(new FileOutputStream(out))) {
                        int n; while ((n = zip.read(buffer)) != -1) { os.write(buffer, 0, n); done += n;
                            if (progress != null) progress.onProgress(done, -1); }
                    }
                }
                zip.closeEntry();
            }
            return new Result(true, "ZIP archive extracted", done);
            }
        } catch (IOException e) {
            return new Result(false, e.getMessage() == null ? e.toString() : e.getMessage(), done);
        }
    }

    private static long directoryBytes(File f) {
        if (f.isFile()) return f.length();
        File[] children = f.listFiles(); if (children == null) return 0;
        long total = 0; for (File c : children) total += directoryBytes(c); return total;
    }
}
