package com.matrix.gaming;

/** Optional JNI status bridge. Does not emulate PS2 hardware. */
public final class Ps2NativeBridge {
    private static boolean loaded;
    static { try { System.loadLibrary("matrix_ps2_bridge"); loaded = true; } catch (UnsatisfiedLinkError ignored) { loaded = false; } }
    private Ps2NativeBridge() {}
    public static boolean isLoaded() { return loaded; }
    public static String status() { return loaded ? nativeStatus() : "ARM64 bridge unavailable; native build required"; }
    private static native String nativeStatus();
}
