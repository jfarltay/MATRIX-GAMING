package com.matrix.gaming.engines;

import java.io.*;
import java.util.*;
import java.util.zip.CRC32;

/** Real streaming file operations for disc images. Does not emulate or transcode formats. */
public final class IsoFileEngine {
    private IsoFileEngine() {}
    public static final long DEFAULT_PART_SIZE = 1024L * 1024L * 1024L;
    public static final class Result {
        public final boolean success; public final String message; public final long bytes;
        Result(boolean ok, String msg, long count) { success=ok; message=msg; bytes=count; }
    }
    public interface Progress { void onProgress(long done, long total); }
    private static void progress(Progress p,long d,long t){if(p!=null)p.onProgress(d,t);}

    public static Result split(File input, File outputDir, long partSize, Progress listener) {
        if(input==null||!input.isFile()||partSize<1024*1024) return new Result(false,"Invalid input or part size",0);
        if(!outputDir.exists()&&!outputDir.mkdirs()) return new Result(false,"Cannot create output directory",0);
        long total=input.length(),done=0; int index=0; byte[] buf=new byte[1024*1024];
        try(InputStream in=new BufferedInputStream(new FileInputStream(input))){
            while(done<total){ File part=new File(outputDir,input.getName()+String.format(Locale.US,".%03d",index++));
                try(OutputStream out=new BufferedOutputStream(new FileOutputStream(part))){long left=Math.min(partSize,total-done);while(left>0){int n=in.read(buf,0,(int)Math.min(buf.length,left));if(n<0)throw new EOFException("Unexpected end of source");out.write(buf,0,n);left-=n;done+=n;progress(listener,done,total);}}
            }
            return new Result(true,"Split into "+index+" parts",done);
        }catch(IOException e){return new Result(false,e.getMessage(),done);}
    }

    public static Result merge(List<File> parts, File output, Progress listener) {
        if(parts==null||parts.isEmpty()||output==null)return new Result(false,"No parts selected",0);
        ArrayList<File> ordered=new ArrayList<>(parts); ordered.sort(Comparator.comparing(File::getName));
        long total=0;for(File f:ordered){if(f==null||!f.isFile())return new Result(false,"Missing part",total);total+=f.length();}
        long done=0;byte[] buf=new byte[1024*1024];
        try(OutputStream out=new BufferedOutputStream(new FileOutputStream(output))){
            for(File f:ordered)try(InputStream in=new BufferedInputStream(new FileInputStream(f))){int n;while((n=in.read(buf))!=-1){out.write(buf,0,n);done+=n;progress(listener,done,total);}}
            return new Result(true,"Merged "+ordered.size()+" parts",done);
        }catch(IOException e){output.delete();return new Result(false,e.getMessage(),done);}
    }

    /** Checks ISO9660 primary volume descriptor at sector 16 (2048-byte sectors). */
    public static Result inspectIso9660(File file) {
        if(file==null||!file.isFile())return new Result(false,"File not found",0);
        if(file.length()<17L*2048L)return new Result(false,"File is too small for an ISO9660 descriptor",file.length());
        byte[] pvd=new byte[7];
        try(RandomAccessFile raf=new RandomAccessFile(file,"r")){raf.seek(16L*2048L);raf.readFully(pvd);
            boolean valid=pvd[0]==1&&pvd[1]=='C'&&pvd[2]=='D'&&pvd[3]=='0'&&pvd[4]=='0'&&pvd[5]=='1'&&pvd[6]==1;
            return new Result(valid,valid?"ISO9660 primary volume descriptor found":"ISO9660 PVD signature not found",file.length());
        }catch(IOException e){return new Result(false,e.getMessage(),0);}
    }

    public static String crc32(File file, Progress listener) throws IOException {
        CRC32 crc=new CRC32();long done=0,total=file.length();byte[] buf=new byte[1024*1024];
        try(InputStream in=new BufferedInputStream(new FileInputStream(file))){int n;while((n=in.read(buf))!=-1){crc.update(buf,0,n);done+=n;progress(listener,done,total);}}
        return String.format(Locale.US,"%08X",crc.getValue());
    }
}
