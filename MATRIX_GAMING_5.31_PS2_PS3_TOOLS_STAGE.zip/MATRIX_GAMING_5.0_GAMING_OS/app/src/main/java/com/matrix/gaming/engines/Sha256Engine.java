package com.matrix.gaming.engines;

import java.io.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Locale;

/** Streaming SHA-256 engine. Never modifies the input stream or source file. */
public final class Sha256Engine {
    private Sha256Engine() {}
    public interface Progress { void onProgress(long done, long total); }

    public static String digest(InputStream input, long totalBytes, Progress progress)
            throws IOException, NoSuchAlgorithmException {
        if (input == null) throw new IllegalArgumentException("input is null");
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] buffer = new byte[1024 * 1024];
        long done = 0;
        int n;
        while ((n = input.read(buffer)) != -1) {
            md.update(buffer, 0, n);
            done += n;
            if (progress != null) progress.onProgress(done, totalBytes);
        }
        byte[] hash = md.digest();
        StringBuilder out = new StringBuilder(hash.length * 2);
        for (byte b : hash) out.append(String.format(Locale.ROOT, "%02x", b & 0xff));
        return out.toString();
    }

    public static String digest(File file, Progress progress)
            throws IOException, NoSuchAlgorithmException {
        if (file == null || !file.isFile()) throw new FileNotFoundException("Source file not found");
        try (InputStream in = new BufferedInputStream(new FileInputStream(file))) {
            return digest(in, file.length(), progress);
        }
    }
}
