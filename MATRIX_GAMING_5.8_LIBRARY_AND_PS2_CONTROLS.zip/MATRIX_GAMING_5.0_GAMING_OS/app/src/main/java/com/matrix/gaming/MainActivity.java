package com.matrix.gaming;

import android.app.*;
import android.os.*;
import android.app.ActivityManager;
import android.content.*;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.database.Cursor;
import android.os.StatFs;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.view.animation.*;
import android.widget.*;
import android.media.MediaPlayer;
import android.media.AudioManager;
import android.media.ToneGenerator;
import java.util.*;

public class MainActivity extends Activity {
  int blue=Color.rgb(0,155,255), red=Color.rgb(255,45,75); LinearLayout page; String lang="ar";
  MediaPlayer musicPlayer; ToneGenerator clickTone;
  boolean musicEnabled=true, clickEnabled=true; int musicVolume=65; int musicTrack=0;
  String[] codes={"ar","en","fr","es","de","it","pt","ru","tr","zh","ja","ko","hi","id","ms","th","vi","nl","pl","uk","fa","ur","bn","sw"};
  String[] flags={"🇮🇶","🇬🇧","🇫🇷","🇪🇸","🇩🇪","🇮🇹","🇵🇹","🇷🇺","🇹🇷","🇨🇳","🇯🇵","🇰🇷","🇮🇳","🇮🇩","🇲🇾","🇹🇭","🇻🇳","🇳🇱","🇵🇱","🇺🇦","🇮🇷","🇵🇰","🇧🇩","🇰🇪"};
  String[] languageNames={"العربية","English","Français","Español","Deutsch","Italiano","Português","Русский","Türkçe","中文","日本語","한국어","हिन्दी","Bahasa Indonesia","Bahasa Melayu","ไทย","Tiếng Việt","Nederlands","Polski","Українська","فارسی","اردو","বাংলা","Kiswahili"};
  HashMap<String,String[]> tr=new HashMap<>();
  void initTranslations(){
    tr.put("ar",new String[]{"الرئيسية","مركز PS2","اختبار التوافق","مكتبة الألعاب","المفضلة","مركز الصور","مركز الفيديو","الأدوات المتقدمة","إدارة الملفات","الإعدادات","اختر اللغة","عالم MATRIX بين يديك","اختبار مواصفات الهاتف","رجوع","إغلاق","اللغة"});
    tr.put("en",new String[]{"HOME","PS2 CENTER","COMPATIBILITY TEST","GAME LIBRARY","FAVORITES","PHOTO CENTER","VIDEO CENTER","ADVANCED TOOLS","FILE MANAGER","SETTINGS","Choose language","Your MATRIX world","Device capability test","Back","Close","Language"});
    tr.put("fr",new String[]{"ACCUEIL","CENTRE PS2","TEST COMPATIBILITÉ","BIBLIOTHÈQUE","FAVORIS","PHOTOS","VIDÉOS","OUTILS AVANCÉS","FICHIERS","PARAMÈTRES","Choisir la langue","Votre univers MATRIX","Test de l’appareil","Retour","Fermer","Langue"});
    tr.put("es",new String[]{"INICIO","CENTRO PS2","PRUEBA COMPATIBILIDAD","BIBLIOTECA","FAVORITOS","FOTOS","VÍDEOS","HERRAMIENTAS","ARCHIVOS","AJUSTES","Elegir idioma","Tu mundo MATRIX","Prueba del dispositivo","Volver","Cerrar","Idioma"});
    tr.put("de",new String[]{"START","PS2-ZENTRUM","KOMPATIBILITÄTSTEST","SPIELBIBLIOTHEK","FAVORITEN","FOTOS","VIDEOS","WERKZEUGE","DATEIEN","EINSTELLUNGEN","Sprache wählen","Deine MATRIX-Welt","Gerätetest","Zurück","Schließen","Sprache"});
    tr.put("it",new String[]{"HOME","CENTRO PS2","TEST COMPATIBILITÀ","LIBRERIA","PREFERITI","FOTO","VIDEO","STRUMENTI","FILE","IMPOSTAZIONI","Scegli lingua","Il tuo mondo MATRIX","Test dispositivo","Indietro","Chiudi","Lingua"});
    tr.put("pt",new String[]{"INÍCIO","CENTRO PS2","TESTE DE COMPATIBILIDADE","BIBLIOTECA","FAVORITOS","FOTOS","VÍDEOS","FERRAMENTAS","ARQUIVOS","DEFINIÇÕES","Escolher idioma","O teu mundo MATRIX","Teste do dispositivo","Voltar","Fechar","Idioma"});
    tr.put("ru",new String[]{"ГЛАВНАЯ","ЦЕНТР PS2","ТЕСТ СОВМЕСТИМОСТИ","БИБЛИОТЕКА","ИЗБРАННОЕ","ФОТО","ВИДЕО","ИНСТРУМЕНТЫ","ФАЙЛЫ","НАСТРОЙКИ","Выбрать язык","Твой мир MATRIX","Тест устройства","Назад","Закрыть","Язык"});
    tr.put("tr",new String[]{"ANA SAYFA","PS2 MERKEZİ","UYUMLULUK TESTİ","OYUN KÜTÜPHANESİ","FAVORİLER","FOTOĞRAFLAR","VİDEOLAR","ARAÇLAR","DOSYALAR","AYARLAR","Dil seç","MATRIX dünyan","Cihaz testi","Geri","Kapat","Dil"});
    tr.put("zh",new String[]{"主页","PS2中心","兼容性测试","游戏库","收藏","照片中心","视频中心","高级工具","文件管理","设置","选择语言","你的 MATRIX 世界","设备测试","返回","关闭","语言"});
    tr.put("ja",new String[]{"ホーム","PS2センター","互換性テスト","ゲームライブラリ","お気に入り","写真","ビデオ","ツール","ファイル","設定","言語を選択","MATRIXの世界","端末テスト","戻る","閉じる","言語"});
    tr.put("ko",new String[]{"홈","PS2 센터","호환성 테스트","게임 라이브러리","즐겨찾기","사진","동영상","고급 도구","파일 관리자","설정","언어 선택","MATRIX 세계","기기 테스트","뒤로","닫기","언어"});
    tr.put("hi",new String[]{"होम","PS2 केंद्र","अनुकूलता परीक्षण","गेम लाइब्रेरी","पसंदीदा","फ़ोटो","वीडियो","उन्नत टूल","फ़ाइल प्रबंधक","सेटिंग्स","भाषा चुनें","आपकी MATRIX दुनिया","डिवाइस परीक्षण","वापस","बंद करें","भाषा"});
    tr.put("id",new String[]{"BERANDA","PUSAT PS2","UJI KOMPATIBILITAS","PUSTAKA GAME","FAVORIT","FOTO","VIDEO","ALAT LANJUTAN","PENGELOLA FILE","PENGATURAN","Pilih bahasa","Dunia MATRIX Anda","Tes perangkat","Kembali","Tutup","Bahasa"});
    tr.put("ms",new String[]{"LAMAN UTAMA","PUSAT PS2","UJIAN KESESUAIAN","PERPUSTAKAAN","KEGEMARAN","FOTO","VIDEO","ALAT LANJUTAN","PENGURUS FAIL","TETAPAN","Pilih bahasa","Dunia MATRIX anda","Ujian peranti","Kembali","Tutup","Bahasa"});
    tr.put("th",new String[]{"หน้าหลัก","ศูนย์ PS2","ทดสอบความเข้ากันได้","คลังเกม","รายการโปรด","รูปภาพ","วิดีโอ","เครื่องมือขั้นสูง","จัดการไฟล์","การตั้งค่า","เลือกภาษา","โลก MATRIX ของคุณ","ทดสอบอุปกรณ์","กลับ","ปิด","ภาษา"});
    tr.put("vi",new String[]{"TRANG CHỦ","TRUNG TÂM PS2","KIỂM TRA TƯƠNG THÍCH","THƯ VIỆN","YÊU THÍCH","ẢNH","VIDEO","CÔNG CỤ","QUẢN LÝ TỆP","CÀI ĐẶT","Chọn ngôn ngữ","Thế giới MATRIX","Kiểm tra thiết bị","Quay lại","Đóng","Ngôn ngữ"});
    tr.put("nl",new String[]{"START","PS2-CENTRUM","COMPATIBILITEITSTEST","BIBLIOTHEEK","FAVORIETEN","FOTO'S","VIDEO'S","HULPMIDDELEN","BESTANDEN","INSTELLINGEN","Kies taal","Jouw MATRIX-wereld","Apparaattest","Terug","Sluiten","Taal"});
    tr.put("pl",new String[]{"START","CENTRUM PS2","TEST ZGODNOŚCI","BIBLIOTEKA","ULUBIONE","ZDJĘCIA","WIDEO","NARZĘDZIA","PLIKI","USTAWIENIA","Wybierz język","Twój świat MATRIX","Test urządzenia","Wstecz","Zamknij","Język"});
    tr.put("uk",new String[]{"ГОЛОВНА","ЦЕНТР PS2","ТЕСТ СУМІСНОСТІ","БІБЛІОТЕКА","ОБРАНЕ","ФОТО","ВІДЕО","ІНСТРУМЕНТИ","ФАЙЛИ","НАЛАШТУВАННЯ","Оберіть мову","Твій світ MATRIX","Тест пристрою","Назад","Закрити","Мова"});
    tr.put("fa",new String[]{"خانه","مرکز PS2","آزمایش سازگاری","کتابخانه بازی","علاقه‌مندی‌ها","عکس‌ها","ویدیوها","ابزار پیشرفته","مدیریت فایل","تنظیمات","انتخاب زبان","دنیای MATRIX شما","آزمایش دستگاه","بازگشت","بستن","زبان"});
    tr.put("ur",new String[]{"ہوم","PS2 مرکز","مطابقت ٹیسٹ","گیم لائبریری","پسندیدہ","تصاویر","ویڈیوز","ایڈوانس ٹولز","فائل مینیجر","ترتیبات","زبان منتخب کریں","آپ کی MATRIX دنیا","ڈیوائس ٹیسٹ","واپس","بند کریں","زبان"});
    tr.put("bn",new String[]{"হোম","PS2 কেন্দ্র","সামঞ্জস্য পরীক্ষা","গেম লাইব্রেরি","প্রিয়","ছবি","ভিডিও","উন্নত সরঞ্জাম","ফাইল ম্যানেজার","সেটিংস","ভাষা নির্বাচন","আপনার MATRIX জগৎ","ডিভাইস পরীক্ষা","ফিরে যান","বন্ধ","ভাষা"});
    tr.put("sw",new String[]{"NYUMBANI","KITUO CHA PS2","JARIBIO LA UWEZO","MAKTABA YA MICHEZO","VIPENDWA","PICHA","VIDEO","ZANA ZA JUU","FAILI","MIPANGILIO","Chagua lugha","Ulimwengu wako wa MATRIX","Jaribio la kifaa","Rudi","Funga","Lugha"});
  }
  String s(int i){String[] a=tr.get(lang); if(a==null)a=tr.get("en"); return a[i];}
  GradientDrawable shape(int a,int b,int stroke){GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{a,b});d.setCornerRadius(25);d.setStroke(2,stroke);return d;}
  TextView txt(String v,int z,int c){TextView t=new TextView(this);t.setText(v);t.setTextColor(c);t.setTextSize(z);t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
  LinearLayout linear(boolean vertical){LinearLayout l=new LinearLayout(this);l.setOrientation(vertical?1:0);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
  @Override public void onCreate(Bundle b){super.onCreate(b);initTranslations();lang=getPreferences(0).getString("lang","ar");getWindow().setStatusBarColor(Color.rgb(2,5,15));getWindow().setNavigationBarColor(Color.rgb(2,5,15));
    musicEnabled=getPreferences(0).getBoolean("music_enabled",true);
    getPreferences(0).edit().putBoolean("music_enabled",musicEnabled).apply();
    clickEnabled=getPreferences(0).getBoolean("click_enabled",true);
    musicVolume=getPreferences(0).getInt("music_volume",65);
    musicTrack=getPreferences(0).getInt("music_track",0);
    clickTone=new ToneGenerator(AudioManager.STREAM_SYSTEM,45);
    if(musicEnabled) startMusic();
    render();}
  void render(){
    FrameLayout root=new FrameLayout(this);ImageView bg=new ImageView(this);bg.setImageResource(R.drawable.matrix_wallpaper);bg.setScaleType(ImageView.ScaleType.CENTER_CROP);root.addView(bg,new FrameLayout.LayoutParams(-1,-1));
    View dim=new View(this);dim.setBackgroundColor(Color.argb(168,0,3,13));root.addView(dim,new FrameLayout.LayoutParams(-1,-1));
    ScrollView sc=new ScrollView(this);sc.setFillViewport(true);LinearLayout content=linear(true);content.setPadding(16,18,16,24);sc.addView(content);root.addView(sc);setContentView(root);page=content;
    LinearLayout top=linear(false);TextView brand=txt("♛ MATRIX",27,Color.WHITE);brand.setShadowLayer(18,0,0,blue);top.addView(brand,new LinearLayout.LayoutParams(0,-2,1));TextView gearBtn=txt("⚙",25,Color.WHITE);gearBtn.setGravity(Gravity.CENTER);gearBtn.setPadding(13,5,13,5);gearBtn.setBackground(shape(Color.rgb(8,45,78),Color.rgb(4,12,29),blue));gearBtn.setElevation(18);gearBtn.setOnClickListener(v->{click();showSettings();});top.addView(gearBtn);
    TextView langBtn=txt("🌐  "+flags[indexOf(lang)]+"  "+s(15)+"  ▾",13,Color.WHITE);langBtn.setPadding(13,12,13,12);langBtn.setBackground(shape(Color.rgb(5,34,65),Color.rgb(10,12,30),blue));langBtn.setOnClickListener(v->chooseLanguage());top.addView(langBtn);page.addView(top);
    TextView sub=txt("G A M I N G   O S   •   5.8",11,Color.LTGRAY);sub.setPadding(4,5,0,4);page.addView(sub);
    TextView hero=txt(s(11),24,Color.WHITE);hero.setGravity(Gravity.CENTER);hero.setShadowLayer(22,0,0,blue);hero.setPadding(4,24,4,7);page.addView(hero);
    TextView desc=txt("GHOST  •  PLAYSTATION 2  •  MATRIX",10,Color.LTGRAY);desc.setGravity(Gravity.CENTER);desc.setPadding(0,0,0,18);page.addView(desc);
    addSection(s(1)); addFeature("Ⅱ","PS2",s(1),blue,()->showPs2Console());
    addFeature("◈","CPU / RAM",s(2),red,()->test());
    addSection("MATRIX HUB");
    LinearLayout r1=linear(false);page.addView(r1);feature(r1,"▣",s(3),blue,()->openGameLibrary());feature(r1,"★",s(4),red,()->showFavorites());
    LinearLayout r2=linear(false);page.addView(r2);feature(r2,"▧",s(5),red,()->openMedia("image/*","اختيار صورة"));feature(r2,"▶",s(6),blue,()->openMedia("video/*","اختيار فيديو"));
    LinearLayout r3=linear(false);page.addView(r3);feature(r3,"⚙",s(7),blue,()->showTools());feature(r3,"☷",s(8),red,()->openFileManager());
    addSection(s(9));
    addFeature("⚙",s(9),"إعدادات MATRIX • MUSIC • SOUND",blue,()->showSettings());
    addFeature("🌐",s(15),"24 LANGUAGES",blue,()->chooseLanguage());
    TextView foot=txt("MATRIX GAMING 5.8   •   BUILT FOR GAMERS",9,Color.LTGRAY);foot.setGravity(Gravity.CENTER);foot.setPadding(0,22,0,0);page.addView(foot);
  }

  void showPs2Console(){
    final android.content.SharedPreferences prefs=getSharedPreferences("matrix_ps2_pad",MODE_PRIVATE);
    FrameLayout frame=new FrameLayout(this);frame.setBackgroundColor(Color.rgb(2,5,14));
    LinearLayout shell=linear(true);shell.setPadding(12,12,12,12);
    ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);frame.addView(scroll);
    scroll.addView(shell);
    LinearLayout head=linear(false);
    TextView back=txt("‹ رجوع",15,Color.WHITE);back.setPadding(8,8,12,8);
    back.setOnClickListener(v->{click();render();});head.addView(back);
    TextView title=txt("MATRIX PS2 • لوحة التحكم",16,Color.WHITE);
    head.addView(title,new LinearLayout.LayoutParams(0,-2,1));
    TextView save=txt("حفظ",13,Color.WHITE);save.setPadding(12,8,12,8);
    save.setBackground(shape(Color.rgb(8,65,95),Color.rgb(2,15,30),blue));
    head.addView(save);shell.addView(head);
    TextView screen=txt("MATRIX PS2\\nشاشة المحاكي",17,Color.WHITE);
    screen.setGravity(Gravity.CENTER);screen.setBackground(shape(Color.rgb(8,24,43),Color.rgb(2,8,18),blue));
    LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,155);sp.setMargins(0,10,0,10);shell.addView(screen,sp);
    TextView state=txt("آخر إدخال: —",11,Color.LTGRAY);state.setGravity(Gravity.CENTER);shell.addView(state);
    TextView note=txt("لوحة لمس تجريبية • تنتظر ربط محرك Play!",10,Color.YELLOW);
    note.setGravity(Gravity.CENTER);shell.addView(note);
    LinearLayout options=linear(false);options.setGravity(Gravity.CENTER);
    shell.addView(options);
    TextView settings=txt("⚙ إعدادات الأزرار",12,Color.WHITE);settings.setPadding(10,8,10,8);
    settings.setBackground(shape(Color.rgb(10,43,72),Color.rgb(3,12,27),blue));options.addView(settings);
    TextView reset=txt("↺ استعادة",12,Color.WHITE);reset.setPadding(10,8,10,8);
    reset.setBackground(shape(Color.rgb(10,43,72),Color.rgb(3,12,27),blue));options.addView(reset);
    LinearLayout.LayoutParams rowP=new LinearLayout.LayoutParams(-1,-2);rowP.setMargins(0,8,0,4);
    LinearLayout top=linear(false);top.setGravity(Gravity.CENTER);shell.addView(top,rowP);
    addPadButton(top,"L2","L2",state);addPadButton(top,"L1","L1",state);
    addPadButton(top,"R1","R1",state);addPadButton(top,"R2","R2",state);
    LinearLayout body=linear(false);body.setGravity(Gravity.CENTER);shell.addView(body,rowP);
    LinearLayout left=linear(true);left.setGravity(Gravity.CENTER);body.addView(left,new LinearLayout.LayoutParams(0,-2,1));
    LinearLayout right=linear(true);right.setGravity(Gravity.CENTER);body.addView(right,new LinearLayout.LayoutParams(0,-2,1));
    LinearLayout up=linear(false);up.setGravity(Gravity.CENTER);left.addView(up);
    LinearLayout lr=linear(false);lr.setGravity(Gravity.CENTER);left.addView(lr);
    LinearLayout dn=linear(false);dn.setGravity(Gravity.CENTER);left.addView(dn);
    addPadButton(up,"↑","UP",state);addPadButton(lr,"←","LEFT",state);addPadButton(lr,"L3","L3",state);addPadButton(lr,"→","RIGHT",state);addPadButton(dn,"↓","DOWN",state);
    LinearLayout r1=linear(false);r1.setGravity(Gravity.CENTER);right.addView(r1);
    LinearLayout r2=linear(false);r2.setGravity(Gravity.CENTER);right.addView(r2);
    addPadButton(r1,"△","TRIANGLE",state);addPadButton(r1,"○","CIRCLE",state);
    addPadButton(r2,"□","SQUARE",state);addPadButton(r2,"×","CROSS",state);
    LinearLayout sticks=linear(false);sticks.setGravity(Gravity.CENTER);shell.addView(sticks,rowP);
    addPadButton(sticks,"R3","R3",state);
    LinearLayout middle=linear(false);middle.setGravity(Gravity.CENTER);shell.addView(middle,rowP);
    addPadButton(middle,"SELECT","SELECT",state);addPadButton(middle,"START","START",state);
    LinearLayout extra=linear(false);extra.setGravity(Gravity.CENTER);shell.addView(extra,rowP);
    addPadButton(extra,"TURBO","TURBO",state);addPadButton(extra,"مركز","CENTER",state);
    save.setOnClickListener(v->{click();prefs.edit().putBoolean("layout_saved",true).putInt("button_size",prefs.getInt("button_size",48)).apply();dialog("تم الحفظ","تم حفظ إعدادات لوحة التحكم على هذا الجهاز.");});
    reset.setOnClickListener(v->{click();prefs.edit().clear().apply();dialog("استعادة","تمت استعادة إعدادات لوحة التحكم الافتراضية. أعد فتح اللوحة لتطبيقها.");});
    settings.setOnClickListener(v->{click();LinearLayout box=linear(true);box.setPadding(16,8,16,8);
      TextView sizeLabel=txt("حجم الأزرار",14,Color.WHITE);box.addView(sizeLabel);
      SeekBar size=new SeekBar(this);size.setMax(48);size.setProgress(prefs.getInt("button_size",48)-32);box.addView(size);
      TextView opacityLabel=txt("شفافية الأزرار",14,Color.WHITE);box.addView(opacityLabel);
      SeekBar opacity=new SeekBar(this);opacity.setMax(100);opacity.setProgress(prefs.getInt("button_opacity",90));box.addView(opacity);
      new AlertDialog.Builder(this).setTitle("إعدادات لوحة التحكم").setView(box).setPositiveButton("حفظ",(d,w)->prefs.edit().putInt("button_size",32+size.getProgress()).putInt("button_opacity",opacity.getProgress()).apply()).setNegativeButton("إلغاء",null).show();
    });
    setContentView(frame);
  }
  void addPadButton(LinearLayout parent,String label,String code,TextView state){
    android.content.SharedPreferences padPrefs=getSharedPreferences("matrix_ps2_pad",MODE_PRIVATE);
    int buttonSize=padPrefs.getInt("button_size",48), opacity=padPrefs.getInt("button_opacity",90);
    TextView b=txt(label, label.length()>2?10:17,Color.WHITE);b.setGravity(Gravity.CENTER);b.setAlpha(Math.max(.2f,opacity/100f));
    b.setBackground(shape(Color.rgb(10,43,72),Color.rgb(3,12,27),blue));b.setElevation(8);
    LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(label.length()>2?buttonSize+20:buttonSize,buttonSize);
    p.setMargins(3,3,3,3);parent.addView(b,p);
    b.setOnTouchListener((v,event)->{
      if(event.getAction()==MotionEvent.ACTION_DOWN){click();v.animate().scaleX(.93f).scaleY(.93f).setDuration(60).start();state.setText("آخر إدخال: "+code+" • DOWN");return true;}
      if(event.getAction()==MotionEvent.ACTION_UP || event.getAction()==MotionEvent.ACTION_CANCEL){v.animate().scaleX(1f).scaleY(1f).setDuration(70).start();state.setText("آخر إدخال: "+code+" • UP");return true;}
      return true;
    });
  }
\n  int indexOf(String c){for(int i=0;i<codes.length;i++)if(codes[i].equals(c))return i;return 1;}
  void addSection(String t){TextView x=txt(t,15,Color.WHITE);x.setPadding(4,18,4,9);page.addView(x);}
  void addFeature(String icon,String title,String sub,int color,Runnable run){LinearLayout holder=linear(true);holder.setPadding(18,15,18,15);holder.setBackground(shape(Color.argb(235,7,27,52),Color.argb(245,3,7,18),color));holder.setElevation(14);TextView i=txt(icon,28,color);holder.addView(i);TextView h=txt(title,15,Color.WHITE);h.setPadding(0,5,0,2);holder.addView(h);TextView d=txt(sub,10,Color.LTGRAY);holder.addView(d);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(2,6,2,7);page.addView(holder,p);animate(holder,run);}
  void feature(LinearLayout row,String icon,String title,int color){feature(row,icon,title,color,()->dialog(title,"هذه الميزة غير مفعلة بعد."));}
  void feature(LinearLayout row,String icon,String title,int color,Runnable action){LinearLayout h=linear(true);h.setGravity(Gravity.CENTER);h.setPadding(8,16,8,16);h.setBackground(shape(Color.rgb(9,29,54),Color.rgb(3,8,20),color));h.setElevation(12);h.addView(txt(icon,27,color));TextView t=txt(title,11,Color.WHITE);t.setGravity(Gravity.CENTER);t.setPadding(0,7,0,0);h.addView(t);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,112,1);p.setMargins(5,5,5,5);row.addView(h,p);animate(h,action);}
  void click(){if(clickEnabled && clickTone!=null) clickTone.startTone(ToneGenerator.TONE_PROP_BEEP,55);}
  void startMusic(){
    try{
      if(musicPlayer!=null){musicPlayer.release();musicPlayer=null;}
      int trackRes=musicTrack==0?R.raw.matrix_battlefield_theme:R.raw.battlefield1_classic_theme;
      musicPlayer=MediaPlayer.create(this,trackRes);
      if(musicPlayer==null)return;
      musicPlayer.setLooping(true);
      musicPlayer.setVolume(musicVolume/100f,musicVolume/100f);
      if(musicEnabled)musicPlayer.start();
    }catch(Exception e){dialog("Music","تعذر تشغيل الموسيقى: "+e.getMessage());}
  }
  void stopMusic(){try{if(musicPlayer!=null && musicPlayer.isPlaying())musicPlayer.pause();}catch(Exception e){}}
  void showSettings(){
    LinearLayout box=linear(true);box.setPadding(22,12,22,8);
    TextView heading=txt("إعدادات MATRIX GAMING",18,Color.WHITE);box.addView(heading);
    Switch music=new Switch(this);music.setText("تشغيل الموسيقى تلقائياً عند فتح التطبيق");music.setTextColor(Color.WHITE);music.setChecked(musicEnabled);box.addView(music);
    TextView trackLabel=txt("اختيار الموسيقى",14,Color.LTGRAY);trackLabel.setPadding(0,15,0,5);box.addView(trackLabel);
    Spinner tracks=new Spinner(this);
    String[] trackNames={"Battlefield 1942 Theme","Battlefield 1 Classic Theme"};
    tracks.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,trackNames));
    tracks.setSelection(musicTrack);box.addView(tracks);
    TextView volLabel=txt("مستوى صوت الموسيقى: "+musicVolume+"%",14,Color.LTGRAY);volLabel.setPadding(0,15,0,2);box.addView(volLabel);
    SeekBar volume=new SeekBar(this);volume.setMax(100);volume.setProgress(musicVolume);box.addView(volume);
    Switch clicks=new Switch(this);clicks.setText("أصوات ضغط الأزرار");clicks.setTextColor(Color.WHITE);clicks.setChecked(clickEnabled);clicks.setPadding(0,14,0,4);box.addView(clicks);
    TextView language=txt("🌐  اللغة: "+flags[indexOf(lang)]+" "+languageNames[indexOf(lang)],14,Color.WHITE);language.setPadding(0,18,0,12);box.addView(language);
    language.setOnClickListener(v->{click();chooseLanguage();});
    music.setOnCheckedChangeListener((b,on)->{musicEnabled=on;getPreferences(0).edit().putBoolean("music_enabled",on).apply();if(on){if(musicPlayer==null)startMusic();else if(!musicPlayer.isPlaying())musicPlayer.start();}else stopMusic();});
    tracks.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?> parent,View view,int position,long id){if(musicTrack!=position){musicTrack=position;getPreferences(0).edit().putInt("music_track",musicTrack).apply();if(musicEnabled)startMusic();}}public void onNothingSelected(android.widget.AdapterView<?> parent){}});
    volume.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int value,boolean user){musicVolume=value;volLabel.setText("مستوى صوت الموسيقى: "+value+"%");if(musicPlayer!=null)musicPlayer.setVolume(value/100f,value/100f);}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){getPreferences(0).edit().putInt("music_volume",musicVolume).apply();}});
    clicks.setOnCheckedChangeListener((b,on)->{clickEnabled=on;getPreferences(0).edit().putBoolean("click_enabled",on).apply();});
    new AlertDialog.Builder(this).setView(box).setPositiveButton("حفظ وإغلاق",(d,w)->{getPreferences(0).edit().putInt("music_volume",musicVolume).apply();}).show();
  }
  @Override protected void onResume(){super.onResume();if(musicEnabled){if(musicPlayer==null)startMusic();else if(!musicPlayer.isPlaying())musicPlayer.start();}}
  @Override protected void onStop(){super.onStop();stopMusic();}
  @Override protected void onDestroy(){super.onDestroy();try{if(musicPlayer!=null){musicPlayer.release();musicPlayer=null;}if(clickTone!=null)clickTone.release();}catch(Exception e){}}
  void animate(View v,Runnable r){v.setOnTouchListener((view,event)->{if(event.getAction()==0){view.animate().scaleX(.96f).scaleY(.96f).setDuration(90).start();}else if(event.getAction()==1){click();view.animate().scaleX(1f).scaleY(1f).setDuration(150).start();r.run();}else if(event.getAction()==3){view.animate().scaleX(1f).scaleY(1f).setDuration(150).start();}return true;});}

  static final int REQ_GAME=7101, REQ_IMAGE=7102, REQ_VIDEO=7103, REQ_FILE=7104;
  ArrayList<String> selectedGames=new ArrayList<>();
  void openGameLibrary(){ renderGameLibrary(); }
  void pickGameFile(){
    Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.addCategory(Intent.CATEGORY_OPENABLE);
    i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/octet-stream","application/x-cd-image","application/zip"});
    startActivityForResult(i,REQ_GAME);
  }
  String[] savedUris(){String raw=getSharedPreferences("matrix_library",MODE_PRIVATE).getString("games","");return raw.trim().isEmpty()?new String[0]:raw.split("\\n");}
  Set<String> favoriteUris(){String raw=getSharedPreferences("matrix_library",MODE_PRIVATE).getString("favorites","");Set<String> out=new HashSet<>();if(!raw.trim().isEmpty())out.addAll(Arrays.asList(raw.split("\\n")));return out;}
  void storeLines(String key,Collection<String> values){StringBuilder b=new StringBuilder();for(String v:values){if(v==null||v.trim().isEmpty())continue;if(b.length()>0)b.append('\n');b.append(v);}getSharedPreferences("matrix_library",MODE_PRIVATE).edit().putString(key,b.toString()).apply();}
  void renderGameLibrary(){
    FrameLayout frame=new FrameLayout(this);frame.setBackgroundColor(Color.rgb(2,5,14));
    LinearLayout box=linear(true);box.setPadding(16,14,16,18);ScrollView scroll=new ScrollView(this);scroll.addView(box);frame.addView(scroll);
    LinearLayout head=linear(false);TextView back=txt("‹ رجوع",14,Color.WHITE);back.setPadding(8,10,16,10);back.setOnClickListener(v->render());head.addView(back);
    TextView title=txt("مكتبة ألعاب MATRIX",18,Color.WHITE);head.addView(title,new LinearLayout.LayoutParams(0,-2,1));box.addView(head);
    EditText search=new EditText(this);search.setSingleLine(true);search.setHint("ابحث باسم ملف اللعبة...");search.setTextColor(Color.WHITE);search.setHintTextColor(Color.LTGRAY);search.setBackground(shape(Color.rgb(8,25,45),Color.rgb(3,9,20),blue));box.addView(search,new LinearLayout.LayoutParams(-1,-2));
    TextView add=txt("＋ إضافة ملف لعبة",14,Color.WHITE);add.setGravity(Gravity.CENTER);add.setPadding(12,14,12,14);add.setBackground(shape(Color.rgb(5,65,105),Color.rgb(3,17,34),blue));LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-1,-2);ap.setMargins(0,10,0,10);box.addView(add,ap);add.setOnClickListener(v->{click();pickGameFile();});
    LinearLayout items=linear(true);box.addView(items);
    final Runnable[] refreshRef=new Runnable[1];refreshRef[0]=()->{items.removeAllViews();String[] uris=savedUris();Set<String> fav=favoriteUris();String q=search.getText().toString().toLowerCase(Locale.ROOT);int shown=0;
      for(String raw:uris){Uri u=Uri.parse(raw);String name=displayName(u);if(!name.toLowerCase(Locale.ROOT).contains(q))continue;shown++;
        LinearLayout card=linear(true);card.setPadding(12,10,12,10);card.setBackground(shape(Color.rgb(8,27,49),Color.rgb(3,9,20),fav.contains(raw)?red:blue));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(0,5,0,5);items.addView(card,cp);
        TextView nm=txt(name,13,Color.WHITE);card.addView(nm);TextView info=txt("ملف محفوظ • لا يتوفر تشغيل PS2 قبل دمج المحرك",9,Color.LTGRAY);info.setPadding(0,4,0,7);card.addView(info);
        LinearLayout actions=linear(false);card.addView(actions);TextView favorite=txt(fav.contains(raw)?"★ إزالة من المفضلة":"☆ إضافة للمفضلة",11,Color.YELLOW);favorite.setPadding(8,7,12,7);actions.addView(favorite);favorite.setOnClickListener(v->{Set<String> f=favoriteUris();if(!f.add(raw))f.remove(raw);storeLines("favorites",f);refreshRef[0].run();});
        TextView remove=txt("حذف من المكتبة",11,Color.RED);remove.setPadding(12,7,8,7);actions.addView(remove);remove.setOnClickListener(v->new AlertDialog.Builder(this).setMessage("حذف الملف من قائمة MATRIX فقط؟ لن يُحذف الملف الأصلي من الهاتف.").setNegativeButton("إلغاء",null).setPositiveButton("حذف",(d,w)->{ArrayList<String> list=new ArrayList<>(Arrays.asList(savedUris()));list.remove(raw);storeLines("games",list);Set<String> f=favoriteUris();f.remove(raw);storeLines("favorites",f);refreshRef[0].run();}).show());
      }
      if(shown==0){TextView empty=txt(uris.length==0?"مكتبتك فارغة. اضغط إضافة ملف لعبة.":"ماكو نتائج تطابق البحث.",12,Color.LTGRAY);empty.setPadding(5,18,5,18);items.addView(empty);}
    };search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){refresh.run();}public void afterTextChanged(android.text.Editable e){}});refreshRef[0].run();setContentView(frame);
  }
  void openMedia(String type,String title){
    Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType(type);i.addCategory(Intent.CATEGORY_OPENABLE);
    startActivityForResult(i,type.startsWith("image")?REQ_IMAGE:REQ_VIDEO);
  }
  void openFileManager(){
    Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.addCategory(Intent.CATEGORY_OPENABLE);
    startActivityForResult(i,REQ_FILE);
  }
  String displayName(Uri uri){
    Cursor c=null;try{c=getContentResolver().query(uri,null,null,null,null);if(c!=null&&c.moveToFirst()){int n=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(n>=0)return c.getString(n);}}catch(Exception e){}finally{if(c!=null)c.close();}return uri.getLastPathSegment();
  }
  @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
    super.onActivityResult(requestCode,resultCode,data);
    if(resultCode!=RESULT_OK||data==null||data.getData()==null)return;
    Uri uri=data.getData();String name=displayName(uri);
    if(requestCode==REQ_GAME){
      try{int flags=data.getFlags()&(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);getContentResolver().takePersistableUriPermission(uri,flags);}catch(Exception ignored){}
      android.content.SharedPreferences p=getSharedPreferences("matrix_library",MODE_PRIVATE);
      String old=p.getString("games","");
      if(!Arrays.asList(old.split("\\n")).contains(uri.toString()))p.edit().putString("games",old+(old.isEmpty()?"":"\n")+uri.toString()).apply();
      dialog("تمت إضافة الملف",name+"\nتم حفظه في المكتبة. افتح المكتبة للبحث أو إضافته للمفضلة. تشغيل ألعاب PS2 ينتظر دمج المحرك.");
    }else if(requestCode==REQ_IMAGE||requestCode==REQ_VIDEO){
      Intent view=new Intent(Intent.ACTION_VIEW);view.setDataAndType(uri,requestCode==REQ_IMAGE?"image/*":"video/*");view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
      try{startActivity(view);}catch(Exception e){dialog("تعذر الفتح",e.getMessage());}
    }else if(requestCode==REQ_FILE){
      dialog("مدير الملفات",name+"\n"+uri.toString());
    }
  }
  void showFavorites(){
    String[] uris=savedUris();Set<String> fav=favoriteUris();ArrayList<String> only=new ArrayList<>();for(String u:uris)if(fav.contains(u))only.add(u);
    if(only.isEmpty()){dialog("المفضلة","ماكو ألعاب بالمفضلة. افتح مكتبة الألعاب واضغط إضافة للمفضلة.");return;}
    String[] labels=new String[only.size()];for(int i=0;i<only.size();i++)labels[i]=(i+1)+". "+displayName(Uri.parse(only.get(i)));
    new AlertDialog.Builder(this).setTitle("ألعابك المفضلة").setItems(labels,(d,w)->dialog("ملف محفوظ",displayName(Uri.parse(only.get(w)))+"\nتشغيل اللعبة يحتاج دمج محرك PS2 أولاً.")).setPositiveButton("إغلاق",null).show();
  }
  void showTools(){
    ActivityManager am=(ActivityManager)getSystemService(ACTIVITY_SERVICE);ActivityManager.MemoryInfo mi=new ActivityManager.MemoryInfo();am.getMemoryInfo(mi);
    StatFs fs=new StatFs(getFilesDir().getAbsolutePath());
    String report="Android: "+Build.VERSION.RELEASE+"\nABI: "+Build.SUPPORTED_ABIS[0]+"\n64-bit: "+android.os.Process.is64Bit()+"\nRAM الكلية: "+(mi.totalMem/1048576)+" MB\\nRAM المتاحة: "+(mi.availMem/1048576)+" MB\\nمساحة التطبيق المتاحة: "+(fs.getAvailableBytes()/1048576)+" MB";
    new AlertDialog.Builder(this).setTitle("أدوات الجهاز").setMessage(report).setPositiveButton("حسناً",null).show();
  }
\n  void dialog(String title,String msg){new AlertDialog.Builder(this).setTitle(title).setMessage(msg).setPositiveButton(s(13),(d,w)->d.dismiss()).show();}
  void chooseLanguage(){String[] opts=new String[codes.length];for(int i=0;i<opts.length;i++)opts[i]=flags[i]+"  "+languageNames[i];new AlertDialog.Builder(this).setTitle(s(10)).setItems(opts,(d,w)->{lang=codes[w];getPreferences(0).edit().putString("lang",lang).apply();render();}).setNegativeButton(s(13),null).show();}
  void test(){ActivityManager am=(ActivityManager)getSystemService(ACTIVITY_SERVICE);ActivityManager.MemoryInfo mi=new ActivityManager.MemoryInfo();am.getMemoryInfo(mi);long total=mi.totalMem/1048576,free=mi.availMem/1048576;String report="Android: "+Build.VERSION.RELEASE+"\nABI: "+Build.SUPPORTED_ABIS[0]+"\n64-bit: "+(android.os.Process.is64Bit()?"Yes":"No")+"\nRAM total: "+total+" MB\nRAM available: "+free+" MB";new AlertDialog.Builder(this).setTitle(s(2)).setMessage(report+"\n\nهذا فحص مواصفات فقط، وليس اختبار تشغيل محاكي.").setPositiveButton(s(14),null).show();}
}
