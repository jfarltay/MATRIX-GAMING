package com.matrix.gaming;
import android.app.*; import android.app.ActivityManager; import android.content.*; import android.graphics.Typeface; import android.graphics.drawable.GradientDrawable; import android.os.*; import android.view.*; import android.widget.*; import java.io.File; import java.text.DecimalFormat;
public class MainActivity extends Activity {
 final int BG=0xFF050907, PANEL=0xFF0D1711, GREEN=0xFF39F58A, MUTED=0xFFB7C8BD;
 LinearLayout content; DecimalFormat df=new DecimalFormat("0.0");
 public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);home();}
 TextView t(String s,int size,int color){TextView v=new TextView(this);v.setText(s);v.setTextSize(size);v.setTextColor(color);v.setPadding(0,5,0,5);return v;}
 GradientDrawable shape(){GradientDrawable d=new GradientDrawable();d.setColor(PANEL);d.setCornerRadius(22);d.setStroke(2,0xFF1B7043);return d;}
 LinearLayout panel(){LinearLayout p=new LinearLayout(this);p.setOrientation(1);p.setPadding(16,13,16,13);p.setBackground(shape());LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,7,0,7);p.setLayoutParams(lp);return p;}
 void home(){
  LinearLayout outer=new LinearLayout(this);outer.setOrientation(1);outer.setPadding(18,18,18,12);outer.setBackgroundColor(BG);
  ScrollView sc=new ScrollView(this);content=new LinearLayout(this);content.setOrientation(1);sc.addView(content);outer.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
  outer.addView(t("MATRIX CORE  •  LOCAL MODE",10,GREEN));setContentView(outer);
  TextView logo=t("MATRIX GAMING",29,GREEN);logo.setTypeface(Typeface.DEFAULT,Typeface.BOLD);content.addView(logo);
  content.addView(t("ULTIMATE PHONE & GAMING CONTROL CENTER",10,MUTED));
  LinearLayout hero=panel();hero.addView(t(Build.MANUFACTURER+" "+Build.MODEL,19,-1));hero.addView(t("ANDROID "+Build.VERSION.RELEASE+"  |  API "+Build.VERSION.SDK_INT,12,GREEN));hero.addView(t("SYSTEM STATUS: READY",11,GREEN));content.addView(hero);
  content.addView(t("LIVE MONITOR",13,GREEN));LinearLayout r=new LinearLayout(this);
  r.addView(metric("CPU CORES",""+Runtime.getRuntime().availableProcessors()),new LinearLayout.LayoutParams(0,-2,1));
  r.addView(metric("RAM",ram()),new LinearLayout.LayoutParams(0,-2,1));content.addView(r);
  LinearLayout r2=new LinearLayout(this);r2.addView(metric("APP STORAGE",storage()),new LinearLayout.LayoutParams(0,-2,1));r2.addView(metric("BATTERY",battery()),new LinearLayout.LayoutParams(0,-2,1));content.addView(r2);
  content.addView(t("ALL-IN-ONE MODULES",13,GREEN));
  add("MATRIX GAMING","مكتبة الألعاب، سجل اللعب، وملاحظات كل لعبة",()->msg("MATRIX GAMING","هذه النسخة توفر سجل ألعاب محلياً. إدارة ملفات الألعاب تلقائياً وتشغيل ألعاب PS2/PS3 تحتاج تطبيقات ومحاكيات مخصصة."));
  add("MATRIX BOOST","مراقبة الذاكرة والبطارية ومعلومات الجهاز",()->diagnostics());
  add("MATRIX STORAGE","إرشادات تنظيم الملفات والتخزين وUSB",()->msg("MATRIX STORAGE","استخدم مدير الملفات في أندرويد لنسخ الملفات. لا تهيّئ USB قبل النسخ الاحتياطي. هذه النسخة لا تغيّر الأقسام."));
  add("MATRIX CONTROL","اختصارات إعدادات الشاشة والصوت والشبكة والتطبيقات",()->settings());
  add("MATRIX SECURITY","مراجعة أذونات التطبيقات وإعدادات الأمان",()->open(android.provider.Settings.ACTION_APPLICATION_SETTINGS));
  add("MATRIX GAME TOOLS","مؤقت لعب وملاحظات وإعدادات لكل لعبة",()->msg("MATRIX GAME TOOLS","الأدوات الأساسية قيد التطوير. لا يوجد تعديل للعبة أو تجاوز للحماية."));
  add("MATRIX DIAGNOSTICS","تشخيص معلومات الجهاز الأساسية",()->diagnostics());
  add("ABOUT MATRIX","حول التطبيق وحدود الصلاحيات",()->msg("MATRIX GAMING","الإصدار 1.0 — نسخة أولية تعمل محلياً.\nلا تدّعي زيادة FPS أو تغيير تردد المعالج أو تبريد الهاتف. بعض وظائف النظام تحتاج صلاحيات لا يمنحها أندرويد للتطبيق العادي."));
  content.addView(t("MATRIX GAMING  •  VERSION 1.0",10,0xFF71877B));
 }
 View metric(String a,String b){LinearLayout p=panel();p.addView(t(a,10,GREEN));p.addView(t(b,17,-1));return p;}
 void add(String a,String b,Runnable action){LinearLayout p=panel();p.addView(t(a,15,GREEN));p.addView(t(b,12,MUTED));p.setOnClickListener(v->action.run());content.addView(p);}
 String ram(){ActivityManager am=(ActivityManager)getSystemService(ACTIVITY_SERVICE);ActivityManager.MemoryInfo m=new ActivityManager.MemoryInfo();am.getMemoryInfo(m);return df.format((m.totalMem-m.availMem)/1073741824.0)+" / "+df.format(m.totalMem/1073741824.0)+" GB";}
 String storage(){File f=getFilesDir();return df.format((f.getTotalSpace()-f.getFreeSpace())/1073741824.0)+" GB used";}
 String battery(){Intent i=registerReceiver(null,new IntentFilter(Intent.ACTION_BATTERY_CHANGED));if(i==null)return "N/A";int l=i.getIntExtra("level",-1),s=i.getIntExtra("scale",100);return (l*100/Math.max(s,1))+"%";}
 void diagnostics(){msg("MATRIX DIAGNOSTICS","Device: "+Build.MANUFACTURER+" "+Build.MODEL+"\nAndroid: "+Build.VERSION.RELEASE+"\nCPU cores: "+Runtime.getRuntime().availableProcessors()+"\nRAM: "+ram()+"\nApp storage: "+storage()+"\nBattery: "+battery()+"\n\nتنبيه: هذه معلومات متاحة للتطبيق فقط؛ لا تعرض حرارة كل المكونات ولا تغيّر تردد المعالج.");}
 void settings(){new AlertDialog.Builder(this).setTitle("MATRIX CONTROL").setItems(new String[]{"إعدادات الشاشة","إعدادات الصوت","إعدادات الشبكة","إعدادات التطبيقات"},(d,w)->{String a=w==0?android.provider.Settings.ACTION_DISPLAY_SETTINGS:w==1?android.provider.Settings.ACTION_SOUND_SETTINGS:w==2?android.provider.Settings.ACTION_WIRELESS_SETTINGS:android.provider.Settings.ACTION_APPLICATION_SETTINGS;open(a);}).show();}
 void open(String action){try{startActivity(new Intent(action));}catch(Exception e){msg("تنبيه","تعذر فتح هذه الصفحة على هذا الجهاز.");}}
 void msg(String title,String body){new AlertDialog.Builder(this).setTitle(title).setMessage(body).setPositiveButton("إغلاق",null).show();}
}
