MATRIX GAMING v1.0
مشروع Android أولي شامل بلوحة محلية ووحدات للألعاب ومراقبة الجهاز والتخزين والإعدادات والأمان.
لا يدّعي رفع FPS أو تغيير تردد المعالج أو تبريد الهاتف أو تعديل الألعاب.
Build: gradle :app:assembleDebug
APK: app/build/outputs/apk/debug/app-debug.apk
