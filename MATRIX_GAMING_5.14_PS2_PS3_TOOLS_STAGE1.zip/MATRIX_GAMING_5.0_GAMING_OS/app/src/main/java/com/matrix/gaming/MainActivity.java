package com.matrix.gaming;

import android.app.*;
import android.os.*;
import android.app.ActivityManager;
import android.content.*;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.database.Cursor;
import android.os.StatFs;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.view.animation.*;
import android.widget.*;
import android.media.MediaPlayer;
import android.media.AudioManager;
import android.media.ToneGenerator;
import java.util.*;

public class MainActivity extends Activity {
  int blue=Color.rgb(0,155,255), red=Color.rgb(255,45,75); LinearLayout page; String lang="ar";
  MediaPlayer musicPlayer; ToneGenerator clickTone;
  boolean musicEnabled=true, clickEnabled=true, darkMode=true; int musicVolume=65; int musicTrack=0;
  String[] codes={"ar","en","fr","es","de","it","pt","ru","tr","zh","ja","ko","hi","id","ms","th","vi","nl","pl","uk","fa","ur","bn","sw"};
  String[] flags={"🇮🇶","🇬🇧","🇫🇷","🇪🇸","🇩🇪","🇮🇹","🇵🇹","🇷🇺","🇹🇷","🇨🇳","🇯🇵","🇰🇷","🇮🇳","🇮🇩","🇲🇾","🇹🇭","🇻🇳","🇳🇱","🇵🇱","🇺🇦","🇮🇷","🇵🇰","🇧🇩","🇰🇪"};
  String[] languageNames={"العربية","English","Français","Español","Deutsch","Italiano","Português","Русский","Türkçe","中文","日本語","한국어","हिन्दी","Bahasa Indonesia","Bahasa Melayu","ไทย","Tiếng Việt","Nederlands","Polski","Українська","فارسی","اردو","বাংলা","Kiswahili"};
  HashMap<String,String[]> tr=new HashMap<>();
  void initTranslations(){
    tr.put("ar",new String[]{"الرئيسية","مركز PS2","اختبار التوافق","مكتبة الألعاب","المفضلة","مركز الصور","مركز الفيديو","الأدوات المتقدمة","إدارة الملفات","الإعدادات","اختر اللغة","عالم MATRIX بين يديك","اختبار مواصفات الهاتف","رجوع","إغلاق","اللغة"});
    tr.put("en",new String[]{"HOME","PS2 CENTER","COMPATIBILITY TEST","GAME LIBRARY","FAVORITES","PHOTO CENTER","VIDEO CENTER","ADVANCED TOOLS","FILE MANAGER","SETTINGS","Choose language","Your MATRIX world","Device capability test","Back","Close","Language"});
    tr.put("fr",new String[]{"ACCUEIL","CENTRE PS2","TEST COMPATIBILITÉ","BIBLIOTHÈQUE","FAVORIS","PHOTOS","VIDÉOS","OUTILS AVANCÉS","FICHIERS","PARAMÈTRES","Choisir la langue","Votre univers MATRIX","Test de l’appareil","Retour","Fermer","Langue"});
    tr.put("es",new String[]{"INICIO","CENTRO PS2","PRUEBA COMPATIBILIDAD","BIBLIOTECA","FAVORITOS","FOTOS","VÍDEOS","HERRAMIENTAS","ARCHIVOS","AJUSTES","Elegir idioma","Tu mundo MATRIX","Prueba del dispositivo","Volver","Cerrar","Idioma"});
    tr.put("de",new String[]{"START","PS2-ZENTRUM","KOMPATIBILITÄTSTEST","SPIELBIBLIOTHEK","FAVORITEN","FOTOS","VIDEOS","WERKZEUGE","DATEIEN","EINSTELLUNGEN","Sprache wählen","Deine MATRIX-Welt","Gerätetest","Zurück","Schließen","Sprache"});
    tr.put("it",new String[]{"HOME","CENTRO PS2","TEST COMPATIBILITÀ","LIBRERIA","PREFERITI","FOTO","VIDEO","STRUMENTI","FILE","IMPOSTAZIONI","Scegli lingua","Il tuo mondo MATRIX","Test dispositivo","Indietro","Chiudi","Lingua"});
    tr.put("pt",new String[]{"INÍCIO","CENTRO PS2","TESTE DE COMPATIBILIDADE","BIBLIOTECA","FAVORITOS","FOTOS","VÍDEOS","FERRAMENTAS","ARQUIVOS","DEFINIÇÕES","Escolher idioma","O teu mundo MATRIX","Teste do dispositivo","Voltar","Fechar","Idioma"});
    tr.put("ru",new String[]{"ГЛАВНАЯ","ЦЕНТР PS2","ТЕСТ СОВМЕСТИМОСТИ","БИБЛИОТЕКА","ИЗБРАННОЕ","ФОТО","ВИДЕО","ИНСТРУМЕНТЫ","ФАЙЛЫ","НАСТРОЙКИ","Выбрать язык","Твой мир MATRIX","Тест устройства","Назад","Закрыть","Язык"});
    tr.put("tr",new String[]{"ANA SAYFA","PS2 MERKEZİ","UYUMLULUK TESTİ","OYUN KÜTÜPHANESİ","FAVORİLER","FOTOĞRAFLAR","VİDEOLAR","ARAÇLAR","DOSYALAR","AYARLAR","Dil seç","MATRIX dünyan","Cihaz testi","Geri","Kapat","Dil"});
    tr.put("zh",new String[]{"主页","PS2中心","兼容性测试","游戏库","收藏","照片中心","视频中心","高级工具","文件管理","设置","选择语言","你的 MATRIX 世界","设备测试","返回","关闭","语言"});
    tr.put("ja",new String[]{"ホーム","PS2センター","互換性テスト","ゲームライブラリ","お気に入り","写真","ビデオ","ツール","ファイル","設定","言語を選択","MATRIXの世界","端末テスト","戻る","閉じる","言語"});
    tr.put("ko",new String[]{"홈","PS2 센터","호환성 테스트","게임 라이브러리","즐겨찾기","사진","동영상","고급 도구","파일 관리자","설정","언어 선택","MATRIX 세계","기기 테스트","뒤로","닫기","언어"});
    tr.put("hi",new String[]{"होम","PS2 केंद्र","अनुकूलता परीक्षण","गेम लाइब्रेरी","पसंदीदा","फ़ोटो","वीडियो","उन्नत टूल","फ़ाइल प्रबंधक","सेटिंग्स","भाषा चुनें","आपकी MATRIX दुनिया","डिवाइस परीक्षण","वापस","बंद करें","भाषा"});
    tr.put("id",new String[]{"BERANDA","PUSAT PS2","UJI KOMPATIBILITAS","PUSTAKA GAME","FAVORIT","FOTO","VIDEO","ALAT LANJUTAN","PENGELOLA FILE","PENGATURAN","Pilih bahasa","Dunia MATRIX Anda","Tes perangkat","Kembali","Tutup","Bahasa"});
    tr.put("ms",new String[]{"LAMAN UTAMA","PUSAT PS2","UJIAN KESESUAIAN","PERPUSTAKAAN","KEGEMARAN","FOTO","VIDEO","ALAT LANJUTAN","PENGURUS FAIL","TETAPAN","Pilih bahasa","Dunia MATRIX anda","Ujian peranti","Kembali","Tutup","Bahasa"});
    tr.put("th",new String[]{"หน้าหลัก","ศูนย์ PS2","ทดสอบความเข้ากันได้","คลังเกม","รายการโปรด","รูปภาพ","วิดีโอ","เครื่องมือขั้นสูง","จัดการไฟล์","การตั้งค่า","เลือกภาษา","โลก MATRIX ของคุณ","ทดสอบอุปกรณ์","กลับ","ปิด","ภาษา"});
    tr.put("vi",new String[]{"TRANG CHỦ","TRUNG TÂM PS2","KIỂM TRA TƯƠNG THÍCH","THƯ VIỆN","YÊU THÍCH","ẢNH","VIDEO","CÔNG CỤ","QUẢN LÝ TỆP","CÀI ĐẶT","Chọn ngôn ngữ","Thế giới MATRIX","Kiểm tra thiết bị","Quay lại","Đóng","Ngôn ngữ"});
    tr.put("nl",new String[]{"START","PS2-CENTRUM","COMPATIBILITEITSTEST","BIBLIOTHEEK","FAVORIETEN","FOTO'S","VIDEO'S","HULPMIDDELEN","BESTANDEN","INSTELLINGEN","Kies taal","Jouw MATRIX-wereld","Apparaattest","Terug","Sluiten","Taal"});
    tr.put("pl",new String[]{"START","CENTRUM PS2","TEST ZGODNOŚCI","BIBLIOTEKA","ULUBIONE","ZDJĘCIA","WIDEO","NARZĘDZIA","PLIKI","USTAWIENIA","Wybierz język","Twój świat MATRIX","Test urządzenia","Wstecz","Zamknij","Język"});
    tr.put("uk",new String[]{"ГОЛОВНА","ЦЕНТР PS2","ТЕСТ СУМІСНОСТІ","БІБЛІОТЕКА","ОБРАНЕ","ФОТО","ВІДЕО","ІНСТРУМЕНТИ","ФАЙЛИ","НАЛАШТУВАННЯ","Оберіть мову","Твій світ MATRIX","Тест пристрою","Назад","Закрити","Мова"});
    tr.put("fa",new String[]{"خانه","مرکز PS2","آزمایش سازگاری","کتابخانه بازی","علاقه‌مندی‌ها","عکس‌ها","ویدیوها","ابزار پیشرفته","مدیریت فایل","تنظیمات","انتخاب زبان","دنیای MATRIX شما","آزمایش دستگاه","بازگشت","بستن","زبان"});
    tr.put("ur",new String[]{"ہوم","PS2 مرکز","مطابقت ٹیسٹ","گیم لائبریری","پسندیدہ","تصاویر","ویڈیوز","ایڈوانس ٹولز","فائل مینیجر","ترتیبات","زبان منتخب کریں","آپ کی MATRIX دنیا","ڈیوائس ٹیسٹ","واپس","بند کریں","زبان"});
    tr.put("bn",new String[]{"হোম","PS2 কেন্দ্র","সামঞ্জস্য পরীক্ষা","গেম লাইব্রেরি","প্রিয়","ছবি","ভিডিও","উন্নত সরঞ্জাম","ফাইল ম্যানেজার","সেটিংস","ভাষা নির্বাচন","আপনার MATRIX জগৎ","ডিভাইস পরীক্ষা","ফিরে যান","বন্ধ","ভাষা"});
    tr.put("sw",new String[]{"NYUMBANI","KITUO CHA PS2","JARIBIO LA UWEZO","MAKTABA YA MICHEZO","VIPENDWA","PICHA","VIDEO","ZANA ZA JUU","FAILI","MIPANGILIO","Chagua lugha","Ulimwengu wako wa MATRIX","Jaribio la kifaa","Rudi","Funga","Lugha"});
  }
  String s(int i){String[] a=tr.get(lang); if(a==null)a=tr.get("en"); return a[i];}
  GradientDrawable shape(int a,int b,int stroke){GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{a,b});d.setCornerRadius(25);d.setStroke(2,stroke);return d;}
  TextView txt(String v,int z,int c){TextView t=new TextView(this);t.setText(v);t.setTextColor(c);t.setTextSize(z);t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
  LinearLayout linear(boolean vertical){LinearLayout l=new LinearLayout(this);l.setOrientation(vertical?1:0);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
  @Override public void onCreate(Bundle b){super.onCreate(b);initTranslations();lang=getPreferences(0).getString("lang","ar");getWindow().setStatusBarColor(Color.rgb(2,5,15));getWindow().setNavigationBarColor(Color.rgb(2,5,15));
    musicEnabled=getPreferences(0).getBoolean("music_enabled",true);
    getPreferences(0).edit().putBoolean("music_enabled",musicEnabled).apply();
    clickEnabled=getPreferences(0).getBoolean("click_enabled",true);
    int savedTheme=getPreferences(0).getInt("theme",0);
    blue=new int[]{Color.rgb(0,155,255),Color.rgb(255,55,75),Color.rgb(175,85,255),Color.rgb(40,205,125),Color.rgb(255,170,35),Color.rgb(0,220,205)}[Math.max(0,Math.min(5,savedTheme))];
    darkMode=getPreferences(0).getBoolean("dark_mode",true);
    if(getPreferences(0).getBoolean("keep_awake",false))getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    musicVolume=getPreferences(0).getInt("music_volume",65);
    musicTrack=getPreferences(0).getInt("music_track",0);
    clickTone=new ToneGenerator(AudioManager.STREAM_SYSTEM,45);
    if(musicEnabled) startMusic();
    render();}
  void render(){
    FrameLayout root=new FrameLayout(this);ImageView bg=new ImageView(this);bg.setImageResource(R.drawable.matrix_wallpaper);bg.setScaleType(ImageView.ScaleType.CENTER_CROP);root.addView(bg,new FrameLayout.LayoutParams(-1,-1));
    View dim=new View(this);int dimAlpha=getPreferences(0).getBoolean("high_contrast",false)?242:(darkMode?228:150);dim.setBackgroundColor(darkMode?Color.argb(dimAlpha,0,0,0):Color.argb(dimAlpha,0,3,13));root.addView(dim,new FrameLayout.LayoutParams(-1,-1));
    ScrollView sc=new ScrollView(this);sc.setFillViewport(true);LinearLayout content=linear(true);content.setPadding(16,18,16,24);sc.addView(content);root.addView(sc);setContentView(root);page=content;
    LinearLayout top=linear(false);TextView brand=txt("♛ MATRIX",27,Color.WHITE);brand.setShadowLayer(18,0,0,blue);top.addView(brand,new LinearLayout.LayoutParams(0,-2,1));TextView gearBtn=txt("⚙",25,Color.WHITE);gearBtn.setGravity(Gravity.CENTER);gearBtn.setPadding(13,5,13,5);gearBtn.setBackground(shape(Color.rgb(8,45,78),Color.rgb(4,12,29),blue));gearBtn.setElevation(18);gearBtn.setOnClickListener(v->{click();showSettings();});top.addView(gearBtn);
    TextView langBtn=txt("🌐  "+flags[indexOf(lang)]+"  "+s(15)+"  ▾",13,Color.WHITE);langBtn.setPadding(13,12,13,12);langBtn.setBackground(shape(Color.rgb(5,34,65),Color.rgb(10,12,30),blue));langBtn.setOnClickListener(v->chooseLanguage());top.addView(langBtn);page.addView(top);
    TextView sub=txt("G A M I N G   O S   •   5.9",11,Color.LTGRAY);sub.setPadding(4,5,0,4);page.addView(sub);
    TextView hero=txt(s(11),24,Color.WHITE);hero.setGravity(Gravity.CENTER);hero.setShadowLayer(22,0,0,blue);hero.setPadding(4,24,4,7);page.addView(hero);
    TextView desc=txt("GHOST  •  PLAYSTATION 2  •  MATRIX",10,Color.LTGRAY);desc.setGravity(Gravity.CENTER);desc.setPadding(0,0,0,18);page.addView(desc);
    addSection(s(1)); addFeature("Ⅱ","PS2",s(1),blue,()->showPs2Console());
    addFeature("◈","CPU / RAM",s(2),red,()->test());
    addSection("MATRIX HUB");
    LinearLayout r1=linear(false);page.addView(r1);feature(r1,"▣",s(3),blue,()->openGameLibrary());feature(r1,"★",s(4),red,()->showFavorites());
    LinearLayout r2=linear(false);page.addView(r2);feature(r2,"▧",s(5),red,()->openMedia("image/*","اختيار صورة"));feature(r2,"▶",s(6),blue,()->openMedia("video/*","اختيار فيديو"));
    LinearLayout r3=linear(false);page.addView(r3);feature(r3,"⚙",s(7),blue,()->showTools());feature(r3,"☷",s(8),red,()->openFileManager());
    addSection(s(9));
    addFeature("⚙",s(9),"إعدادات MATRIX • MUSIC • SOUND",blue,()->showSettings());
    addFeature("🌐",s(15),"24 LANGUAGES",blue,()->chooseLanguage());
    TextView foot=txt("MATRIX GAMING 5.8   •   BUILT FOR GAMERS",9,Color.LTGRAY);foot.setGravity(Gravity.CENTER);foot.setPadding(0,22,0,0);page.addView(foot);
  }

  void showPs2Console(){
    final android.content.SharedPreferences prefs=getSharedPreferences("matrix_ps2_pad",MODE_PRIVATE);
    FrameLayout frame=new FrameLayout(this);frame.setBackgroundColor(Color.rgb(2,5,14));
    LinearLayout shell=linear(true);shell.setPadding(12,12,12,12);
    ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);frame.addView(scroll);
    scroll.addView(shell);
    LinearLayout head=linear(false);
    TextView back=txt("‹ رجوع",15,Color.WHITE);back.setPadding(8,8,12,8);
    back.setOnClickListener(v->{click();render();});head.addView(back);
    TextView title=txt("MATRIX PS2 • لوحة التحكم",16,Color.WHITE);
    head.addView(title,new LinearLayout.LayoutParams(0,-2,1));
    TextView save=txt("حفظ",13,Color.WHITE);save.setPadding(12,8,12,8);
    save.setBackground(shape(Color.rgb(8,65,95),Color.rgb(2,15,30),blue));
    head.addView(save);shell.addView(head);
    TextView screen=txt("MATRIX PS2\\nشاشة المحاكي",17,Color.WHITE);
    screen.setGravity(Gravity.CENTER);screen.setBackground(shape(Color.rgb(8,24,43),Color.rgb(2,8,18),blue));
    LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,155);sp.setMargins(0,10,0,10);shell.addView(screen,sp);
    TextView state=txt("آخر إدخال: —",11,Color.LTGRAY);state.setGravity(Gravity.CENTER);shell.addView(state);
    LinearLayout.LayoutParams rowP=new LinearLayout.LayoutParams(-1,-2);rowP.setMargins(0,8,0,4);
    LinearLayout gameActions=linear(false);gameActions.setGravity(Gravity.CENTER);shell.addView(gameActions,rowP);
    TextView addGame=txt("＋ إضافة لعبة PS2",12,Color.WHITE);addGame.setPadding(12,11,12,11);addGame.setBackground(shape(Color.rgb(5,65,105),Color.rgb(3,17,34),blue));gameActions.addView(addGame);
    TextView gamesList=txt("▤ مكتبة PS2",12,Color.WHITE);gamesList.setPadding(12,11,12,11);gamesList.setBackground(shape(Color.rgb(10,43,72),Color.rgb(3,12,27),blue));gameActions.addView(gamesList);
    addGame.setOnClickListener(v->{click();pickPs2Game();});
    gamesList.setOnClickListener(v->{click();showPs2Library();});
    TextView bios=txt("▣ إدارة BIOS",12,Color.WHITE);bios.setPadding(12,11,12,11);bios.setBackground(shape(Color.rgb(10,43,72),Color.rgb(3,12,27),blue));gameActions.addView(bios);bios.setOnClickListener(v->{click();showPs2BiosManager();});
    TextView note=txt("مرحلة 1: إدارة ملفات الألعاب • محرك المحاكاة لم يُدمج بعد",10,Color.YELLOW);
    note.setGravity(Gravity.CENTER);shell.addView(note);
    LinearLayout ps2Tools=linear(false);ps2Tools.setGravity(Gravity.CENTER);shell.addView(ps2Tools);
    addToolChip(ps2Tools,"🎨 الرسوميات",()->showPs2Graphics());
    addToolChip(ps2Tools,"💾 بطاقات الذاكرة",()->showMemoryCards());
    addToolChip(ps2Tools,"🎮 يد التحكم",()->showControllerCenter());
    LinearLayout options=linear(false);options.setGravity(Gravity.CENTER);
    shell.addView(options);
    TextView settings=txt("⚙ إعدادات الأزرار",12,Color.WHITE);settings.setPadding(10,8,10,8);
    settings.setBackground(shape(Color.rgb(10,43,72),Color.rgb(3,12,27),blue));options.addView(settings);
    TextView reset=txt("↺ استعادة",12,Color.WHITE);reset.setPadding(10,8,10,8);
    reset.setBackground(shape(Color.rgb(10,43,72),Color.rgb(3,12,27),blue));options.addView(reset);
    LinearLayout top=linear(false);top.setGravity(Gravity.CENTER);shell.addView(top,rowP);
    addPadButton(top,"L2","L2",state);addPadButton(top,"L1","L1",state);
    addPadButton(top,"R1","R1",state);addPadButton(top,"R2","R2",state);
    LinearLayout body=linear(false);body.setGravity(Gravity.CENTER);shell.addView(body,rowP);
    LinearLayout left=linear(true);left.setGravity(Gravity.CENTER);body.addView(left,new LinearLayout.LayoutParams(0,-2,1));
    LinearLayout right=linear(true);right.setGravity(Gravity.CENTER);body.addView(right,new LinearLayout.LayoutParams(0,-2,1));
    LinearLayout up=linear(false);up.setGravity(Gravity.CENTER);left.addView(up);
    LinearLayout lr=linear(false);lr.setGravity(Gravity.CENTER);left.addView(lr);
    LinearLayout dn=linear(false);dn.setGravity(Gravity.CENTER);left.addView(dn);
    addPadButton(up,"↑","UP",state);addPadButton(lr,"←","LEFT",state);addPadButton(lr,"L3","L3",state);addPadButton(lr,"→","RIGHT",state);addPadButton(dn,"↓","DOWN",state);
    LinearLayout r1=linear(false);r1.setGravity(Gravity.CENTER);right.addView(r1);
    LinearLayout r2=linear(false);r2.setGravity(Gravity.CENTER);right.addView(r2);
    addPadButton(r1,"△","TRIANGLE",state);addPadButton(r1,"○","CIRCLE",state);
    addPadButton(r2,"□","SQUARE",state);addPadButton(r2,"×","CROSS",state);
    LinearLayout sticks=linear(false);sticks.setGravity(Gravity.CENTER);shell.addView(sticks,rowP);
    addPadButton(sticks,"R3","R3",state);
    LinearLayout middle=linear(false);middle.setGravity(Gravity.CENTER);shell.addView(middle,rowP);
    addPadButton(middle,"SELECT","SELECT",state);addPadButton(middle,"START","START",state);
    LinearLayout extra=linear(false);extra.setGravity(Gravity.CENTER);shell.addView(extra,rowP);
    addPadButton(extra,"TURBO","TURBO",state);addPadButton(extra,"مركز","CENTER",state);
    save.setOnClickListener(v->{click();prefs.edit().putBoolean("layout_saved",true).putInt("button_size",prefs.getInt("button_size",48)).apply();dialog("تم الحفظ","تم حفظ إعدادات لوحة التحكم على هذا الجهاز.");});
    reset.setOnClickListener(v->{click();prefs.edit().clear().apply();dialog("استعادة","تمت استعادة إعدادات لوحة التحكم الافتراضية. أعد فتح اللوحة لتطبيقها.");});
    settings.setOnClickListener(v->{click();LinearLayout box=linear(true);box.setPadding(16,8,16,8);
      TextView sizeLabel=txt("حجم الأزرار",14,Color.WHITE);box.addView(sizeLabel);
      SeekBar size=new SeekBar(this);size.setMax(48);size.setProgress(prefs.getInt("button_size",48)-32);box.addView(size);
      TextView opacityLabel=txt("شفافية الأزرار",14,Color.WHITE);box.addView(opacityLabel);
      SeekBar opacity=new SeekBar(this);opacity.setMax(100);opacity.setProgress(prefs.getInt("button_opacity",90));box.addView(opacity);
      new AlertDialog.Builder(this).setTitle("إعدادات لوحة التحكم").setView(box).setPositiveButton("حفظ",(d,w)->prefs.edit().putInt("button_size",32+size.getProgress()).putInt("button_opacity",opacity.getProgress()).apply()).setNegativeButton("إلغاء",null).show();
    });
    setContentView(frame);
  }
  void addPadButton(LinearLayout parent,String label,String code,TextView state){
    android.content.SharedPreferences padPrefs=getSharedPreferences("matrix_ps2_pad",MODE_PRIVATE);
    int buttonSize=padPrefs.getInt("button_size",48), opacity=padPrefs.getInt("button_opacity",90);
    TextView b=txt(label, label.length()>2?10:17,Color.WHITE);b.setGravity(Gravity.CENTER);b.setAlpha(Math.max(.2f,opacity/100f));
    b.setBackground(shape(Color.rgb(10,43,72),Color.rgb(3,12,27),blue));b.setElevation(8);
    LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(label.length()>2?buttonSize+20:buttonSize,buttonSize);
    p.setMargins(3,3,3,3);parent.addView(b,p);
    b.setOnTouchListener((v,event)->{
      if(event.getAction()==MotionEvent.ACTION_DOWN){click();if(getPreferences(0).getBoolean("vibration",false))v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);v.animate().scaleX(.93f).scaleY(.93f).setDuration(60).start();state.setText("آخر إدخال: "+code+" • DOWN");return true;}
      if(event.getAction()==MotionEvent.ACTION_UP || event.getAction()==MotionEvent.ACTION_CANCEL){v.animate().scaleX(1f).scaleY(1f).setDuration(70).start();state.setText("آخر إدخال: "+code+" • UP");return true;}
      return true;
    });
  }
  int indexOf(String c){for(int i=0;i<codes.length;i++)if(codes[i].equals(c))return i;return 1;}
  void addSection(String t){TextView x=txt(t,15,Color.WHITE);x.setPadding(4,18,4,9);page.addView(x);}
  void addFeature(String icon,String title,String sub,int color,Runnable run){LinearLayout holder=linear(true);holder.setPadding(18,15,18,15);holder.setBackground(shape(Color.argb(235,7,27,52),Color.argb(245,3,7,18),color));holder.setElevation(14);TextView i=txt(icon,28,color);holder.addView(i);TextView h=txt(title,15,Color.WHITE);h.setPadding(0,5,0,2);holder.addView(h);TextView d=txt(sub,10,Color.LTGRAY);holder.addView(d);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(2,6,2,7);page.addView(holder,p);animate(holder,run);}
  void feature(LinearLayout row,String icon,String title,int color){feature(row,icon,title,color,()->dialog(title,"هذه الميزة غير مفعلة بعد."));}
  void feature(LinearLayout row,String icon,String title,int color,Runnable action){LinearLayout h=linear(true);h.setGravity(Gravity.CENTER);h.setPadding(8,16,8,16);h.setBackground(shape(Color.rgb(9,29,54),Color.rgb(3,8,20),color));h.setElevation(12);h.addView(txt(icon,27,color));TextView t=txt(title,11,Color.WHITE);t.setGravity(Gravity.CENTER);t.setPadding(0,7,0,0);h.addView(t);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,112,1);p.setMargins(5,5,5,5);row.addView(h,p);animate(h,action);}
  void click(){if(clickEnabled && clickTone!=null) clickTone.startTone(ToneGenerator.TONE_PROP_BEEP,55);}
  void startMusic(){
    try{
      if(musicPlayer!=null){musicPlayer.release();musicPlayer=null;}
      int trackRes=musicTrack==0?R.raw.matrix_battlefield_theme:R.raw.battlefield1_classic_theme;
      musicPlayer=MediaPlayer.create(this,trackRes);
      if(musicPlayer==null)return;
      musicPlayer.setLooping(true);
      musicPlayer.setVolume(musicVolume/100f,musicVolume/100f);
      if(musicEnabled)musicPlayer.start();
    }catch(Exception e){dialog("Music","تعذر تشغيل الموسيقى: "+e.getMessage());}
  }
  void stopMusic(){try{if(musicPlayer!=null && musicPlayer.isPlaying())musicPlayer.pause();}catch(Exception e){}}
  void showSettings(){
    final android.content.SharedPreferences prefs=getPreferences(0);
    LinearLayout box=linear(true);box.setPadding(20,12,20,8);
    TextView heading=txt("إعدادات MATRIX GAMING",19,Color.WHITE);box.addView(heading);
    TextView general=txt("━━ عام ━━",12,blue);general.setPadding(0,14,0,5);box.addView(general);
    Switch music=new Switch(this);music.setText("تشغيل الموسيقى تلقائياً");music.setTextColor(Color.WHITE);music.setChecked(musicEnabled);box.addView(music);
    TextView trackLabel=txt("الموسيقى الخلفية",13,Color.LTGRAY);trackLabel.setPadding(0,10,0,3);box.addView(trackLabel);
    Spinner tracks=new Spinner(this);String[] trackNames={"Battlefield 1942 Theme","Battlefield 1 Classic Theme"};
    tracks.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,trackNames));tracks.setSelection(musicTrack);box.addView(tracks);
    TextView volLabel=txt("مستوى صوت الموسيقى: "+musicVolume+"%",13,Color.LTGRAY);volLabel.setPadding(0,8,0,2);box.addView(volLabel);
    SeekBar volume=new SeekBar(this);volume.setMax(100);volume.setProgress(musicVolume);box.addView(volume);
    Switch clicks=new Switch(this);clicks.setText("صوت عند الضغط على الأزرار");clicks.setTextColor(Color.WHITE);clicks.setChecked(clickEnabled);clicks.setPadding(0,8,0,2);box.addView(clicks);
    Switch vibration=new Switch(this);vibration.setText("اهتزاز خفيف عند اللمس");vibration.setTextColor(Color.WHITE);vibration.setChecked(prefs.getBoolean("vibration",false));box.addView(vibration);
    Switch animations=new Switch(this);animations.setText("الحركات والانتقالات");animations.setTextColor(Color.WHITE);animations.setChecked(prefs.getBoolean("animations",true));box.addView(animations);
    Switch keepAwake=new Switch(this);keepAwake.setText("منع إطفاء الشاشة داخل التطبيق");keepAwake.setTextColor(Color.WHITE);keepAwake.setChecked(prefs.getBoolean("keep_awake",false));box.addView(keepAwake);
    TextView appearance=txt("━━ المظهر ━━",12,blue);appearance.setPadding(0,14,0,5);box.addView(appearance);
    Spinner themes=new Spinner(this);String[] themeNames={"أزرق MATRIX","أحمر","بنفسجي","أخضر","ذهبي","تركوازي"};themes.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,themeNames));themes.setSelection(prefs.getInt("theme",0));box.addView(themes);
    Switch dark=new Switch(this);dark.setText("الوضع الأسود الداكن بالكامل");dark.setTextColor(Color.WHITE);dark.setChecked(prefs.getBoolean("dark_mode",true));dark.setPadding(0,10,0,4);box.addView(dark);
    Switch highContrast=new Switch(this);highContrast.setText("تباين أعلى ووضوح النصوص");highContrast.setTextColor(Color.WHITE);highContrast.setChecked(prefs.getBoolean("high_contrast",false));box.addView(highContrast);
    Switch reduceMotion=new Switch(this);reduceMotion.setText("تقليل الحركات لتخفيف الحمل");reduceMotion.setTextColor(Color.WHITE);reduceMotion.setChecked(prefs.getBoolean("reduce_motion",false));box.addView(reduceMotion);
    TextView language=txt("🌐 اللغة: "+flags[indexOf(lang)]+" "+languageNames[indexOf(lang)],14,Color.WHITE);language.setPadding(0,14,0,10);box.addView(language);
    language.setOnClickListener(v->{click();chooseLanguage();});
    TextView ps2=txt("━━ إعدادات PS2 ━━",12,blue);ps2.setPadding(0,14,0,5);box.addView(ps2);
    TextView pad=txt("🎮 تخصيص أزرار التحكم (الحجم والشفافية)",13,Color.WHITE);pad.setPadding(10,12,10,12);pad.setBackground(shape(Color.rgb(8,35,60),Color.rgb(3,10,22),blue));box.addView(pad);
    pad.setOnClickListener(v->{click();showPadSettings();});
    TextView extra=txt("━━ أدوات MATRIX الإضافية ━━",12,blue);extra.setPadding(0,14,0,5);box.addView(extra);
    addSettingsAction(box,"🚀 Game Booster • معلومات الأداء",()->showGameBooster());
    addSettingsAction(box,"💾 النسخ الاحتياطي والاستعادة",()->showBackupCenter());
    addSettingsAction(box,"🔄 مركز التحديثات",()->showUpdateCenter());
    addSettingsAction(box,"🎮 مركز يد التحكم",()->showControllerCenter());
    TextView about=txt("━━ معلومات ━━",12,blue);about.setPadding(0,14,0,5);box.addView(about);
    TextView info=txt("MATRIX GAMING 5.13\nPS2 tools • Android project\nالمحاكي غير مدمج بعد",11,Color.LTGRAY);box.addView(info);
    music.setOnCheckedChangeListener((b,on)->{musicEnabled=on;prefs.edit().putBoolean("music_enabled",on).apply();if(on){if(musicPlayer==null)startMusic();else if(!musicPlayer.isPlaying())musicPlayer.start();}else stopMusic();});
    tracks.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?> parent,View view,int position,long id){if(musicTrack!=position){musicTrack=position;prefs.edit().putInt("music_track",musicTrack).apply();if(musicEnabled)startMusic();}}public void onNothingSelected(android.widget.AdapterView<?> parent){}});
    volume.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int value,boolean user){musicVolume=value;volLabel.setText("مستوى صوت الموسيقى: "+value+"%");if(musicPlayer!=null)musicPlayer.setVolume(value/100f,value/100f);}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){prefs.edit().putInt("music_volume",musicVolume).apply();}});
    clicks.setOnCheckedChangeListener((b,on)->{clickEnabled=on;prefs.edit().putBoolean("click_enabled",on).apply();});
    new AlertDialog.Builder(this).setView(box).setPositiveButton("حفظ وإغلاق",(d,w)->{
      int theme=themes.getSelectedItemPosition();darkMode=dark.isChecked();prefs.edit().putInt("music_volume",musicVolume).putBoolean("vibration",vibration.isChecked()).putBoolean("animations",animations.isChecked()).putBoolean("keep_awake",keepAwake.isChecked()).putBoolean("dark_mode",darkMode).putBoolean("high_contrast",highContrast.isChecked()).putBoolean("reduce_motion",reduceMotion.isChecked()).putInt("theme",theme).apply();
      blue=new int[]{Color.rgb(0,155,255),Color.rgb(255,55,75),Color.rgb(175,85,255),Color.rgb(40,205,125),Color.rgb(255,170,35),Color.rgb(0,220,205)}[theme];
      getWindow().setStatusBarColor(darkMode?Color.BLACK:Color.rgb(2,5,15));getWindow().setNavigationBarColor(darkMode?Color.BLACK:Color.rgb(2,5,15));
      if(keepAwake.isChecked())getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
      render();dialog("تم حفظ الإعدادات","تم حفظ المظهر والألوان والإعدادات الجديدة.");
    }).setNegativeButton("إغلاق",null).show();
  }
  void showPadSettings(){
    final android.content.SharedPreferences p=getSharedPreferences("matrix_ps2_pad",MODE_PRIVATE);
    LinearLayout box=linear(true);box.setPadding(18,8,18,8);
    TextView sizeText=txt("حجم الأزرار: "+p.getInt("button_size",48),13,Color.WHITE);box.addView(sizeText);
    SeekBar size=new SeekBar(this);size.setMax(48);size.setProgress(Math.max(0,p.getInt("button_size",48)-32));box.addView(size);
    size.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int v,boolean u){sizeText.setText("حجم الأزرار: "+(32+v));}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});
    TextView opacityText=txt("شفافية الأزرار: "+p.getInt("button_opacity",90)+"%",13,Color.WHITE);opacityText.setPadding(0,12,0,0);box.addView(opacityText);
    SeekBar opacity=new SeekBar(this);opacity.setMax(100);opacity.setProgress(p.getInt("button_opacity",90));box.addView(opacity);
    opacity.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int v,boolean u){opacityText.setText("شفافية الأزرار: "+v+"%");}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});
    new AlertDialog.Builder(this).setTitle("تخصيص يد PS2").setView(box).setPositiveButton("حفظ",(d,w)->{p.edit().putInt("button_size",32+size.getProgress()).putInt("button_opacity",opacity.getProgress()).apply();dialog("تم الحفظ","إعدادات الأزرار محفوظة. افتح لوحة PS2 من جديد لتطبيقها.");}).setNegativeButton("إلغاء",null).show();
  }
  @Override protected void onResume(){super.onResume();if(musicEnabled){if(musicPlayer==null)startMusic();else if(!musicPlayer.isPlaying())musicPlayer.start();}}
  @Override protected void onStop(){super.onStop();stopMusic();}
  @Override protected void onDestroy(){super.onDestroy();try{if(musicPlayer!=null){musicPlayer.release();musicPlayer=null;}if(clickTone!=null)clickTone.release();}catch(Exception e){}}
  void animate(View v,Runnable r){if(getPreferences(0).getBoolean("reduce_motion",false)){v.setOnClickListener(w->{click();r.run();});return;}v.setOnTouchListener((view,event)->{if(event.getAction()==0){view.animate().scaleX(.96f).scaleY(.96f).setDuration(90).start();}else if(event.getAction()==1){click();view.animate().scaleX(1f).scaleY(1f).setDuration(150).start();r.run();}else if(event.getAction()==3){view.animate().scaleX(1f).scaleY(1f).setDuration(150).start();}return true;});}

  static final int REQ_GAME=7101, REQ_IMAGE=7102, REQ_VIDEO=7103, REQ_FILE=7104, REQ_PS2_GAME=7105, REQ_PS2_BIOS=7106, REQ_BACKUP=7107, REQ_RESTORE=7108, REQ_COVER=7109;
  String pendingCoverGame="";
  ArrayList<String> selectedGames=new ArrayList<>();
  void openGameLibrary(){ renderGameLibrary(); }
  void pickGameFile(){
    Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.addCategory(Intent.CATEGORY_OPENABLE);
    i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/octet-stream","application/x-cd-image","application/zip"});
    startActivityForResult(i,REQ_GAME);
  }
  String[] savedUris(){String raw=getSharedPreferences("matrix_library",MODE_PRIVATE).getString("games","");return raw.trim().isEmpty()?new String[0]:raw.split("\\n");}
  Set<String> favoriteUris(){String raw=getSharedPreferences("matrix_library",MODE_PRIVATE).getString("favorites","");Set<String> out=new HashSet<>();if(!raw.trim().isEmpty())out.addAll(Arrays.asList(raw.split("\\n")));return out;}
  void storeLines(String key,Collection<String> values){StringBuilder b=new StringBuilder();for(String v:values){if(v==null||v.trim().isEmpty())continue;if(b.length()>0)b.append('\n');b.append(v);}getSharedPreferences("matrix_library",MODE_PRIVATE).edit().putString(key,b.toString()).apply();}
  void renderGameLibrary(){
    FrameLayout frame=new FrameLayout(this);frame.setBackgroundColor(Color.rgb(2,5,14));
    LinearLayout box=linear(true);box.setPadding(16,14,16,18);ScrollView scroll=new ScrollView(this);scroll.addView(box);frame.addView(scroll);
    LinearLayout head=linear(false);TextView back=txt("‹ رجوع",14,Color.WHITE);back.setPadding(8,10,16,10);back.setOnClickListener(v->render());head.addView(back);
    TextView title=txt("مكتبة ألعاب MATRIX",18,Color.WHITE);head.addView(title,new LinearLayout.LayoutParams(0,-2,1));box.addView(head);
    EditText search=new EditText(this);search.setSingleLine(true);search.setHint("ابحث باسم ملف اللعبة...");search.setTextColor(Color.WHITE);search.setHintTextColor(Color.LTGRAY);search.setBackground(shape(Color.rgb(8,25,45),Color.rgb(3,9,20),blue));box.addView(search,new LinearLayout.LayoutParams(-1,-2));
    TextView add=txt("＋ إضافة ملف لعبة",14,Color.WHITE);add.setGravity(Gravity.CENTER);add.setPadding(12,14,12,14);add.setBackground(shape(Color.rgb(5,65,105),Color.rgb(3,17,34),blue));LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-1,-2);ap.setMargins(0,10,0,10);box.addView(add,ap);add.setOnClickListener(v->{click();pickGameFile();});
    LinearLayout items=linear(true);box.addView(items);
    final Runnable[] refreshRef=new Runnable[1];refreshRef[0]=()->{items.removeAllViews();String[] uris=savedUris();Set<String> fav=favoriteUris();String q=search.getText().toString().toLowerCase(Locale.ROOT);int shown=0;
      for(String raw:uris){Uri u=Uri.parse(raw);String name=displayName(u);if(!name.toLowerCase(Locale.ROOT).contains(q))continue;shown++;
        LinearLayout card=linear(true);card.setPadding(12,10,12,10);card.setBackground(shape(Color.rgb(8,27,49),Color.rgb(3,9,20),fav.contains(raw)?red:blue));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(0,5,0,5);items.addView(card,cp);
        TextView nm=txt(name,13,Color.WHITE);card.addView(nm);TextView info=txt("ملف محفوظ • لا يتوفر تشغيل PS2 قبل دمج المحرك",9,Color.LTGRAY);info.setPadding(0,4,0,7);card.addView(info);
        LinearLayout actions=linear(false);card.addView(actions);TextView favorite=txt(fav.contains(raw)?"★ إزالة من المفضلة":"☆ إضافة للمفضلة",11,Color.YELLOW);favorite.setPadding(8,7,12,7);actions.addView(favorite);favorite.setOnClickListener(v->{Set<String> f=favoriteUris();if(!f.add(raw))f.remove(raw);storeLines("favorites",f);refreshRef[0].run();});
        TextView remove=txt("حذف من المكتبة",11,Color.RED);remove.setPadding(12,7,8,7);actions.addView(remove);remove.setOnClickListener(v->new AlertDialog.Builder(this).setMessage("حذف الملف من قائمة MATRIX فقط؟ لن يُحذف الملف الأصلي من الهاتف.").setNegativeButton("إلغاء",null).setPositiveButton("حذف",(d,w)->{ArrayList<String> list=new ArrayList<>(Arrays.asList(savedUris()));list.remove(raw);storeLines("games",list);Set<String> f=favoriteUris();f.remove(raw);storeLines("favorites",f);refreshRef[0].run();}).show());
      }
      if(shown==0){TextView empty=txt(uris.length==0?"مكتبتك فارغة. اضغط إضافة ملف لعبة.":"ماكو نتائج تطابق البحث.",12,Color.LTGRAY);empty.setPadding(5,18,5,18);items.addView(empty);}
    };search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){refreshRef[0].run();}public void afterTextChanged(android.text.Editable e){}});refreshRef[0].run();setContentView(frame);
  }
  void pickPs2Game(){
    Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.addCategory(Intent.CATEGORY_OPENABLE);
    i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/octet-stream","application/x-cd-image"});
    startActivityForResult(i,REQ_PS2_GAME);
  }
  ArrayList<String> ps2Uris(){
    String raw=getSharedPreferences("matrix_ps2_library",MODE_PRIVATE).getString("games","");
    ArrayList<String> out=new ArrayList<>();if(!raw.trim().isEmpty())out.addAll(Arrays.asList(raw.split("\\n")));return out;
  }
  Set<String> ps2Favorites(){String raw=getSharedPreferences("matrix_ps2_library",MODE_PRIVATE).getString("favorites","");Set<String> out=new HashSet<>();if(!raw.trim().isEmpty())out.addAll(Arrays.asList(raw.split("\\n")));return out;}
  void savePs2Lines(String key,Collection<String> values){StringBuilder b=new StringBuilder();for(String x:values){if(x==null||x.trim().isEmpty())continue;if(b.length()>0)b.append('\n');b.append(x);}getSharedPreferences("matrix_ps2_library",MODE_PRIVATE).edit().putString(key,b.toString()).apply();}
  String ps2FileSize(Uri uri){Cursor c=null;try{c=getContentResolver().query(uri,new String[]{OpenableColumns.SIZE},null,null,null);if(c!=null&&c.moveToFirst()){int i=c.getColumnIndex(OpenableColumns.SIZE);if(i>=0&&!c.isNull(i)){long n=c.getLong(i);if(n>=1024L*1024L*1024L)return String.format(Locale.US,"%.2f GB",n/(1024d*1024d*1024d));if(n>=1024L*1024L)return String.format(Locale.US,"%.1f MB",n/(1024d*1024d));return (n/1024L)+" KB";}}}catch(Exception ignored){}finally{if(c!=null)c.close();}return "الحجم غير معروف";}
  boolean canReadPs2(Uri uri){try{android.os.ParcelFileDescriptor fd=getContentResolver().openFileDescriptor(uri,"r");if(fd==null)return false;fd.close();return true;}catch(Exception e){return false;}}
  void showPs2BiosManager(){
    android.content.SharedPreferences p=getSharedPreferences("matrix_ps2_library",MODE_PRIVATE);String saved=p.getString("bios_uri","");
    LinearLayout box=linear(true);box.setPadding(18,12,18,12);
    box.addView(txt("إدارة BIOS الخاص بجهازك",17,Color.WHITE));
    box.addView(txt("اختر ملف BIOS مستخرجاً من جهاز PS2 تملكه. لا يتضمن التطبيق BIOS ولا يوفّره.",11,Color.LTGRAY));
    TextView current=txt(saved.isEmpty()?"الحالة: لم يتم اختيار BIOS":"الملف الحالي: "+displayName(Uri.parse(saved)),12, saved.isEmpty()?Color.YELLOW:Color.GREEN);current.setPadding(0,12,0,12);box.addView(current);
    TextView choose=txt("＋ اختيار ملف BIOS",13,Color.WHITE);choose.setPadding(12,12,12,12);choose.setBackground(shape(Color.rgb(5,65,105),Color.rgb(3,17,34),blue));box.addView(choose);choose.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,REQ_PS2_BIOS);});
    new AlertDialog.Builder(this).setTitle("PS2 BIOS Manager").setView(box).setPositiveButton("إغلاق",null).setNeutralButton("إزالة الربط",(d,w)->{p.edit().remove("bios_uri").apply();dialog("تم","تم إلغاء ربط ملف BIOS من التطبيق فقط.");}).show();
  }
  void showPs2Library(){
    FrameLayout frame=new FrameLayout(this);frame.setBackgroundColor(Color.rgb(2,5,14));
    LinearLayout box=linear(true);box.setPadding(16,14,16,18);ScrollView scroll=new ScrollView(this);scroll.addView(box);frame.addView(scroll);
    LinearLayout head=linear(false);TextView back=txt("‹ رجوع",14,Color.WHITE);back.setPadding(8,10,16,10);back.setOnClickListener(v->showPs2Console());head.addView(back);
    TextView title=txt("مكتبة ألعاب PS2",18,Color.WHITE);head.addView(title);box.addView(head);
    TextView summary=txt("الألعاب: "+ps2Uris().size()+"  •  المفضلة: "+ps2Favorites().size(),11,Color.CYAN);summary.setPadding(3,5,3,9);box.addView(summary);
    EditText search=new EditText(this);search.setSingleLine(true);search.setTextColor(Color.WHITE);search.setHintTextColor(Color.LTGRAY);search.setHint("ابحث باسم اللعبة أو الملف...");search.setBackground(shape(Color.rgb(8,25,45),Color.rgb(3,9,20),blue));box.addView(search,new LinearLayout.LayoutParams(-1,-2));
    LinearLayout tools=linear(false);tools.setGravity(Gravity.CENTER_VERTICAL);box.addView(tools);
    TextView add=txt("＋ استيراد لعبة",13,Color.WHITE);add.setPadding(10,12,10,12);add.setBackground(shape(Color.rgb(5,65,105),Color.rgb(3,17,34),blue));tools.addView(add);add.setOnClickListener(v->pickPs2Game());
    TextView bios=txt("BIOS",12,Color.WHITE);bios.setPadding(14,12,14,12);tools.addView(bios);bios.setOnClickListener(v->showPs2BiosManager());
    Spinner filter=new Spinner(this);String[] modes={"كل الألعاب","المفضلة فقط"};filter.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,modes));tools.addView(filter,new LinearLayout.LayoutParams(0,-2,1));
    LinearLayout items=linear(true);box.addView(items);
    final Runnable[] refresh=new Runnable[1];refresh[0]=()->{
      items.removeAllViews();ArrayList<String> games=ps2Uris();Set<String> fav=ps2Favorites();String q=search.getText().toString().toLowerCase(Locale.ROOT);int shown=0;
      for(String raw:games){Uri uri=Uri.parse(raw);String name=displayName(uri);if(!name.toLowerCase(Locale.ROOT).contains(q))continue;if(filter.getSelectedItemPosition()==1&&!fav.contains(raw))continue;shown++;
        LinearLayout card=linear(true);card.setPadding(13,11,13,11);card.setBackground(shape(Color.rgb(8,27,49),Color.rgb(3,9,20),fav.contains(raw)?red:blue));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(0,6,0,6);items.addView(card,cp);
        card.addView(txt("🎮  "+name,14,Color.WHITE));card.addView(txt(ps2FileSize(uri)+"  •  "+(canReadPs2(uri)?"الملف قابل للقراءة":"تعذر الوصول للملف"),10,canReadPs2(uri)?Color.LTGRAY:Color.YELLOW));
        String coverUri=getSharedPreferences("matrix_ps2_library",MODE_PRIVATE).getString("cover_"+raw,"");if(!coverUri.isEmpty())card.addView(txt("🖼 غلاف مخصص مرتبط",9,Color.MAGENTA));
        card.addView(txt("الصيغة: "+name.substring(name.lastIndexOf('.')>=0?name.lastIndexOf('.')+1:name.length()).toUpperCase(Locale.ROOT)+"  •  التشغيل ينتظر دمج المحرك",9,Color.LTGRAY));
        LinearLayout actions=linear(false);card.addView(actions);
        TextView star=txt(fav.contains(raw)?"★ مفضلة":"☆ أضف للمفضلة",11,Color.YELLOW);star.setPadding(7,9,12,7);actions.addView(star);star.setOnClickListener(v->{Set<String> f=ps2Favorites();if(!f.add(raw))f.remove(raw);savePs2Lines("favorites",f);refresh[0].run();});
        TextView details=txt("تفاصيل",11,Color.CYAN);details.setPadding(9,9,12,7);actions.addView(details);details.setOnClickListener(v->{String msg="الاسم: "+name+"\nالحجم: "+ps2FileSize(uri)+"\nالصيغة: "+(name.contains(".")?name.substring(name.lastIndexOf('.')+1):"غير معروفة")+"\nإمكانية القراءة: "+(canReadPs2(uri)?"نعم":"لا")+"\n\nالمحرك غير مدمج بعد؛ لا يمكن تشغيل اللعبة حالياً.";new AlertDialog.Builder(this).setTitle("معلومات اللعبة").setMessage(msg).setPositiveButton("حسناً",null).show();});
        TextView cover=txt("غلاف",11,Color.MAGENTA);cover.setPadding(9,9,12,7);actions.addView(cover);cover.setOnClickListener(v->{pendingCoverGame=raw;Intent pick=new Intent(Intent.ACTION_OPEN_DOCUMENT);pick.setType("image/*");pick.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(pick,REQ_COVER);});
        TextView remove=txt("إزالة",11,Color.RED);remove.setPadding(9,9,7,7);actions.addView(remove);remove.setOnClickListener(v->new AlertDialog.Builder(this).setMessage("إزالة اللعبة من مكتبة MATRIX فقط؟ لن يُحذف الملف الأصلي.").setNegativeButton("إلغاء",null).setPositiveButton("إزالة",(d,w)->{ArrayList<String> list=ps2Uris();list.remove(raw);savePs2Lines("games",list);Set<String> f=ps2Favorites();f.remove(raw);savePs2Lines("favorites",f);refresh[0].run();}).show());
      }
      if(shown==0)items.addView(txt(games.isEmpty()?"المكتبة فارغة. استورد ملف لعبة تملكه.":"لا توجد نتائج مطابقة.",12,Color.LTGRAY));
    };
    search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){refresh[0].run();}public void afterTextChanged(android.text.Editable e){}});
    filter.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?> a,View v,int pos,long id){refresh[0].run();}public void onNothingSelected(android.widget.AdapterView<?> a){}});
    refresh[0].run();setContentView(frame);
  }
  boolean isSupportedPs2File(String name){String n=name.toLowerCase(Locale.ROOT);return n.endsWith(".iso")||n.endsWith(".chd")||n.endsWith(".cso")||n.endsWith(".cue")||n.endsWith(".elf")||n.endsWith(".isz");}
  void openMedia(String type,String title){
    Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType(type);i.addCategory(Intent.CATEGORY_OPENABLE);
    startActivityForResult(i,type.startsWith("image")?REQ_IMAGE:REQ_VIDEO);
  }
  void openFileManager(){
    Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.addCategory(Intent.CATEGORY_OPENABLE);
    startActivityForResult(i,REQ_FILE);
  }
  String displayName(Uri uri){
    Cursor c=null;try{c=getContentResolver().query(uri,null,null,null,null);if(c!=null&&c.moveToFirst()){int n=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(n>=0)return c.getString(n);}}catch(Exception e){}finally{if(c!=null)c.close();}return uri.getLastPathSegment();
  }
  @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
    super.onActivityResult(requestCode,resultCode,data);
    if(resultCode!=RESULT_OK||data==null||data.getData()==null)return;
    Uri uri=data.getData();String name=displayName(uri);
    if(requestCode==REQ_PS2_BIOS){
      try{int flags=data.getFlags()&(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);getContentResolver().takePersistableUriPermission(uri,flags);}catch(Exception ignored){}
      getSharedPreferences("matrix_ps2_library",MODE_PRIVATE).edit().putString("bios_uri",uri.toString()).apply();
      dialog("تم ربط BIOS",name+"\nتم حفظ رابط الملف. تأكد أنه مستخرج من جهاز PS2 تملكه. لم يتم اختبار تشغيل المحرك بعد.");
    }else if(requestCode==REQ_PS2_GAME){
      if(!isSupportedPs2File(name)){dialog("صيغة غير معروفة","الملف المحدد ليس من الصيغ المعروفة لمكتبة PS2: ISO, CHD, CSO, CUE, ELF, ISZ.");return;}
      try{int flags=data.getFlags()&(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);getContentResolver().takePersistableUriPermission(uri,flags);}catch(Exception ignored){}
      ArrayList<String> list=ps2Uris();if(!list.contains(uri.toString()))list.add(uri.toString());StringBuilder b=new StringBuilder();for(String x:list){if(b.length()>0)b.append('\n');b.append(x);}getSharedPreferences("matrix_ps2_library",MODE_PRIVATE).edit().putString("games",b.toString()).apply();
      dialog("تم استيراد اللعبة",name+"\nأُضيفت إلى مكتبة PS2. التشغيل الفعلي يحتاج دمج محرك المحاكاة واختباره بعد.");
    }else if(requestCode==REQ_COVER){
      try{int flags=data.getFlags()&(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);getContentResolver().takePersistableUriPermission(uri,flags);}catch(Exception ignored){}
      getSharedPreferences("matrix_ps2_library",MODE_PRIVATE).edit().putString("cover_"+pendingCoverGame,uri.toString()).apply();
      dialog("تم حفظ الغلاف",name+"\nتم ربط صورة الغلاف بهذه اللعبة داخل المكتبة.");pendingCoverGame="";
    }else if(requestCode==REQ_BACKUP){
      try{String backup=buildBackupText();java.io.OutputStream out=getContentResolver().openOutputStream(uri);if(out==null)throw new Exception("تعذر فتح ملف النسخة الاحتياطية");out.write(backup.getBytes("UTF-8"));out.close();dialog("اكتمل النسخ الاحتياطي","تم تصدير إعدادات MATRIX وروابط المكتبات إلى الملف المحدد.");}catch(Exception e){dialog("فشل النسخ الاحتياطي",String.valueOf(e.getMessage()));}
    }else if(requestCode==REQ_RESTORE){
      try{java.io.InputStream in=getContentResolver().openInputStream(uri);java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream();byte[] buf=new byte[4096];int n;while((n=in.read(buf))>0)out.write(buf,0,n);in.close();String dataText=new String(out.toByteArray(),"UTF-8");restoreBackupText(dataText);}catch(Exception e){dialog("تعذر الاستعادة",String.valueOf(e.getMessage()));}
    }else if(requestCode==REQ_GAME){
      try{int flags=data.getFlags()&(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);getContentResolver().takePersistableUriPermission(uri,flags);}catch(Exception ignored){}
      android.content.SharedPreferences p=getSharedPreferences("matrix_library",MODE_PRIVATE);
      String old=p.getString("games","");
      if(!Arrays.asList(old.split("\\n")).contains(uri.toString()))p.edit().putString("games",old+(old.isEmpty()?"":"\n")+uri.toString()).apply();
      dialog("تمت إضافة الملف",name+"\nتم حفظه في المكتبة. افتح المكتبة للبحث أو إضافته للمفضلة. تشغيل ألعاب PS2 ينتظر دمج المحرك.");
    }else if(requestCode==REQ_IMAGE||requestCode==REQ_VIDEO){
      Intent view=new Intent(Intent.ACTION_VIEW);view.setDataAndType(uri,requestCode==REQ_IMAGE?"image/*":"video/*");view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
      try{startActivity(view);}catch(Exception e){dialog("تعذر الفتح",e.getMessage());}
    }else if(requestCode==REQ_FILE){
      dialog("مدير الملفات",name+"\n"+uri.toString());
    }
  }
  void addToolChip(LinearLayout parent,String label,Runnable action){TextView t=txt(label,11,Color.WHITE);t.setPadding(10,10,10,10);t.setBackground(shape(Color.rgb(8,42,70),Color.rgb(3,12,27),blue));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);lp.setMargins(3,5,3,5);parent.addView(t,lp);t.setOnClickListener(v->{click();action.run();});}
  void addSettingsAction(LinearLayout parent,String label,Runnable action){TextView t=txt(label,13,Color.WHITE);t.setPadding(12,13,12,13);t.setBackground(shape(Color.rgb(8,35,60),Color.rgb(3,10,22),blue));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,4,0,4);parent.addView(t,lp);t.setOnClickListener(v->{click();action.run();});}
  void showPs2Graphics(){
    android.content.SharedPreferences p=getSharedPreferences("matrix_ps2_graphics",MODE_PRIVATE);LinearLayout box=linear(true);box.setPadding(16,10,16,10);
    box.addView(txt("خيارات الرسوميات التي سيستخدمها المحرك عند دمجه. حالياً تُحفظ كإعدادات فقط ولا تغيّر عرض الألعاب.",11,Color.YELLOW));
    String[] resolutions={"Native / الدقة الأصلية","2x Native","3x Native","4x Native"};Spinner res=new Spinner(this);res.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,resolutions));res.setSelection(p.getInt("resolution",0));box.addView(txt("دقة العرض الداخلية",13,Color.WHITE));box.addView(res);
    String[] ratios={"تلقائي","4:3","16:9","Stretch"};Spinner ratio=new Spinner(this);ratio.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,ratios));ratio.setSelection(p.getInt("ratio",0));box.addView(txt("نسبة الشاشة",13,Color.WHITE));box.addView(ratio);
    Switch vsync=new Switch(this);vsync.setText("V-Sync");vsync.setTextColor(Color.WHITE);vsync.setChecked(p.getBoolean("vsync",true));box.addView(vsync);
    Switch bilinear=new Switch(this);bilinear.setText("ترشيح Bilinear");bilinear.setTextColor(Color.WHITE);bilinear.setChecked(p.getBoolean("bilinear",true));box.addView(bilinear);
    new AlertDialog.Builder(this).setTitle("إعدادات رسوميات PS2").setView(box).setPositiveButton("حفظ",(d,w)->p.edit().putInt("resolution",res.getSelectedItemPosition()).putInt("ratio",ratio.getSelectedItemPosition()).putBoolean("vsync",vsync.isChecked()).putBoolean("bilinear",bilinear.isChecked()).apply()).setNegativeButton("إغلاق",null).show();
  }
  void showMemoryCards(){
    java.io.File dir=new java.io.File(getFilesDir(),"ps2_memory_cards");if(!dir.exists())dir.mkdirs();
    String[] names=dir.list();if(names==null)names=new String[0];final String[] cardNames=names;final String[] opts=new String[cardNames.length+2];opts[0]="＋ إنشاء بطاقة ذاكرة افتراضية (8 MB)";opts[1]="📂 مجلد بطاقات الذاكرة";for(int i=0;i<cardNames.length;i++)opts[i+2]=cardNames[i];
    new AlertDialog.Builder(this).setTitle("بطاقات ذاكرة PS2").setItems(opts,(d,which)->{if(which==0){try{java.io.File f=new java.io.File(dir,"MATRIX_MC_"+System.currentTimeMillis()+".ps2");java.io.RandomAccessFile raf=new java.io.RandomAccessFile(f,"rw");raf.setLength(8L*1024L*1024L);raf.close();dialog("تم إنشاء البطاقة",f.getName()+" • 8 MB\\nملف فارغ للتجهيز؛ ليس تنسيق بطاقة محاكي معتمداً بعد.");}catch(Exception e){dialog("خطأ",String.valueOf(e.getMessage()));}}else if(which==1){dialog("مجلد البطاقات",dir.getAbsolutePath()+"\\nتُحفظ الملفات داخل مساحة التطبيق الخاصة.");}else{java.io.File f=new java.io.File(dir,cardNames[which-2]);dialog("بطاقة الذاكرة",f.getName()+"\\nالحجم: "+(f.length()/1024)+" KB");}}).setNegativeButton("إغلاق",null).show();
  }
  void showGameBooster(){
    ActivityManager am=(ActivityManager)getSystemService(ACTIVITY_SERVICE);ActivityManager.MemoryInfo mi=new ActivityManager.MemoryInfo();am.getMemoryInfo(mi);StatFs fs=new StatFs(android.os.Environment.getDataDirectory().getAbsolutePath());
    String report="RAM الكلية: "+(mi.totalMem/1048576)+" MB\nRAM المتاحة حالياً: "+(mi.availMem/1048576)+" MB\nمساحة التخزين المتاحة: "+(fs.getAvailableBytes()/1048576)+" MB\nمعمارية الهاتف: "+Build.SUPPORTED_ABIS[0]+"\n64-bit: "+android.os.Process.is64Bit()+"\n\nملاحظة: الأداة تعرض معلومات الأداء فقط؛ لا تقتل التطبيقات ولا تدّعي زيادة FPS.";
    new AlertDialog.Builder(this).setTitle("MATRIX Game Booster").setMessage(report).setPositiveButton("تحديث القياس",(d,w)->showGameBooster()).setNegativeButton("إغلاق",null).show();
  }
  void showControllerCenter(){
    int[] ids=android.view.InputDevice.getDeviceIds();ArrayList<String> labels=new ArrayList<>();for(int id:ids){android.view.InputDevice dev=android.view.InputDevice.getDevice(id);if(dev==null)continue;int src=dev.getSources();boolean game=(src&android.view.InputDevice.SOURCE_GAMEPAD)==android.view.InputDevice.SOURCE_GAMEPAD||(src&android.view.InputDevice.SOURCE_JOYSTICK)==android.view.InputDevice.SOURCE_JOYSTICK;labels.add((game?"🎮 ":"• ")+dev.getName()+"\nID: "+id+" • "+(game?"يد تحكم/Joystick":"جهاز إدخال"));}
    String msg=labels.isEmpty()?"لم يتم اكتشاف يد تحكم حالياً. جرّب توصيل يد USB أو Bluetooth ثم افتح المركز مرة ثانية.":android.text.TextUtils.join("\n\n",labels);
    new AlertDialog.Builder(this).setTitle("مركز يد التحكم").setMessage(msg+"\n\nملاحظة: الكشف عن الجهاز لا يعني أن المحاكي مرتبط به بعد.").setPositiveButton("إعادة الفحص",(d,w)->showControllerCenter()).setNegativeButton("إغلاق",null).show();
  }
  void showUpdateCenter(){
    String version="MATRIX GAMING 5.13";new AlertDialog.Builder(this).setTitle("مركز التحديثات").setMessage(version+"\nالقناة: GitHub Actions\n\nافتح صفحة الإصدارات للتحقق من وجود إصدار أحدث. هذا الزر لا يثبت تحديثاً تلقائياً.").setPositiveButton("فتح الإصدارات",(d,w)->{try{Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse("https://github.com/jfarltay/MATRIX-GAMING/releases"));startActivity(i);}catch(Exception e){dialog("تعذر الفتح",String.valueOf(e.getMessage()));}}).setNegativeButton("إغلاق",null).show();
  }
  void showBackupCenter(){new AlertDialog.Builder(this).setTitle("النسخ الاحتياطي والاستعادة").setMessage("صدّر نسخة من إعدادات MATRIX وروابط مكتبات الألعاب، أو استعد نسخة سبق تصديرها. ملفات الألعاب نفسها لا تُنسخ.").setPositiveButton("تصدير نسخة",(d,w)->{Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,"matrix-gaming-backup.json");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,REQ_BACKUP);}).setNeutralButton("استعادة نسخة",(d,w)->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("application/json");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,REQ_RESTORE);}).setNegativeButton("إغلاق",null).show();}
  String buildBackupText(){android.content.SharedPreferences a=getPreferences(0),b=getSharedPreferences("matrix_ps2_library",MODE_PRIVATE),c=getSharedPreferences("matrix_library",MODE_PRIVATE),d=getSharedPreferences("matrix_ps2_pad",MODE_PRIVATE),g=getSharedPreferences("matrix_ps2_graphics",MODE_PRIVATE);return "MATRIX_BACKUP_V1\nMUSIC_ENABLED="+a.getBoolean("music_enabled",true)+"\nMUSIC_VOLUME="+a.getInt("music_volume",65)+"\nDARK_MODE="+a.getBoolean("dark_mode",true)+"\nTHEME="+a.getInt("theme",0)+"\nPS2_GAMES="+b.getString("games","")+"\nPS2_FAVORITES="+b.getString("favorites","")+"\nBIOS_URI="+b.getString("bios_uri","")+"\nGAMES="+c.getString("games","")+"\nFAVORITES="+c.getString("favorites","")+"\nPAD_SIZE="+d.getInt("button_size",48)+"\nPAD_OPACITY="+d.getInt("button_opacity",90)+"\nGFX_RES="+g.getInt("resolution",0)+"\nGFX_RATIO="+g.getInt("ratio",0);}
  void restoreBackupText(String text){if(!text.startsWith("MATRIX_BACKUP_V1")){dialog("ملف غير صالح","هذا الملف ليس نسخة MATRIX معروفة.");return;}String[] lines=text.split("\n");android.content.SharedPreferences.Editor app=getPreferences(0).edit(),e=getSharedPreferences("matrix_ps2_library",MODE_PRIVATE).edit(),lib=getSharedPreferences("matrix_library",MODE_PRIVATE).edit(),pad=getSharedPreferences("matrix_ps2_pad",MODE_PRIVATE).edit(),gfx=getSharedPreferences("matrix_ps2_graphics",MODE_PRIVATE).edit();for(String line:lines){int x=line.indexOf('=');if(x<1)continue;String k=line.substring(0,x),v=line.substring(x+1);if(k.equals("MUSIC_ENABLED"))app.putBoolean("music_enabled",Boolean.parseBoolean(v));else if(k.equals("MUSIC_VOLUME"))try{app.putInt("music_volume",Integer.parseInt(v));}catch(Exception ignored){}else if(k.equals("DARK_MODE"))app.putBoolean("dark_mode",Boolean.parseBoolean(v));else if(k.equals("THEME"))try{app.putInt("theme",Integer.parseInt(v));}catch(Exception ignored){}else if(k.equals("PS2_GAMES"))e.putString("games",v);else if(k.equals("PS2_FAVORITES"))e.putString("favorites",v);else if(k.equals("BIOS_URI")&&!v.isEmpty())e.putString("bios_uri",v);else if(k.equals("GAMES"))lib.putString("games",v);else if(k.equals("FAVORITES"))lib.putString("favorites",v);else if(k.equals("PAD_SIZE"))try{pad.putInt("button_size",Integer.parseInt(v));}catch(Exception ignored){}else if(k.equals("PAD_OPACITY"))try{pad.putInt("button_opacity",Integer.parseInt(v));}catch(Exception ignored){}else if(k.equals("GFX_RES"))try{gfx.putInt("resolution",Integer.parseInt(v));}catch(Exception ignored){}else if(k.equals("GFX_RATIO"))try{gfx.putInt("ratio",Integer.parseInt(v));}catch(Exception ignored){}}app.apply();e.apply();lib.apply();pad.apply();gfx.apply();dialog("تمت الاستعادة","استُعيدت المكتبات وتخصيص الأزرار وإعدادات الرسوميات. قد تحتاج روابط الملفات إلى إعادة منح الإذن.");}
  void showFavorites(){
    String[] uris=savedUris();Set<String> fav=favoriteUris();ArrayList<String> only=new ArrayList<>();for(String u:uris)if(fav.contains(u))only.add(u);
    if(only.isEmpty()){dialog("المفضلة","ماكو ألعاب بالمفضلة. افتح مكتبة الألعاب واضغط إضافة للمفضلة.");return;}
    String[] labels=new String[only.size()];for(int i=0;i<only.size();i++)labels[i]=(i+1)+". "+displayName(Uri.parse(only.get(i)));
    new AlertDialog.Builder(this).setTitle("ألعابك المفضلة").setItems(labels,(d,w)->dialog("ملف محفوظ",displayName(Uri.parse(only.get(w)))+"\nتشغيل اللعبة يحتاج دمج محرك PS2 أولاً.")).setPositiveButton("إغلاق",null).show();
  }
  void showTools(){
    FrameLayout frame=new FrameLayout(this);frame.setBackgroundColor(Color.rgb(2,5,14));
    LinearLayout box=linear(true);box.setPadding(16,14,16,22);ScrollView sc=new ScrollView(this);sc.addView(box);frame.addView(sc);
    LinearLayout head=linear(false);TextView back=txt("‹ رجوع",14,Color.WHITE);back.setPadding(8,10,16,10);back.setOnClickListener(v->render());head.addView(back);head.addView(txt("MATRIX • مركز الأدوات",19,Color.WHITE));box.addView(head);
    TextView intro=txt("إدارة ملفات الألعاب لأجهزة PlayStation 2 و PlayStation 3",11,Color.LTGRAY);intro.setPadding(4,8,4,14);box.addView(intro);
    addToolPanel(box,"🎮","أدوات PS2 USB","استيراد الألعاب وإدارة مكتبة PS2",()->showPs2UsbTools());
    addToolPanel(box,"💿","أدوات PS3 ISO","تقسيم ودمج واستخراج وإنشاء ISO/PKG",()->showPs3IsoTools());
    addToolPanel(box,"🔄","محول الألعاب","اختيار صيغة المصدر والوجهة",()->showGameConverter());
    addToolPanel(box,"🕹","مكتبة ومحاكي PS2","الألعاب والأغلفة والمفضلة وBIOS والتحكم",()->showPs2Library());
    addToolPanel(box,"📱","معلومات الجهاز","Android وABI والذاكرة والتخزين",()->showDeviceReport());
    box.addView(txt("تنبيه: إدارة المكتبة متاحة. التحويلات المتقدمة ومحرك محاكاة PS2 تحتاج دمج محركات متخصصة واختبارها.",10,Color.YELLOW));setContentView(frame);
  }
  void addToolPanel(LinearLayout parent,String icon,String title,String sub,Runnable action){
    LinearLayout card=linear(false);card.setPadding(14,15,14,15);card.setBackground(shape(Color.rgb(8,31,54),Color.rgb(3,10,22),blue));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,6,0,6);parent.addView(card,lp);
    card.addView(txt(icon,25,Color.WHITE));LinearLayout words=linear(true);words.setPadding(13,0,8,0);card.addView(words,new LinearLayout.LayoutParams(0,-2,1));words.addView(txt(title,15,Color.WHITE));words.addView(txt(sub,10,Color.LTGRAY));card.addView(txt("‹",24,blue));card.setOnClickListener(v->{click();action.run();});
  }
  void showDeviceReport(){
    ActivityManager am=(ActivityManager)getSystemService(ACTIVITY_SERVICE);ActivityManager.MemoryInfo mi=new ActivityManager.MemoryInfo();am.getMemoryInfo(mi);StatFs fs=new StatFs(getFilesDir().getAbsolutePath());
    String report="Android: "+Build.VERSION.RELEASE+"\nABI: "+Build.SUPPORTED_ABIS[0]+"\n64-bit: "+android.os.Process.is64Bit()+"\nRAM الكلية: "+(mi.totalMem/1048576)+" MB\nRAM المتاحة: "+(mi.availMem/1048576)+" MB\nمساحة التطبيق المتاحة: "+(fs.getAvailableBytes()/1048576)+" MB";
    new AlertDialog.Builder(this).setTitle("معلومات الجهاز").setMessage(report).setPositiveButton("رجوع",(d,w)->showTools()).show();
  }
  void showPs2UsbTools(){
    String[] items={"استيراد لعبة PS2 إلى المكتبة","عرض ألعاب PS2 المحفوظة","إدارة BIOS","بطاقات الذاكرة","إعدادات الرسوميات","إعدادات يد التحكم","معلومات صيغ PS2"};
    new AlertDialog.Builder(this).setTitle("أدوات PS2 USB").setItems(items,(d,w)->{if(w==0)pickPs2Game();else if(w==1)showPs2Library();else if(w==2)showPs2BiosManager();else if(w==3)showMemoryCards();else if(w==4)showPs2Graphics();else if(w==5)showControllerCenter();else dialog("صيغ PS2","ISO • CHD • CSO • CUE • ELF • ISZ\nهذه قائمة ملفات؛ تشغيلها يتطلب دمج محرك PS2 فعلي.");}).setNegativeButton("رجوع",(d,w)->showTools()).show();
  }
  void showPs3IsoTools(){
    String[] items={"معلومات ملف ISO","اختيار ملف ISO","تقسيم ISO","دمج أجزاء ISO","استخراج ISO","إنشاء ISO من مجلد","تقسيم PKG","دمج أجزاء PKG"};
    new AlertDialog.Builder(this).setTitle("أدوات PS3 ISO / PKG").setItems(items,(d,w)->{if(w==0||w==1){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,REQ_FILE);}else dialog(items[w],"واجهة الأداة ضمن مركز PS3، لكن تنفيذ العملية يحتاج إضافة محرك ملفات PS3 واختباره. لم يتم تعديل ملفاتك أو إنشاء ناتج وهمي.");}).setNegativeButton("رجوع",(d,w)->showTools()).show();
  }
  void showGameConverter(){
    LinearLayout panel=linear(true);panel.setPadding(18,12,18,12);panel.addView(txt("محول صيغ الألعاب",18,Color.WHITE));panel.addView(txt("الصيغ: ISO, BIN/CUE, VCD, ZSO, CSO, CHD, ECM, CCD/IMG, MDS/MDF, NRG, GDI",11,Color.LTGRAY));
    Spinner source=new Spinner(this),target=new Spinner(this);String[] formats={"ISO","BIN/CUE","VCD","ZSO","CSO","CHD","ECM","CCD/IMG","MDS/MDF","NRG","GDI"};ArrayAdapter<String> ad=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,formats);source.setAdapter(ad);target.setAdapter(ad);panel.addView(txt("صيغة المصدر",12,Color.WHITE));panel.addView(source);panel.addView(txt("صيغة الوجهة",12,Color.WHITE));panel.addView(target);
    TextView choose=txt("＋ اختيار ملف المصدر",13,Color.WHITE);choose.setPadding(12,12,12,12);choose.setBackground(shape(Color.rgb(5,65,105),Color.rgb(3,17,34),blue));panel.addView(choose);choose.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,REQ_FILE);});
    panel.addView(txt("ملاحظة: اختيار الصيغ لا يعني أن التحويل مفعّل. يلزم دمج مكتبات التحويل المناسبة قبل تشغيل التحويل الفعلي.",10,Color.YELLOW));new AlertDialog.Builder(this).setTitle("MATRIX Game Converter").setView(panel).setPositiveButton("إغلاق",(d,w)->showTools()).show();
  }
  void dialog(String title,String msg){new AlertDialog.Builder(this).setTitle(title).setMessage(msg).setPositiveButton(s(13),(d,w)->d.dismiss()).show();}
  void chooseLanguage(){String[] opts=new String[codes.length];for(int i=0;i<opts.length;i++)opts[i]=flags[i]+"  "+languageNames[i];new AlertDialog.Builder(this).setTitle(s(10)).setItems(opts,(d,w)->{lang=codes[w];getPreferences(0).edit().putString("lang",lang).apply();render();}).setNegativeButton(s(13),null).show();}
  void test(){ActivityManager am=(ActivityManager)getSystemService(ACTIVITY_SERVICE);ActivityManager.MemoryInfo mi=new ActivityManager.MemoryInfo();am.getMemoryInfo(mi);long total=mi.totalMem/1048576,free=mi.availMem/1048576;String report="Android: "+Build.VERSION.RELEASE+"\nABI: "+Build.SUPPORTED_ABIS[0]+"\n64-bit: "+(android.os.Process.is64Bit()?"Yes":"No")+"\nRAM total: "+total+" MB\nRAM available: "+free+" MB";new AlertDialog.Builder(this).setTitle(s(2)).setMessage(report+"\n\nهذا فحص مواصفات فقط، وليس اختبار تشغيل محاكي.").setPositiveButton(s(14),null).show();}
}
