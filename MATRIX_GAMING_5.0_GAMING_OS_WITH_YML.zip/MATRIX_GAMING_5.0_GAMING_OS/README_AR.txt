MATRIX GAMING 5.0 — GAMING OS
============================

هذه نسخة تأسيسية جديدة بواجهة Android أصلية (Java).
تتضمن:
- خلفية MATRIX GAMING التي تم إنشاؤها في المحادثة ومضمّنة داخل المشروع.
- شاشة رئيسية داكنة بأسلوب Gaming OS.
- أزرار أوضاع LOW / BALANCED / HIGH تتحكم حالياً بمظهر الواجهة فقط.
- بطاقات تنقل أولية للأقسام.

مهم:
هذه ليست نسخة APK جاهزة. هذا مصدر المشروع ويحتاج بناءً باستخدام Android Studio
أو GitHub Actions مع Android SDK وGradle.
الأقسام التي تظهر كبطاقات هي هيكل واجهة أولي وليست وظائف مكتملة بعد.
لا يدّعي هذا الإصدار تحسين أداء الألعاب أو التحكم بمعالج الهاتف.

طريقة البناء:
1) افتح المستودع/المجلد في Android Studio.
2) استخدم JDK 17 و Android SDK Platform 35.
3) نفّذ: gradle assembleDebug
4) ملف APK الناتج: app/build/outputs/apk/debug/app-debug.apk
