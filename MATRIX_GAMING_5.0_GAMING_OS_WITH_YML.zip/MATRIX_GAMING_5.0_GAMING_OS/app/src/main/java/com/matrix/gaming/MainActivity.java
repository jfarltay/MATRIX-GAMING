package com.matrix.gaming;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.graphics.drawable.Drawable;

public class MainActivity extends Activity {
    int cyan = Color.rgb(45, 205, 255), purple = Color.rgb(154, 105, 255);
    LinearLayout root, content;
    TextView low, balanced, high, status;
    String mode = "BALANCED";

    GradientDrawable shape(int color, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(24);
        if (stroke != 0) d.setStroke(2, stroke);
        return d;
    }
    TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size);
        t.setTextColor(color); if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    LinearLayout column() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l;
    }
    LinearLayout row() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL); return l;
    }
    void pad(View v, int a) { v.setPadding(a,a,a,a); }
    TextView tile(String icon, String title, String subtitle) {
        LinearLayout box = column(); box.setPadding(18,18,12,18);
        box.setBackground(shape(Color.argb(225,10,20,39), Color.argb(190,38,170,235)));
        TextView ic = text(icon, 27, cyan, true);
        TextView name = text(title, 14, Color.WHITE, true);
        TextView sub = text(subtitle, 10, Color.LTGRAY, false);
        box.addView(ic); box.addView(name); box.addView(sub);
        TextView wrapper = text("", 1, Color.WHITE, false);
        wrapper.setVisibility(View.GONE);
        box.setOnClickListener(v -> showSection(title));
        box.setLayoutParams(new LinearLayout.LayoutParams(0, 132, 1));
        box.setTag(title);
        // Return a compact container through a TextView-compatible holder is not possible;
        // tiles are added as their own LinearLayouts in addTile().
        return wrapper;
    }
    void addTile(String icon, String title, String subtitle, LinearLayout parent) {
        LinearLayout box = column(); box.setPadding(16,14,8,10);
        box.setBackground(shape(Color.argb(232,8,18,35), Color.argb(190,38,170,235)));
        box.addView(text(icon,26,cyan,true));
        box.addView(text(title,13,Color.WHITE,true));
        box.addView(text(subtitle,10,Color.LTGRAY,false));
        box.setOnClickListener(v -> showSection(title));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0,128,1);
        p.setMargins(5,5,5,5); parent.addView(box,p);
    }
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(4,8,18));
        getWindow().setNavigationBarColor(Color.rgb(4,8,18));
        root = column(); root.setBackgroundColor(Color.rgb(4,8,18));
        ScrollView scroll = new ScrollView(this);
        FrameLayout frame = new FrameLayout(this);
        ImageView bg = new ImageView(this);
        bg.setImageResource(com.matrix.gaming.R.drawable.matrix_wallpaper);
        bg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        frame.addView(bg, new FrameLayout.LayoutParams(-1,-1));
        View shade = new View(this); shade.setBackgroundColor(Color.argb(155,2,7,18));
        frame.addView(shade, new FrameLayout.LayoutParams(-1,-1));
        content = column(); content.setPadding(16,20,16,28);
        frame.addView(content, new FrameLayout.LayoutParams(-1,-2));
        scroll.addView(frame);
        setContentView(scroll);
        buildHome();
    }
    void buildHome() {
        content.removeAllViews();
        LinearLayout top = row();
        TextView logo = text("MATRIX",24,Color.WHITE,true);
        TextView sub = text(" GAMING",17,cyan,true);
        top.addView(logo); top.addView(sub);
        content.addView(top);
        TextView os = text("G A M I N G   O S   //   V 5 . 0",10,cyan,true);
        os.setPadding(2,5,0,16); content.addView(os);
        TextView hero = text("ENTER THE\\nGAMING WORLD",29,Color.WHITE,true);
        hero.setShadowLayer(16,0,0,cyan); content.addView(hero);
        TextView desc = text("YOUR GAMES. YOUR POWER. YOUR MATRIX.",10,Color.LTGRAY,true);
        desc.setPadding(0,8,0,18); content.addView(desc);
        TextView perf = text("PERFORMANCE PROFILE",13,Color.WHITE,true);
        perf.setPadding(2,12,0,8); content.addView(perf);
        LinearLayout modes = row();
        low = modeButton("LOW"); balanced = modeButton("BALANCED"); high = modeButton("HIGH");
        modes.addView(low,new LinearLayout.LayoutParams(0,48,1));
        modes.addView(balanced,new LinearLayout.LayoutParams(0,48,1));
        modes.addView(high,new LinearLayout.LayoutParams(0,48,1));
        content.addView(modes);
        status = text("ACTIVE PROFILE: " + mode,10,cyan,true);
        status.setPadding(2,8,0,14); content.addView(status); updateMode();
        content.addView(text("YOUR COMMAND CENTER",13,Color.WHITE,true));
        addGridRow("▣","GAME CENTER","Your library","◉","PS2 CENTER","Console collection");
        addGridRow("⚡","QUICK BOOST","App-side cleanup","▤","GAME PROFILES","Per-game setup");
        addGridRow("▧","WALLPAPERS","Gaming backgrounds","✦","ICON STUDIO","Personalize UI");
        addGridRow("◈","STATS & TROPHIES","Your activity","⚙","SETTINGS","System options");
        TextView foot = text("MATRIX GAMING 5.0  •  BUILT FOR PLAY",9,Color.LTGRAY,false);
        foot.setGravity(Gravity.CENTER); foot.setPadding(0,24,0,8); content.addView(foot);
    }
    TextView modeButton(String s) {
        TextView t = text(s,11,Color.WHITE,true); t.setGravity(Gravity.CENTER);
        t.setBackground(shape(Color.argb(220,10,20,38),Color.argb(180,60,140,190)));
        t.setOnClickListener(v -> { mode=s; updateMode(); });
        return t;
    }
    void updateMode() {
        if (low==null) return;
        low.setBackground(shape(Color.argb(220,10,20,38),mode.equals("LOW")?cyan:Color.GRAY));
        balanced.setBackground(shape(Color.argb(220,10,20,38),mode.equals("BALANCED")?cyan:Color.GRAY));
        high.setBackground(shape(Color.argb(220,10,20,38),mode.equals("HIGH")?purple:Color.GRAY));
        status.setText("ACTIVE PROFILE: " + mode + "  •  UI EFFECTS");
    }
    void addGridRow(String i1,String t1,String s1,String i2,String t2,String s2) {
        LinearLayout r=row(); r.setPadding(0,5,0,5);
        addTile(i1,t1,s1,r); addTile(i2,t2,s2,r); content.addView(r);
    }
    void showSection(String title) {
        new android.app.AlertDialog.Builder(this).setTitle(title)
            .setMessage("This MATRIX module is part of the 5.0 foundation. Its full functionality will be added and tested in the next development stages.")
            .setPositiveButton("OK", (d,w)->d.dismiss()).show();
    }
}