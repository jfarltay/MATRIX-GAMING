# MATRIX GAMING 2.6

مشروع Android Java بسيط بتقسيم أولي لمكتبة PS2:

- `domain/model`: نموذج بيانات المكتبة.
- `domain/repository`: عقد الوصول إلى المكتبة.
- `domain/usecase`: حالات الاستخدام.
- `data/local`: حفظ الاختيارات محلياً.
- `data/repository`: تنفيذ المستودع.
- `MainActivity`: واجهة التطبيق وأدوات الجهاز.

## البناء

يستخدم المشروع Android Gradle Plugin 8.7.3 و compileSdk 35 و Java 17 و Gradle 8.9. يوجد workflow في `.github/workflows/build-apk.yml` لاكتشاف مجلد المشروع وبناء APK ورفعه كـ artifact.

## حدود الإصدار

إدارة BIOS وملفات الألعاب لا تعني وجود محاكي PS2. لا يتضمن المشروع BIOS أو ألعاباً أو محرك محاكاة. يلزم دمج محرك مرخّص واختباره بشكل منفصل.
