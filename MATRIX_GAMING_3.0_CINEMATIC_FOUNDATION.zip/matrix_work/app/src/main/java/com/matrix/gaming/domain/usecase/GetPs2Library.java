package com.matrix.gaming.domain.usecase;
import com.matrix.gaming.domain.model.Ps2Library;
import com.matrix.gaming.domain.repository.Ps2LibraryRepository;
public final class GetPs2Library {
    private final Ps2LibraryRepository repository;
    public GetPs2Library(Ps2LibraryRepository repository) { this.repository = repository; }
    public Ps2Library execute() { return repository.load(); }
}
