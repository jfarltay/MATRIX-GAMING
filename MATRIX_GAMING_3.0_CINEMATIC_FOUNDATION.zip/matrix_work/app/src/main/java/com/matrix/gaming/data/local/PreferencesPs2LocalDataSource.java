package com.matrix.gaming.data.local;

import android.content.SharedPreferences;
import com.matrix.gaming.domain.model.Ps2Library;

/** Private local persistence for the PS2 library selections. */
public final class PreferencesPs2LocalDataSource {
    private static final String BIOS_KEY = "ps2_bios";
    private static final String GAME_KEY = "ps2_game";
    private final SharedPreferences preferences;

    public PreferencesPs2LocalDataSource(SharedPreferences preferences) {
        if (preferences == null) throw new IllegalArgumentException("preferences == null");
        this.preferences = preferences;
    }

    public Ps2Library load() {
        return new Ps2Library(preferences.getString(BIOS_KEY, ""),
                preferences.getString(GAME_KEY, ""));
    }
    public void saveBios(String uri) { preferences.edit().putString(BIOS_KEY, requireUri(uri)).apply(); }
    public void saveGame(String uri) { preferences.edit().putString(GAME_KEY, requireUri(uri)).apply(); }
    public void clearBios() { preferences.edit().remove(BIOS_KEY).apply(); }
    public void clearGame() { preferences.edit().remove(GAME_KEY).apply(); }
    private String requireUri(String value) {
        if (value == null || value.trim().isEmpty()) throw new IllegalArgumentException("URI is empty");
        return value;
    }
}
