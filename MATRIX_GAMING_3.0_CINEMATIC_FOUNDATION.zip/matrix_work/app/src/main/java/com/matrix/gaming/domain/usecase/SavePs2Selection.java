package com.matrix.gaming.domain.usecase;
import com.matrix.gaming.domain.repository.Ps2LibraryRepository;
public final class SavePs2Selection {
    public enum Type { BIOS, GAME }
    private final Ps2LibraryRepository repository;
    public SavePs2Selection(Ps2LibraryRepository repository) { this.repository = repository; }
    public void execute(Type type, String uri) {
        if (type == null || uri == null || uri.trim().isEmpty()) throw new IllegalArgumentException("Invalid selection");
        if (type == Type.BIOS) repository.saveBios(uri); else repository.saveGame(uri);
    }
}
