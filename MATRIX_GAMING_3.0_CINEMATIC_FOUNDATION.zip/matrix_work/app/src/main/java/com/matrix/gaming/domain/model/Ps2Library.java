package com.matrix.gaming.domain.model;

/** Immutable snapshot of the user's locally selected PS2 files. */
public final class Ps2Library {
    private final String biosUri;
    private final String gameUri;

    public Ps2Library(String biosUri, String gameUri) {
        this.biosUri = biosUri == null ? "" : biosUri;
        this.gameUri = gameUri == null ? "" : gameUri;
    }

    public String getBiosUri() { return biosUri; }
    public String getGameUri() { return gameUri; }
    public boolean hasBios() { return !biosUri.isEmpty(); }
    public boolean hasGame() { return !gameUri.isEmpty(); }
}
