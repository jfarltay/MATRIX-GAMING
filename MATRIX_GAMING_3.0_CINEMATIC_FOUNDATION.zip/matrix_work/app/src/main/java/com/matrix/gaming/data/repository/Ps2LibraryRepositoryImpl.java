package com.matrix.gaming.data.repository;

import com.matrix.gaming.data.local.PreferencesPs2LocalDataSource;
import com.matrix.gaming.domain.model.Ps2Library;
import com.matrix.gaming.domain.repository.Ps2LibraryRepository;

/** Data implementation; replaceable later without changing screens or use cases. */
public final class Ps2LibraryRepositoryImpl implements Ps2LibraryRepository {
    private final PreferencesPs2LocalDataSource local;
    public Ps2LibraryRepositoryImpl(PreferencesPs2LocalDataSource local) {
        if (local == null) throw new IllegalArgumentException("local == null");
        this.local = local;
    }
    @Override public Ps2Library load() { return local.load(); }
    @Override public void saveBios(String uri) { local.saveBios(uri); }
    @Override public void saveGame(String uri) { local.saveGame(uri); }
    @Override public void clearBios() { local.clearBios(); }
    @Override public void clearGame() { local.clearGame(); }
}
