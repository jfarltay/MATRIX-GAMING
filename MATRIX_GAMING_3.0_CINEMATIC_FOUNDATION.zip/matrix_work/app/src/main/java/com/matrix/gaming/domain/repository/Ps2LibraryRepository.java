package com.matrix.gaming.domain.repository;

import com.matrix.gaming.domain.model.Ps2Library;

/** Domain contract. UI must not know how PS2 selections are persisted. */
public interface Ps2LibraryRepository {
    Ps2Library load();
    void saveBios(String uri);
    void saveGame(String uri);
    void clearBios();
    void clearGame();
}
