package com.matrix.gaming;

import android.app.*;
import android.os.*;
import android.content.*;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.database.Cursor;
import android.provider.OpenableColumns;
import java.util.*;

public class MainActivity extends Activity {
    private LinearLayout root, body;
    private final ArrayList<String> games = new ArrayList<>();
    private TextView count;
    private static final int PICK_GAME = 41;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(5,9,20));
        getWindow().setNavigationBarColor(Color.rgb(5,9,20));
        getWindow().getDecorView().setSystemUiVisibility(0);
        showHome();
    }

    private GradientDrawable panel(int color, int stroke) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(16)); d.setStroke(dp(1), stroke); return d;
    }
    private int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+.5f); }
    private TextView text(String s,int size,int color,boolean bold){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); t.setGravity(Gravity.CENTER_VERTICAL); return t; }
    private void base(String title){
        root=new LinearLayout(this); root.setOrientation(1); root.setBackgroundColor(Color.rgb(5,9,20));
        setContentView(root);
        LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL); top.setPadding(dp(18),dp(8),dp(18),dp(8));
        TextView back=text("‹",34,Color.WHITE,true); back.setPadding(0,0,dp(18),0); back.setOnClickListener(v->showHome()); top.addView(back);
        TextView name=text(title,20,Color.WHITE,true); top.addView(name,new LinearLayout.LayoutParams(0,dp(48),1)); root.addView(top);
        ScrollView scroll=new ScrollView(this); body=new LinearLayout(this); body.setOrientation(1); body.setPadding(dp(16),dp(8),dp(16),dp(24)); scroll.addView(body); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
    }
    private void addButton(String title,String sub,Runnable action){
        LinearLayout card=new LinearLayout(this); card.setOrientation(1); card.setPadding(dp(16),dp(13),dp(16),dp(13)); card.setBackground(panel(Color.rgb(13,24,43),Color.rgb(23,128,205)));
        TextView a=text(title,18,Color.WHITE,true); card.addView(a); TextView b=text(sub,13,Color.LTGRAY,false); card.addView(b);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.bottomMargin=dp(10); body.addView(card,lp); card.setOnClickListener(v->action.run());
    }
    private void showHome(){
        base("MATRIX GAMING 5.28");
        ImageView hero=new ImageView(this); hero.setImageResource(com.matrix.gaming.R.drawable.matrix_ps2_reference); hero.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,dp(330)); hp.bottomMargin=dp(14); body.addView(hero,hp);
        TextView heading=text("MATRIX OPL MOBILE",22,Color.WHITE,true); heading.setGravity(Gravity.CENTER); body.addView(heading);
        TextView desc=text("مكتبة ألعاب PS2 وأدوات تنظيم ملفات OPL",14,Color.LTGRAY,false); desc.setGravity(Gravity.CENTER); body.addView(desc);
        addButton("🎮  مكتبة ألعاب PS2","استيراد ملفات ISO وعرض الألعاب",()->showLibrary());
        addButton("💿  MATRIX OPL","فحص ملفات OPL و ul.cfg",()->showOpl());
        addButton("🗂  مدير ملفات USB","اختيار الملفات والمجلدات من الهاتف أو USB",()->pickGame());
        addButton("🧰  أدوات PS2","معلومات ELF والباتشات وملفات الحفظ",()->showTools());
        addButton("⚙  حول التحديث","MATRIX GAMING 5.28 • مرحلة تأسيسية",()->new AlertDialog.Builder(this).setTitle("MATRIX GAMING 5.28").setMessage("هذه أول حزمة تأسيسية للواجهة ومكتبة الملفات. تشغيل ألعاب PS2 يحتاج دمج محاكي حقيقي في مرحلة مستقلة.").setPositiveButton("تمام",null).show());
    }
    private void showLibrary(){ base("مكتبة ألعاب PS2");
        addButton("＋ استيراد لعبة ISO","اختر ملف ISO من ذاكرة الهاتف أو USB",()->pickGame());
        count=text("عدد الألعاب: "+games.size(),16,Color.CYAN,true); body.addView(count);
        renderGames();
    }
    private void renderGames(){ for(String g:games){ addButton("🎮  "+g,"ملف مستورد • لم يتم تشغيله بعد",()->new AlertDialog.Builder(this).setTitle(g).setMessage("تمت إضافة الملف إلى قائمة المكتبة. تشغيل اللعبة يتطلب محاكي PS2 متوافق.").setPositiveButton("حسناً",null).show()); } }
    private void pickGame(){ Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("*/*"); i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i,PICK_GAME); }
    @Override protected void onActivityResult(int req,int res,Intent data){ super.onActivityResult(req,res,data); if(req==PICK_GAME && res==RESULT_OK && data!=null){ Uri u=data.getData(); String n=queryName(u); if(n!=null){ games.add(n); if(root!=null)showLibrary(); Toast.makeText(this,"تمت إضافة الملف للقائمة",Toast.LENGTH_SHORT).show(); } } }
    private String queryName(Uri u){ Cursor c=null; try{ c=getContentResolver().query(u,null,null,null,null); if(c!=null&&c.moveToFirst()){ int x=c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if(x>=0)return c.getString(x); } }catch(Exception ignored){}finally{if(c!=null)c.close();} return u.getLastPathSegment(); }
    private void showOpl(){ base("MATRIX OPL MOBILE");
        addButton("فحص ul.cfg","استيراد ملف إعدادات ألعاب OPL وفحص إمكانية قراءته",()->pickNamed("ul.cfg"));
        addButton("ملفات ألعاب USB","استيراد ملفات الألعاب أو اختيار مجلدها من مدير الملفات",()->pickGame());
        addButton("معلومة مهمة","OPL الأصلي يعمل على جهاز PS2؛ هذه أداة Android لإدارة الملفات وتجهيزها.",()->new AlertDialog.Builder(this).setMessage("لن ندّعي أن الهاتف يشغّل OPL الخاص بالـPS2. تشغيل الألعاب على Android يحتاج محاكي PS2 منفصل.").setPositiveButton("فهمت",null).show());
    }
    private void pickNamed(String label){ Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("*/*"); i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i,PICK_GAME); }
    private void showTools(){ base("أدوات PS2");
        addButton("مدير ملفات الحفظ","مرحلة قادمة: استيراد وتصدير ملفات Memory Card",()->info("مدير الحفظ","سيضاف بعد تنفيذ قارئ صيغ ملفات حفظ PS2 والتحقق منها."));
        addButton("مدير الباتشات","مرحلة قادمة: فحص ملفات patch وربطها بمعرّف اللعبة",()->info("مدير الباتشات","لن يتم تطبيق باتش قبل التأكد من صيغته وتوافقه."));
        addButton("فاحص ELF","مرحلة قادمة: قراءة ترويسة ELF ومعلومات الملف",()->info("فاحص ELF","سيتم تنفيذ فحص حقيقي للملف، وليس زر تشغيل وهمي."));
        addButton("مدير BIOS","استيراد BIOS يدوياً لمحاكي متوافق فقط",()->info("مدير BIOS","لا نوفر BIOS جاهزاً؛ المستخدم يختار نسخته التي يملكها."));
    }
    private void info(String t,String m){new AlertDialog.Builder(this).setTitle(t).setMessage(m).setPositiveButton("حسناً",null).show();}
}
