# MATRIX GAMING 5.28 — المرحلة التأسيسية

- واجهة Android أصلية Java، package: `com.matrix.gaming`.
- صورة PS2 المعتمدة مضمنة كما وصلت، دون تعديل: `app/src/main/res/drawable-nodpi/matrix_ps2_reference.png`.
- استيراد ملفات عبر Android Storage Access Framework.
- قائمة محلية مؤقتة للألعاب المستوردة أثناء جلسة التطبيق.
- صفحات MATRIX OPL وأدوات PS2 توضح الوظائف التي ستنفذ في المراحل التالية.

## حدود هذه الحزمة
هذه ليست نسخة نهائية ولا تحتوي محاكي PS2 بعد. OPL الأصلي برنامج يعمل على PS2، أما هذا التطبيق فهو مدير Android لملفات ومكتبة OPL. يلزم دمج محاكي PS2 حقيقي قبل ادعاء تشغيل الألعاب.

## البناء
Android Gradle Plugin 8.7.3، Gradle 8.9، JDK 17، compileSdk 35.

`gradle clean :app:assembleDebug`
