MATRIX GAMING 2.5 - Android source project

Package: com.matrix.gaming
Version: 2.5 (versionCode 5)
Minimum Android: 6.0 (API 23)
Compile SDK: 35
Java: 17

Build:
- Upload the contents of this project to the root of your GitHub repository.
- Run Actions > MATRIX GAMING 2.5 - Build APK.
- Download the MATRIX-GAMING-2.5-APK artifact after a successful run.

PS2 library status:
This source currently provides manual BIOS/game file selection and local URI persistence.
It does NOT contain or integrate a functioning PS2 emulation core. Import your own legally
obtained BIOS and game images; none are included in this archive.

Build status:
The workflow is configured to build the Android debug APK on GitHub Actions. This archive
has not been verified by a successful remote GitHub Actions run or on-device installation.
