package com.matrix.gaming;

import android.app.*;
import android.os.*;
import android.app.ActivityManager;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.view.animation.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
  int blue=Color.rgb(0,155,255), red=Color.rgb(255,45,75); LinearLayout page; String lang="ar";
  String[] codes={"ar","en","fr","es","de","it","pt","ru","tr","zh","ja","ko","hi","id","ms","th","vi","nl","pl","uk","fa","ur","bn","sw"};
  String[] flags={"🇮🇶","🇬🇧","🇫🇷","🇪🇸","🇩🇪","🇮🇹","🇵🇹","🇷🇺","🇹🇷","🇨🇳","🇯🇵","🇰🇷","🇮🇳","🇮🇩","🇲🇾","🇹🇭","🇻🇳","🇳🇱","🇵🇱","🇺🇦","🇮🇷","🇵🇰","🇧🇩","🇰🇪"};
  String[] languageNames={"العربية","English","Français","Español","Deutsch","Italiano","Português","Русский","Türkçe","中文","日本語","한국어","हिन्दी","Bahasa Indonesia","Bahasa Melayu","ไทย","Tiếng Việt","Nederlands","Polski","Українська","فارسی","اردو","বাংলা","Kiswahili"};
  HashMap<String,String[]> tr=new HashMap<>();
  void initTranslations(){
    tr.put("ar",new String[]{"الرئيسية","مركز PS2","اختبار التوافق","مكتبة الألعاب","المفضلة","مركز الصور","مركز الفيديو","الأدوات المتقدمة","إدارة الملفات","الإعدادات","اختر اللغة","عالم MATRIX بين يديك","اختبار مواصفات الهاتف","رجوع","إغلاق","اللغة"});
    tr.put("en",new String[]{"HOME","PS2 CENTER","COMPATIBILITY TEST","GAME LIBRARY","FAVORITES","PHOTO CENTER","VIDEO CENTER","ADVANCED TOOLS","FILE MANAGER","SETTINGS","Choose language","Your MATRIX world","Device capability test","Back","Close","Language"});
    tr.put("fr",new String[]{"ACCUEIL","CENTRE PS2","TEST COMPATIBILITÉ","BIBLIOTHÈQUE","FAVORIS","PHOTOS","VIDÉOS","OUTILS AVANCÉS","FICHIERS","PARAMÈTRES","Choisir la langue","Votre univers MATRIX","Test de l’appareil","Retour","Fermer","Langue"});
    tr.put("es",new String[]{"INICIO","CENTRO PS2","PRUEBA COMPATIBILIDAD","BIBLIOTECA","FAVORITOS","FOTOS","VÍDEOS","HERRAMIENTAS","ARCHIVOS","AJUSTES","Elegir idioma","Tu mundo MATRIX","Prueba del dispositivo","Volver","Cerrar","Idioma"});
    tr.put("de",new String[]{"START","PS2-ZENTRUM","KOMPATIBILITÄTSTEST","SPIELBIBLIOTHEK","FAVORITEN","FOTOS","VIDEOS","WERKZEUGE","DATEIEN","EINSTELLUNGEN","Sprache wählen","Deine MATRIX-Welt","Gerätetest","Zurück","Schließen","Sprache"});
    tr.put("it",new String[]{"HOME","CENTRO PS2","TEST COMPATIBILITÀ","LIBRERIA","PREFERITI","FOTO","VIDEO","STRUMENTI","FILE","IMPOSTAZIONI","Scegli lingua","Il tuo mondo MATRIX","Test dispositivo","Indietro","Chiudi","Lingua"});
    tr.put("pt",new String[]{"INÍCIO","CENTRO PS2","TESTE DE COMPATIBILIDADE","BIBLIOTECA","FAVORITOS","FOTOS","VÍDEOS","FERRAMENTAS","ARQUIVOS","DEFINIÇÕES","Escolher idioma","O teu mundo MATRIX","Teste do dispositivo","Voltar","Fechar","Idioma"});
    tr.put("ru",new String[]{"ГЛАВНАЯ","ЦЕНТР PS2","ТЕСТ СОВМЕСТИМОСТИ","БИБЛИОТЕКА","ИЗБРАННОЕ","ФОТО","ВИДЕО","ИНСТРУМЕНТЫ","ФАЙЛЫ","НАСТРОЙКИ","Выбрать язык","Твой мир MATRIX","Тест устройства","Назад","Закрыть","Язык"});
    tr.put("tr",new String[]{"ANA SAYFA","PS2 MERKEZİ","UYUMLULUK TESTİ","OYUN KÜTÜPHANESİ","FAVORİLER","FOTOĞRAFLAR","VİDEOLAR","ARAÇLAR","DOSYALAR","AYARLAR","Dil seç","MATRIX dünyan","Cihaz testi","Geri","Kapat","Dil"});
    tr.put("zh",new String[]{"主页","PS2中心","兼容性测试","游戏库","收藏","照片中心","视频中心","高级工具","文件管理","设置","选择语言","你的 MATRIX 世界","设备测试","返回","关闭","语言"});
    tr.put("ja",new String[]{"ホーム","PS2センター","互換性テスト","ゲームライブラリ","お気に入り","写真","ビデオ","ツール","ファイル","設定","言語を選択","MATRIXの世界","端末テスト","戻る","閉じる","言語"});
    tr.put("ko",new String[]{"홈","PS2 센터","호환성 테스트","게임 라이브러리","즐겨찾기","사진","동영상","고급 도구","파일 관리자","설정","언어 선택","MATRIX 세계","기기 테스트","뒤로","닫기","언어"});
    tr.put("hi",new String[]{"होम","PS2 केंद्र","अनुकूलता परीक्षण","गेम लाइब्रेरी","पसंदीदा","फ़ोटो","वीडियो","उन्नत टूल","फ़ाइल प्रबंधक","सेटिंग्स","भाषा चुनें","आपकी MATRIX दुनिया","डिवाइस परीक्षण","वापस","बंद करें","भाषा"});
    tr.put("id",new String[]{"BERANDA","PUSAT PS2","UJI KOMPATIBILITAS","PUSTAKA GAME","FAVORIT","FOTO","VIDEO","ALAT LANJUTAN","PENGELOLA FILE","PENGATURAN","Pilih bahasa","Dunia MATRIX Anda","Tes perangkat","Kembali","Tutup","Bahasa"});
    tr.put("ms",new String[]{"LAMAN UTAMA","PUSAT PS2","UJIAN KESESUAIAN","PERPUSTAKAAN","KEGEMARAN","FOTO","VIDEO","ALAT LANJUTAN","PENGURUS FAIL","TETAPAN","Pilih bahasa","Dunia MATRIX anda","Ujian peranti","Kembali","Tutup","Bahasa"});
    tr.put("th",new String[]{"หน้าหลัก","ศูนย์ PS2","ทดสอบความเข้ากันได้","คลังเกม","รายการโปรด","รูปภาพ","วิดีโอ","เครื่องมือขั้นสูง","จัดการไฟล์","การตั้งค่า","เลือกภาษา","โลก MATRIX ของคุณ","ทดสอบอุปกรณ์","กลับ","ปิด","ภาษา"});
    tr.put("vi",new String[]{"TRANG CHỦ","TRUNG TÂM PS2","KIỂM TRA TƯƠNG THÍCH","THƯ VIỆN","YÊU THÍCH","ẢNH","VIDEO","CÔNG CỤ","QUẢN LÝ TỆP","CÀI ĐẶT","Chọn ngôn ngữ","Thế giới MATRIX","Kiểm tra thiết bị","Quay lại","Đóng","Ngôn ngữ"});
    tr.put("nl",new String[]{"START","PS2-CENTRUM","COMPATIBILITEITSTEST","BIBLIOTHEEK","FAVORIETEN","FOTO'S","VIDEO'S","HULPMIDDELEN","BESTANDEN","INSTELLINGEN","Kies taal","Jouw MATRIX-wereld","Apparaattest","Terug","Sluiten","Taal"});
    tr.put("pl",new String[]{"START","CENTRUM PS2","TEST ZGODNOŚCI","BIBLIOTEKA","ULUBIONE","ZDJĘCIA","WIDEO","NARZĘDZIA","PLIKI","USTAWIENIA","Wybierz język","Twój świat MATRIX","Test urządzenia","Wstecz","Zamknij","Język"});
    tr.put("uk",new String[]{"ГОЛОВНА","ЦЕНТР PS2","ТЕСТ СУМІСНОСТІ","БІБЛІОТЕКА","ОБРАНЕ","ФОТО","ВІДЕО","ІНСТРУМЕНТИ","ФАЙЛИ","НАЛАШТУВАННЯ","Оберіть мову","Твій світ MATRIX","Тест пристрою","Назад","Закрити","Мова"});
    tr.put("fa",new String[]{"خانه","مرکز PS2","آزمایش سازگاری","کتابخانه بازی","علاقه‌مندی‌ها","عکس‌ها","ویدیوها","ابزار پیشرفته","مدیریت فایل","تنظیمات","انتخاب زبان","دنیای MATRIX شما","آزمایش دستگاه","بازگشت","بستن","زبان"});
    tr.put("ur",new String[]{"ہوم","PS2 مرکز","مطابقت ٹیسٹ","گیم لائبریری","پسندیدہ","تصاویر","ویڈیوز","ایڈوانس ٹولز","فائل مینیجر","ترتیبات","زبان منتخب کریں","آپ کی MATRIX دنیا","ڈیوائس ٹیسٹ","واپس","بند کریں","زبان"});
    tr.put("bn",new String[]{"হোম","PS2 কেন্দ্র","সামঞ্জস্য পরীক্ষা","গেম লাইব্রেরি","প্রিয়","ছবি","ভিডিও","উন্নত সরঞ্জাম","ফাইল ম্যানেজার","সেটিংস","ভাষা নির্বাচন","আপনার MATRIX জগৎ","ডিভাইস পরীক্ষা","ফিরে যান","বন্ধ","ভাষা"});
    tr.put("sw",new String[]{"NYUMBANI","KITUO CHA PS2","JARIBIO LA UWEZO","MAKTABA YA MICHEZO","VIPENDWA","PICHA","VIDEO","ZANA ZA JUU","FAILI","MIPANGILIO","Chagua lugha","Ulimwengu wako wa MATRIX","Jaribio la kifaa","Rudi","Funga","Lugha"});
  }
  String s(int i){String[] a=tr.get(lang); if(a==null)a=tr.get("en"); return a[i];}
  GradientDrawable shape(int a,int b,int stroke){GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{a,b});d.setCornerRadius(25);d.setStroke(2,stroke);return d;}
  TextView txt(String v,int z,int c){TextView t=new TextView(this);t.setText(v);t.setTextColor(c);t.setTextSize(z);t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
  LinearLayout linear(boolean vertical){LinearLayout l=new LinearLayout(this);l.setOrientation(vertical?1:0);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
  @Override public void onCreate(Bundle b){super.onCreate(b);initTranslations();lang=getPreferences(0).getString("lang","ar");getWindow().setStatusBarColor(Color.rgb(2,5,15));getWindow().setNavigationBarColor(Color.rgb(2,5,15));render();}
  void render(){
    FrameLayout root=new FrameLayout(this);ImageView bg=new ImageView(this);bg.setImageResource(R.drawable.matrix_wallpaper);bg.setScaleType(ImageView.ScaleType.CENTER_CROP);root.addView(bg,new FrameLayout.LayoutParams(-1,-1));
    View dim=new View(this);dim.setBackgroundColor(Color.argb(168,0,3,13));root.addView(dim,new FrameLayout.LayoutParams(-1,-1));
    ScrollView sc=new ScrollView(this);sc.setFillViewport(true);LinearLayout content=linear(true);content.setPadding(16,18,16,24);sc.addView(content);root.addView(sc);setContentView(root);page=content;
    LinearLayout top=linear(false);TextView brand=txt("♛ MATRIX",27,Color.WHITE);brand.setShadowLayer(18,0,0,blue);top.addView(brand,new LinearLayout.LayoutParams(0,-2,1));TextView langBtn=txt("🌐  "+flags[indexOf(lang)]+"  "+s(15)+"  ▾",13,Color.WHITE);langBtn.setPadding(13,12,13,12);langBtn.setBackground(shape(Color.rgb(5,34,65),Color.rgb(10,12,30),blue));langBtn.setOnClickListener(v->chooseLanguage());top.addView(langBtn);page.addView(top);
    TextView sub=txt("G A M I N G   O S   •   5.1",11,Color.LTGRAY);sub.setPadding(4,5,0,4);page.addView(sub);
    TextView hero=txt(s(11),24,Color.WHITE);hero.setGravity(Gravity.CENTER);hero.setShadowLayer(22,0,0,blue);hero.setPadding(4,24,4,7);page.addView(hero);
    TextView desc=txt("GHOST  •  PLAYSTATION 2  •  MATRIX",10,Color.LTGRAY);desc.setGravity(Gravity.CENTER);desc.setPadding(0,0,0,18);page.addView(desc);
    addSection(s(1)); addFeature("Ⅱ","PS2",s(1),blue,()->dialog(s(1),"مركز PS2 — نواة المحاكي تحتاج إلى دمج مستقل قبل تشغيل الألعاب."));
    addFeature("◈","CPU / RAM",s(2),red,()->test());
    addSection("MATRIX HUB");
    LinearLayout r1=linear(false);page.addView(r1);feature(r1,"▣",s(3),blue);feature(r1,"★",s(4),red);
    LinearLayout r2=linear(false);page.addView(r2);feature(r2,"▧",s(5),red);feature(r2,"▶",s(6),blue);
    LinearLayout r3=linear(false);page.addView(r3);feature(r3,"⚙",s(7),blue);feature(r3,"☷",s(8),red);
    addSection(s(9));addFeature("🌐",s(15),"24 LANGUAGES",blue,()->chooseLanguage());
    TextView foot=txt("MATRIX GAMING 5.1   •   BUILT FOR GAMERS",9,Color.LTGRAY);foot.setGravity(Gravity.CENTER);foot.setPadding(0,22,0,0);page.addView(foot);
  }
  int indexOf(String c){for(int i=0;i<codes.length;i++)if(codes[i].equals(c))return i;return 1;}
  void addSection(String t){TextView x=txt(t,15,Color.WHITE);x.setPadding(4,18,4,9);page.addView(x);}
  void addFeature(String icon,String title,String sub,int color,Runnable run){LinearLayout holder=linear(true);holder.setPadding(18,15,18,15);holder.setBackground(shape(Color.argb(235,7,27,52),Color.argb(245,3,7,18),color));holder.setElevation(14);TextView i=txt(icon,28,color);holder.addView(i);TextView h=txt(title,15,Color.WHITE);h.setPadding(0,5,0,2);holder.addView(h);TextView d=txt(sub,10,Color.LTGRAY);holder.addView(d);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(2,6,2,7);page.addView(holder,p);animate(holder,run);}
  void feature(LinearLayout row,String icon,String title,int color){LinearLayout h=linear(true);h.setGravity(Gravity.CENTER);h.setPadding(8,16,8,16);h.setBackground(shape(Color.rgb(9,29,54),Color.rgb(3,8,20),color));h.setElevation(12);h.addView(txt(icon,27,color));TextView t=txt(title,11,Color.WHITE);t.setGravity(Gravity.CENTER);t.setPadding(0,7,0,0);h.addView(t);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,112,1);p.setMargins(5,5,5,5);row.addView(h,p);animate(h,()->dialog(title,title+" — سيتم تطوير هذه الميزة ضمن التحديثات القادمة."));}
  void animate(View v,Runnable r){v.setOnTouchListener((view,event)->{if(event.getAction()==0){view.animate().scaleX(.96f).scaleY(.96f).setDuration(90).start();}else if(event.getAction()==1){view.animate().scaleX(1f).scaleY(1f).setDuration(150).start();r.run();}else if(event.getAction()==3){view.animate().scaleX(1f).scaleY(1f).setDuration(150).start();}return true;});}
  void dialog(String title,String msg){new AlertDialog.Builder(this).setTitle(title).setMessage(msg).setPositiveButton(s(13),(d,w)->d.dismiss()).show();}
  void chooseLanguage(){String[] opts=new String[codes.length];for(int i=0;i<opts.length;i++)opts[i]=flags[i]+"  "+languageNames[i];new AlertDialog.Builder(this).setTitle(s(10)).setItems(opts,(d,w)->{lang=codes[w];getPreferences(0).edit().putString("lang",lang).apply();render();}).setNegativeButton(s(13),null).show();}
  void test(){ActivityManager am=(ActivityManager)getSystemService(ACTIVITY_SERVICE);ActivityManager.MemoryInfo mi=new ActivityManager.MemoryInfo();am.getMemoryInfo(mi);long total=mi.totalMem/1048576,free=mi.availMem/1048576;String report="Android: "+Build.VERSION.RELEASE+"\nABI: "+Build.SUPPORTED_ABIS[0]+"\n64-bit: "+(android.os.Process.is64Bit()?"Yes":"No")+"\nRAM total: "+total+" MB\nRAM available: "+free+" MB";new AlertDialog.Builder(this).setTitle(s(2)).setMessage(report+"\n\nهذا فحص مواصفات فقط، وليس اختبار تشغيل محاكي.").setPositiveButton(s(14),null).show();}
}
