package com.matrix.gaming;

import android.app.*;
import android.media.*;
import android.media.ImageReader;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.provider.MediaStore;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.view.Surface;
import android.os.Environment;
import android.content.ContentValues;
import android.provider.MediaStore;
import android.app.ActivityManager;
import android.content.*;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.text.DecimalFormat;
import java.util.*;

public class MainActivity extends Activity {
    final int BG=0xFF050907, PANEL=0xFF0D1711, GREEN=0xFF39F58A, MUTED=0xFFB7C8BD;
    LinearLayout root, body, bar;
    DecimalFormat df=new DecimalFormat("0.0");
    SharedPreferences prefs;
    com.matrix.gaming.domain.repository.Ps2LibraryRepository ps2Repository;
    static final int PICK_FILE=41;
    static final int CAPTURE_REQUEST=42;
    static final int PICK_BIOS=43;
    static final int PICK_PS2_GAME=44;
    MediaProjectionManager projectionManager;
    MediaProjection projection;
    VirtualDisplay virtualDisplay;
    MediaRecorder recorder;
    boolean recording=false;
    boolean takingScreenshot=false;
    ImageReader imageReader;
    Handler captureHandler=new Handler();
    String videoPath="";
    int chosenFps=30;
    int chosenLongEdge=1080;
    TextView status;
    Handler handler=new Handler();
    Runnable refreshTask;
    @Override public void onCreate(Bundle b){super.onCreate(b); prefs=getSharedPreferences("matrix",0);
        ps2Repository=new com.matrix.gaming.data.repository.Ps2LibraryRepositoryImpl(
            new com.matrix.gaming.data.local.PreferencesPs2LocalDataSource(prefs));
        getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);home();}
    TextView text(String s,int z,int c){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);t.setPadding(0,5,0,5);return t;}
    GradientDrawable bg(int color,int stroke){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(22);d.setStroke(2,stroke);return d;}
    LinearLayout panel(){LinearLayout p=new LinearLayout(this);p.setOrientation(1);p.setPadding(16,13,16,13);p.setBackground(bg(PANEL,0xFF1B7043));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,7,0,7);p.setLayoutParams(lp);return p;}
    void setup(String title){
        root=new LinearLayout(this);root.setOrientation(1);root.setPadding(16,12,16,10);root.setBackgroundColor(BG);
        LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);
        TextView back=text("‹",34,GREEN);back.setPadding(8,0,18,0);back.setOnClickListener(v->home());head.addView(back);
        TextView name=text("MATRIX  /  "+title,17,GREEN);name.setTypeface(null,Typeface.BOLD);head.addView(name);root.addView(head);
        ScrollView sc=new ScrollView(this);body=new LinearLayout(this);body.setOrientation(1);sc.addView(body);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        TextView foot=text("MATRIX GAMING  •  ANDROID STANDARD PERMISSIONS",10,0xFF71877B);root.addView(foot);setContentView(root);
    }
    void home(){
        setup("MATRIX GAMING");
        root.setPadding(10,8,10,8);
        LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
        TextView settings=text("⚙",27,GREEN); settings.setGravity(Gravity.CENTER); settings.setBackground(bg(0xFF07150D,GREEN));
        LinearLayout.LayoutParams gearLp=new LinearLayout.LayoutParams(dp(52),dp(48)); gearLp.setMargins(0,0,8,0); top.addView(settings,gearLp);
        TextView brand=text("MATRIX GAMING",19,GREEN); brand.setTypeface(null,Typeface.BOLD); top.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
        TextView pro=text("♛  PRO",17,0xFFFFD84A); pro.setGravity(Gravity.CENTER); pro.setPadding(15,8,15,8); pro.setBackground(bg(0xFF10140C,0xFF8B7624)); top.addView(pro);
        settings.setOnClickListener(v->control()); pro.setOnClickListener(v->about()); body.addView(top);

        ImageView hero=new ImageView(this); hero.setImageResource(com.matrix.gaming.R.drawable.matrix_hero); hero.setScaleType(ImageView.ScaleType.CENTER_CROP);
        LinearLayout.LayoutParams heroLp=new LinearLayout.LayoutParams(-1,dp(205)); heroLp.setMargins(0,dp(5),0,dp(8)); hero.setBackground(bg(BG,GREEN)); hero.setClipToOutline(true); body.addView(hero,heroLp);

        LinearLayout stats=new LinearLayout(this); stats.setOrientation(LinearLayout.HORIZONTAL); stats.setBackground(bg(0xFF07130C,0xFF1DBB61)); stats.setPadding(4,7,4,7);
        stats.addView(metric("CPU",""+Runtime.getRuntime().availableProcessors()+" cores"),new LinearLayout.LayoutParams(0,-2,1));
        stats.addView(metric("RAM",ram()),new LinearLayout.LayoutParams(0,-2,1));
        stats.addView(metric("البطارية",battery()),new LinearLayout.LayoutParams(0,-2,1));
        stats.addView(metric("الحرارة",batteryTemp()),new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout.LayoutParams statsLp=new LinearLayout.LayoutParams(-1,-2); statsLp.setMargins(0,0,0,dp(8)); body.addView(stats,statsLp);

        addHomeRow("🎮","MATRIX GAMING","مكتبة الألعاب وتشغيلها",()->games(),"🚀","MATRIX BOOST","تحسين ومراقبة الأداء",()->boost());
        addHomeRow("📁","MATRIX STORAGE","إدارة الملفات والتخزين",()->storage(),"☷","MATRIX CONTROL","اختصارات وإعدادات سريعة",()->control());
        addHomeRow("🛡","MATRIX SECURITY","أمان وحماية التطبيقات",()->security(),"🧰","MATRIX GAME TOOLS","أدوات مساعدة للألعاب",()->tools());
        addHomeRow("⏺","MATRIX SCREEN STUDIO","تسجيل الشاشة والتقاط الصور",()->screenStudio(),"⌕","MATRIX DIAGNOSTICS","فحص الجهاز وتشخيصه",()->diagnostics());
        addCard("MATRIX PS2","اختيار BIOS وإضافة ألعاب PS2 الخاصة بك",()->ps2Library());
        LinearLayout about=panel(); about.setOrientation(LinearLayout.HORIZONTAL); about.setGravity(Gravity.CENTER_VERTICAL); TextView info=text("ⓘ",34,GREEN); about.addView(info); LinearLayout aboutText=new LinearLayout(this); aboutText.setOrientation(1); aboutText.setPadding(12,0,0,0); aboutText.addView(text("ABOUT MATRIX",18,-1)); aboutText.addView(text("معلومات التطبيق والإعدادات",12,MUTED)); about.addView(aboutText,new LinearLayout.LayoutParams(0,-2,1)); TextView crown=text("♛",34,GREEN); about.addView(crown); about.setOnClickListener(v->about()); body.addView(about);
        TextView footer=text("M A T R I X   G A M I N G   •   G A M E   O N",12,GREEN); footer.setGravity(Gravity.CENTER); footer.setPadding(0,dp(12),0,dp(8)); body.addView(footer);
    }
    int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    void addHomeRow(String i1,String t1,String d1,Runnable r1,String i2,String t2,String d2,Runnable r2){
        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        row.addView(homeTile(i1,t1,d1,r1),new LinearLayout.LayoutParams(0,dp(92),1));
        View gap=new View(this); row.addView(gap,new LinearLayout.LayoutParams(dp(8),1));
        row.addView(homeTile(i2,t2,d2,r2),new LinearLayout.LayoutParams(0,dp(92),1));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,dp(2),0,dp(2)); body.addView(row,lp);
    }
    View homeTile(String icon,String title,String desc,Runnable action){
        LinearLayout tile=new LinearLayout(this); tile.setGravity(Gravity.CENTER_VERTICAL); tile.setPadding(9,8,7,8); tile.setBackground(bg(0xFF07120B,0xFF20C968));
        TextView ic=text(icon,27,GREEN); ic.setGravity(Gravity.CENTER); tile.addView(ic,new LinearLayout.LayoutParams(dp(43),-2));
        LinearLayout labels=new LinearLayout(this); labels.setOrientation(1); labels.setPadding(5,0,0,0); TextView a=text(title,12,-1); a.setTypeface(null,Typeface.BOLD); a.setMaxLines(2); TextView b=text(desc,10,MUTED); b.setMaxLines(2); labels.addView(a); labels.addView(b); tile.addView(labels,new LinearLayout.LayoutParams(0,-2,1));
        TextView arrow=text("›",25,GREEN); tile.addView(arrow); tile.setOnClickListener(v->action.run()); return tile;
    }
    View metric(String a,String b){LinearLayout p=new LinearLayout(this);p.setOrientation(1);p.setGravity(Gravity.CENTER);p.setPadding(3,7,3,7);TextView x=text(a,10,GREEN);x.setGravity(Gravity.CENTER);TextView y=text(b,11,-1);y.setGravity(Gravity.CENTER);y.setMaxLines(2);p.addView(x);p.addView(y);return p;}
    void addCard(String a,String b,Runnable r){LinearLayout p=panel();p.addView(text(a,17,GREEN));TextView d=text(b,13,MUTED);p.addView(d);p.setOnClickListener(v->r.run());body.addView(p);}
    void button(String label,Runnable r){Button b=new Button(this);b.setText(label);b.setTextColor(GREEN);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF14251B));b.setOnClickListener(v->r.run());body.addView(b,new LinearLayout.LayoutParams(-1,-2));}
    String ram(){ActivityManager am=(ActivityManager)getSystemService(ACTIVITY_SERVICE);ActivityManager.MemoryInfo m=new ActivityManager.MemoryInfo();am.getMemoryInfo(m);return df.format((m.totalMem-m.availMem)/1073741824.0)+" / "+df.format(m.totalMem/1073741824.0)+" GB";}
    String battery(){Intent i=registerReceiver(null,new IntentFilter(Intent.ACTION_BATTERY_CHANGED));if(i==null)return "N/A";int l=i.getIntExtra("level",-1),s=i.getIntExtra("scale",100);return (l*100/Math.max(s,1))+"%";}
    String batteryTemp(){Intent i=registerReceiver(null,new IntentFilter(Intent.ACTION_BATTERY_CHANGED));if(i==null)return "N/A";int t=i.getIntExtra("temperature",-1);return t<0?"N/A":df.format(t/10.0)+" °C";}
    void boost(){setup("BOOST");body.addView(text("LIVE DEVICE MONITOR",20,GREEN));TextView values=text("",17,-1);body.addView(panel());LinearLayout p=panel();p.addView(values);body.addView(p);Runnable r=new Runnable(){public void run(){values.setText("CPU CORES: "+Runtime.getRuntime().availableProcessors()+"\nRAM USED / TOTAL: "+ram()+"\nBATTERY: "+battery()+"\nBATTERY TEMPERATURE: "+batteryTemp()+"\n\nتتحدث القراءات كل ثانيتين أثناء فتح هذه الصفحة.");handler.postDelayed(this,2000);}};r.run();refreshTask=r;button("إيقاف التحديث والعودة",()->{handler.removeCallbacks(r);home();});}
    void games(){setup("GAMES");body.addView(text("INSTALLED LAUNCHABLE APPS",19,GREEN));Intent q=new Intent(Intent.ACTION_MAIN,null);q.addCategory(Intent.CATEGORY_LAUNCHER);List<android.content.pm.ResolveInfo> apps=getPackageManager().queryIntentActivities(q,0);Collections.sort(apps,(a,b)->String.valueOf(a.loadLabel(getPackageManager())).compareToIgnoreCase(String.valueOf(b.loadLabel(getPackageManager()))));body.addView(text("عدد التطبيقات القابلة للتشغيل: "+apps.size(),13,MUTED));for(android.content.pm.ResolveInfo ri:apps){String label=String.valueOf(ri.loadLabel(getPackageManager()));String pkg=ri.activityInfo.packageName;LinearLayout p=panel();p.addView(text(label,16,GREEN));p.addView(text(pkg,10,MUTED));p.setOnClickListener(v->{Intent launch=getPackageManager().getLaunchIntentForPackage(pkg);if(launch!=null)startActivity(launch);});body.addView(p);}}
    void storage(){setup("STORAGE");body.addView(text("FILE ACCESS",20,GREEN));body.addView(text("اختَر ملفاً من خلال منتقي أندرويد الرسمي. التطبيق لا يقرأ ملفاتك إلا التي تختارها.",14,MUTED));button("اختيار ملف",()->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,PICK_FILE);});button("فتح مدير الملفات",()->{try{Intent i=new Intent(Intent.ACTION_GET_CONTENT);i.setType("*/*");startActivity(Intent.createChooser(i,"اختيار ملف"));}catch(Exception e){msg("تنبيه","مدير الملفات غير متاح.");}});}
    @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);
        if(req==PICK_FILE&&res==RESULT_OK&&data!=null){Uri u=data.getData();msg("تم اختيار الملف",u==null?"":u.toString());}
        if((req==PICK_BIOS||req==PICK_PS2_GAME)&&res==RESULT_OK&&data!=null&&data.getData()!=null){
            Uri u=data.getData();
            try{getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}
            if(req==PICK_BIOS) ps2Repository.saveBios(u.toString());
            else ps2Repository.saveGame(u.toString());
            String label=req==PICK_BIOS?"تم اختيار ملف BIOS":"تمت إضافة ملف اللعبة";
            msg(label,"تم حفظ مسار الملف داخل MATRIX GAMING. هذه مرحلة إدارة الملفات؛ تشغيل الألعاب يحتاج دمج نواة محاكي PS2 واختبارها.");
            ps2Library();
        }
        if(req==CAPTURE_REQUEST&&res==RESULT_OK&&data!=null){if(takingScreenshot)startScreenshotCapture(res,data);else startCapture(res,data);}
    }

    void ps2Library(){
        setup("PS2 LIBRARY");
        body.addView(text("MATRIX PS2",23,GREEN));
        body.addView(text("إدارة ملفاتك الشخصية لمحاكي PS2",14,MUTED));
        com.matrix.gaming.domain.model.Ps2Library library=ps2Repository.load();
        String bios=library.getBiosUri();
        String game=library.getGameUri();
        LinearLayout bp=panel();bp.addView(text("BIOS STATUS",12,GREEN));bp.addView(text(bios.isEmpty()?"لم يتم اختيار BIOS بعد":"تم اختيار BIOS ✓",15,-1));body.addView(bp);
        LinearLayout gp=panel();gp.addView(text("GAME LIBRARY",12,GREEN));gp.addView(text(game.isEmpty()?"لم تتم إضافة لعبة بعد":"تمت إضافة ملف لعبة ✓",15,-1));body.addView(gp);
        button("اختيار BIOS من الهاتف",()->pickPs2File(PICK_BIOS,"application/octet-stream"));
        button("إضافة لعبة PS2 (ISO)",()->pickPs2File(PICK_PS2_GAME,"*/*"));
        button("مسح اختيار BIOS",()->{ps2Repository.clearBios();ps2Library();});
        button("مسح اللعبة المختارة",()->{ps2Repository.clearGame();ps2Library();});
        body.addView(text("تنبيه: اختيار BIOS وISO لا يشغّل اللعبة وحده. نواة محاكي PS2 الحقيقية لم تُدمج بعد، ولن ندّعي أن هذه الشاشة محاكي يعمل. استخدم BIOS ونسخ الألعاب التي تملكها قانونياً.",13,MUTED));
    }
    void pickPs2File(int request,String type){
        try{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType(type);i.addCategory(Intent.CATEGORY_OPENABLE);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);startActivityForResult(i,request);}
        catch(Exception e){msg("خطأ","تعذر فتح منتقي الملفات.");}
    }

    void screenStudio(){
        setup("SCREEN STUDIO");
        body.addView(text("SCREEN RECORDING",21,GREEN));
        body.addView(text("سجّل شاشة الهاتف بصيغة MP4 أو التقط صورة PNG. سيطلب أندرويد موافقتك قبل كل جلسة تسجيل.",14,MUTED));
        button("إعدادات جودة الفيديو",()->qualityDialog());
        button("بدء تسجيل الشاشة",()->requestCapture());
        button("التقاط صورة للشاشة",()->requestScreenshot());
        body.addView(text("التسجيل فيديو صامت MP4، والصورة PNG. الملفات تُحفظ في معرض الهاتف داخل مجلد MATRIX GAMING. الدقة و60 FPS تعتمد على قدرات الجهاز.",12,MUTED));
    }
    void qualityDialog(){
        String[] opts={"تلقائي (دقة الشاشة)","720p","1080p","1440p","30 FPS","60 FPS"};
        new AlertDialog.Builder(this).setTitle("جودة التسجيل").setItems(opts,(d,w)->{
            if(w==0)chosenLongEdge=0; else if(w==1)chosenLongEdge=720; else if(w==2)chosenLongEdge=1080; else if(w==3)chosenLongEdge=1440; else if(w==4)chosenFps=30; else chosenFps=60;
            msg("تم اختيار الإعداد","الدقة والإطارات الفعلية تعتمد على شاشة الهاتف وقدراته.");
        }).show();
    }
    void requestCapture(){
        try{projectionManager=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);startActivityForResult(projectionManager.createScreenCaptureIntent(),CAPTURE_REQUEST);}
        catch(Exception e){msg("تعذر بدء الالتقاط","ميزة تسجيل الشاشة غير متاحة على هذا الجهاز.");}
    }

    void requestScreenshot(){
        try{
            takingScreenshot=true;
            projectionManager=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
            startActivityForResult(projectionManager.createScreenCaptureIntent(),CAPTURE_REQUEST);
        }catch(Exception e){takingScreenshot=false;msg("تعذر التقاط الصورة","ميزة التقاط الشاشة غير متاحة حالياً.");}
    }
    void startScreenshotCapture(int resultCode,Intent data){
        try{
            projection=projectionManager.getMediaProjection(resultCode,data);
            if(projection==null)throw new Exception("projection");
            android.util.DisplayMetrics dm=new android.util.DisplayMetrics();
            getWindowManager().getDefaultDisplay().getRealMetrics(dm);
            final int w=dm.widthPixels, h=dm.heightPixels;
            imageReader=ImageReader.newInstance(w,h,PixelFormat.RGBA_8888,2);
            virtualDisplay=projection.createVirtualDisplay("MATRIX_SCREENSHOT",w,h,dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,imageReader.getSurface(),null,captureHandler);
            imageReader.setOnImageAvailableListener(reader->{
                Image image=null;
                try{
                    image=reader.acquireLatestImage();
                    if(image==null)return;
                    Image.Plane plane=image.getPlanes()[0];
                    java.nio.ByteBuffer buffer=plane.getBuffer();
                    int pixelStride=plane.getPixelStride();
                    int rowStride=plane.getRowStride();
                    int rowPadding=rowStride-pixelStride*w;
                    Bitmap padded=Bitmap.createBitmap(w+rowPadding/pixelStride,h,Bitmap.Config.ARGB_8888);
                    padded.copyPixelsFromBuffer(buffer);
                    Bitmap bitmap=Bitmap.createBitmap(padded,0,0,w,h);
                    padded.recycle();
                    String saved=saveBitmapToGallery(bitmap);
                    bitmap.recycle();
                    runOnUiThread(()->msg("تم التقاط الصورة",saved));
                }catch(Exception e){runOnUiThread(()->msg("فشل الالتقاط","تعذر حفظ صورة الشاشة. جرّب مرة ثانية."));}
                finally{
                    if(image!=null)image.close();
                    releaseCapture();
                    takingScreenshot=false;
                }
            },captureHandler);
            captureHandler.postDelayed(()->{
                if(takingScreenshot && imageReader!=null){
                    // The listener receives the first available frame; this timeout only prevents a stuck session.
                }
            },2500);
        }catch(Exception e){
            takingScreenshot=false;releaseCapture();
            msg("خطأ","تعذر التقاط صورة الشاشة. جرّب مرة ثانية.");
        }
    }
    String saveBitmapToGallery(Bitmap bitmap) throws Exception{
        String name="MATRIX_"+System.currentTimeMillis()+".png";
        ContentValues values=new ContentValues();
        values.put(MediaStore.Images.Media.DISPLAY_NAME,name);
        values.put(MediaStore.Images.Media.MIME_TYPE,"image/png");
        if(Build.VERSION.SDK_INT>=29)values.put(MediaStore.Images.Media.RELATIVE_PATH,Environment.DIRECTORY_PICTURES+"/MATRIX GAMING");
        Uri uri=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values);
        if(uri==null)throw new Exception("media insert");
        try(OutputStream out=getContentResolver().openOutputStream(uri)){
            if(out==null)throw new Exception("output");
            bitmap.compress(Bitmap.CompressFormat.PNG,100,out);
        }catch(Exception e){getContentResolver().delete(uri,null,null);throw e;}
        return "حُفظت الصورة في Pictures/MATRIX GAMING/"+name;
    }
    String publishVideoToGallery(String path) throws Exception{
        if(Build.VERSION.SDK_INT<29)return "حُفظ الفيديو داخل ملفات التطبيق: "+path;
        String name=new File(path).getName();
        ContentValues values=new ContentValues();
        values.put(MediaStore.Video.Media.DISPLAY_NAME,name);
        values.put(MediaStore.Video.Media.MIME_TYPE,"video/mp4");
        values.put(MediaStore.Video.Media.RELATIVE_PATH,Environment.DIRECTORY_MOVIES+"/MATRIX GAMING");
        Uri uri=getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI,values);
        if(uri==null)throw new Exception("media insert");
        try(InputStream in=new FileInputStream(path);OutputStream out=getContentResolver().openOutputStream(uri)){
            if(out==null)throw new Exception("output");
            byte[] buf=new byte[65536];int n;
            while((n=in.read(buf))>0)out.write(buf,0,n);
        }catch(Exception e){getContentResolver().delete(uri,null,null);throw e;}
        return "حُفظ الفيديو في Movies/MATRIX GAMING/"+name;
    }

    void startCapture(int resultCode,Intent data){
        try{
            projection=projectionManager.getMediaProjection(resultCode,data);
            if(projection==null)throw new Exception("projection");
            if(recording){stopCapture();return;}
            startVideoCapture();
        }catch(Exception e){releaseCapture();msg("خطأ","تعذر بدء تسجيل الشاشة. جرّب دقة أقل وأغلق التطبيقات الثقيلة.");}
    }
    void startVideoCapture() throws Exception {
        android.util.DisplayMetrics dm=new android.util.DisplayMetrics();getWindowManager().getDefaultDisplay().getRealMetrics(dm);
        int w=dm.widthPixels,h=dm.heightPixels;
        int max=Math.max(w,h);
        if(chosenLongEdge>0 && max>chosenLongEdge){float scale=(float)chosenLongEdge/max;w=((int)(w*scale))&~1;h=((int)(h*scale))&~1;}
        w=Math.max(2,w&~1);h=Math.max(2,h&~1);
        File dir=new File(getExternalFilesDir(Environment.DIRECTORY_MOVIES),"MATRIX");if(!dir.exists())dir.mkdirs();
        videoPath=new File(dir,"MATRIX_"+System.currentTimeMillis()+".mp4").getAbsolutePath();
        recorder=new MediaRecorder();
        recorder.setVideoSource(MediaRecorder.VideoSource.SURFACE);
        recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
        recorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264);
        recorder.setVideoSize(w,h);
        recorder.setVideoFrameRate(chosenFps);
        recorder.setVideoEncodingBitRate(Math.max(2000000,w*h*(chosenFps==60?8:5)));
        recorder.setOutputFile(videoPath);
        recorder.prepare();
        Surface surface=recorder.getSurface();
        virtualDisplay=projection.createVirtualDisplay("MATRIX_SCREEN",w,h,dm.densityDpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,surface,null,null);
        recorder.start();recording=true;
        new AlertDialog.Builder(this).setTitle("التسجيل يعمل").setMessage("جاري تسجيل الشاشة. اضغط إيقاف عند الانتهاء.").setPositiveButton("إيقاف التسجيل",(d,x)->stopCapture()).setCancelable(false).show();
    }
    void stopCapture(){
        try{if(recorder!=null){recorder.stop();}String location=publishVideoToGallery(videoPath);msg("تم حفظ الفيديو",location);}
        catch(Exception e){msg("فشل التسجيل","قد تكون مدة التسجيل قصيرة جداً أو تعذر حفظ الفيديو.");}
        releaseCapture();
    }
    void releaseCapture(){
        recording=false;
        try{if(virtualDisplay!=null)virtualDisplay.release();}catch(Exception e){}
        try{if(imageReader!=null){imageReader.close();}}catch(Exception e){}
        imageReader=null;
        try{if(recorder!=null){recorder.reset();recorder.release();}}catch(Exception e){}
        try{if(projection!=null)projection.stop();}catch(Exception e){}
        virtualDisplay=null;recorder=null;projection=null;
    }
    void control(){setup("CONTROL");body.addView(text("SYSTEM SHORTCUTS",20,GREEN));item("إعدادات الشاشة",Settings.ACTION_DISPLAY_SETTINGS);item("الصوت",Settings.ACTION_SOUND_SETTINGS);item("الشبكة والاتصال",Settings.ACTION_WIRELESS_SETTINGS);item("البطارية",Intent.ACTION_POWER_USAGE_SUMMARY);item("إعدادات التطبيقات",Settings.ACTION_APPLICATION_SETTINGS);item("معلومات الجهاز",Settings.ACTION_DEVICE_INFO_SETTINGS);}
    void item(String label,String action){button(label,()->open(action));}
    void security(){setup("SECURITY");body.addView(text("APP SETTINGS",20,GREEN));Intent q=new Intent(Intent.ACTION_MAIN,null);q.addCategory(Intent.CATEGORY_LAUNCHER);List<android.content.pm.ResolveInfo> apps=getPackageManager().queryIntentActivities(q,0);for(android.content.pm.ResolveInfo ri:apps){String label=String.valueOf(ri.loadLabel(getPackageManager()));String pkg=ri.activityInfo.packageName;button(label+"  •  الأذونات والتفاصيل",()->{Intent i=new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+pkg));openIntent(i);});}}
    void tools(){setup("GAME TOOLS");body.addView(text("PLAY SESSION TIMER",20,GREEN));Chronometer c=new Chronometer(this);c.setTextColor(-1);c.setTextSize(28);body.addView(c);button("بدء المؤقت",()->{c.setBase(android.os.SystemClock.elapsedRealtime());c.start();});button("إيقاف المؤقت",c::stop);body.addView(text("LOCAL GAME NOTES",20,GREEN));EditText e=new EditText(this);e.setTextColor(-1);e.setHintTextColor(MUTED);e.setHint("اكتب ملاحظاتك عن اللعبة...");e.setMinLines(4);e.setGravity(Gravity.TOP);e.setText(prefs.getString("notes",""));e.setBackground(bg(PANEL,0xFF1B7043));body.addView(e);button("حفظ الملاحظات",()->{prefs.edit().putString("notes",e.getText().toString()).apply();msg("MATRIX","تم حفظ الملاحظات على الهاتف.");});}
    void diagnostics(){setup("DIAGNOSTICS");body.addView(text("DEVICE REPORT",20,GREEN));String report="الشركة: "+Build.MANUFACTURER+"\nالجهاز: "+Build.MODEL+"\nAndroid: "+Build.VERSION.RELEASE+"\nAPI: "+Build.VERSION.SDK_INT+"\nCPU cores: "+Runtime.getRuntime().availableProcessors()+"\nRAM: "+ram()+"\nBattery: "+battery()+"\nBattery temp: "+batteryTemp()+"\nApp data used: "+df.format((getFilesDir().getTotalSpace()-getFilesDir().getFreeSpace())/1048576.0)+" MB";body.addView(text(report,15,-1));button("مشاركة تقرير الجهاز",()->{Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,report);startActivity(Intent.createChooser(i,"مشاركة التقرير"));});}
    void about(){setup("ABOUT");body.addView(text("MATRIX GAMING 2.3",23,GREEN));body.addView(text("يعمل بدون روت وبصلاحيات أندرويد العادية.\n\nيستطيع عرض التطبيقات القابلة للتشغيل، مراقبة معلومات الذاكرة والبطارية، فتح إعدادات النظام، اختيار الملفات، حفظ الملاحظات وتشغيل مؤقت.\n\nلا يستطيع التطبيق العادي ضمان زيادة FPS أو تغيير تردد المعالج أو تبريد الهاتف أو التحكم بأذونات التطبيقات نيابةً عنك. كما أن صفحة PS2 الحالية تحفظ اختيارات BIOS وISO فقط، وليست نواة محاكاة بعد.",15,MUTED));}
    void open(String a){try{startActivity(new Intent(a));}catch(Exception e){msg("تنبيه","هذه الصفحة غير متاحة على إصدار أندرويد الحالي.");}}
    void openIntent(Intent i){try{startActivity(i);}catch(Exception e){msg("تنبيه","تعذر فتح إعدادات التطبيق.");}}
    void msg(String a,String b){new AlertDialog.Builder(this).setTitle(a).setMessage(b).setPositiveButton("إغلاق",null).show();}
    @Override protected void onDestroy(){if(recording)stopCapture();else if(projection!=null)releaseCapture();super.onDestroy();}
    @Override protected void onPause(){super.onPause();if(refreshTask!=null)handler.removeCallbacks(refreshTask);}
    @Override protected void onResume(){super.onResume();if(refreshTask!=null)handler.post(refreshTask);}
}
