# MATRIX GAMING 5.34 — PS2 core integration stage 1

## What is included in this stage
- A reproducible GitHub Actions job that fetches the official ARMSX2 source repository, including its Git submodules, and stores an immutable source snapshot as a workflow artifact.
- A source audit step that verifies the upstream CMake root, Android platform tree, GPL-3.0 license, and submodule metadata are present.
- The existing MATRIX Android app remains separate and buildable; its current `matrix_ps2_bridge` is only a JNI status bridge and is NOT an emulator core.

## What is not included yet
- ARMSX2 is not linked into MATRIX's APK in this stage.
- No PS2 BIOS or commercial game data is bundled. The user must supply a BIOS dumped from a PS2 console they own and their own game dumps.
- No claim is made that PS2 games launch from MATRIX until the core is linked, an Android rendering/input/audio host is implemented, and device testing succeeds.

## Why this staged approach
ARMSX2 is a large PCSX2-derived C++ project with submodules and its own Android build system. Copying a few C++ files or adding a JNI method would not create a working emulator. First pin and archive a complete source snapshot; next inspect its Android Gradle/NDK integration and license obligations; then adapt its Android host/core into MATRIX.

## Upstream
- https://github.com/ARMSX2/ARMSX2
- License: GPL-3.0 (review all third-party licenses before redistribution).
