package com.matrix.gaming.engines;

import java.util.*;

/** Central inventory. Status values deliberately distinguish working code from planned integrations. */
public final class EngineCatalog {
    private EngineCatalog() {}
    public enum Status { IMPLEMENTED, PARTIAL, INTEGRATION_REQUIRED, NOT_IMPLEMENTED }
    public static final class Entry {
        public final String id, title, detail; public final Status status;
        Entry(String i, String t, Status s, String d) { id=i; title=t; status=s; detail=d; }
    }
    public static List<Entry> all() {
        List<Entry> e = new ArrayList<>();
        e.add(new Entry("iso", "ISO File Engine", Status.IMPLEMENTED, "Split, merge, ISO9660 inspection and CRC32"));
        e.add(new Entry("sha256", "SHA-256 Engine", Status.IMPLEMENTED, "Streaming SHA-256 checksums"));
        e.add(new Entry("zip", "ZIP Engine", Status.IMPLEMENTED, "Streaming ZIP create/extract with path traversal protection"));
        e.add(new Entry("opl-folders", "OPL Folder Export", Status.PARTIAL, "ISO copy to CD/DVD folders exists; device testing remains"));
        e.add(new Entry("opl-ul", "OPL USBExtreme UL", Status.INTEGRATION_REQUIRED, "UL segments and ul.cfg writer/reader still required"));
        e.add(new Entry("ps2", "MATRIX PS2 ENGINE", Status.INTEGRATION_REQUIRED, "Integrate Play! ARM64 core; JNI bridge alone is not an emulator"));
        e.add(new Entry("chd-cso-zso", "CHD/CSO/ZSO codecs", Status.INTEGRATION_REQUIRED, "Use compatible codec libraries; extension renaming is not conversion"));
        e.add(new Entry("ps3-pkg", "PS3 PKG Engine", Status.NOT_IMPLEMENTED, "Dedicated PKG parser/extractor and validation required"));
        e.add(new Entry("bin-cue", "BIN/CUE Engine", Status.NOT_IMPLEMENTED, "Disc layout parser and tested conversion path required"));
        e.add(new Entry("ecm", "ECM Engine", Status.NOT_IMPLEMENTED, "ECM codec integration required"));
        return Collections.unmodifiableList(e);
    }
}
