package com.matrix.gaming;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.os.Environment;
import android.os.StatFs;
import android.app.ActivityManager;
import java.util.Locale;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    private final int blue=Color.rgb(0,155,255), red=Color.rgb(255,48,74);
    private LinearLayout page;
    private TextView selected;
    private GradientDrawable panel(int stroke) {
        GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,
            new int[]{Color.rgb(8,18,38),Color.rgb(3,7,17)});
        d.setCornerRadius(26); d.setStroke(2,stroke); return d;
    }
    private TextView label(String s,int size,int color,boolean bold) {
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return t;
    }
    private LinearLayout row(){ LinearLayout l=new LinearLayout(this); l.setOrientation(0); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    private LinearLayout col(){ LinearLayout l=new LinearLayout(this); l.setOrientation(1); return l; }
    private void gap(LinearLayout p,int h){ View v=new View(this); p.addView(v,new LinearLayout.LayoutParams(1,h)); }
    private void card(String icon,String title,String sub,int color,Runnable action){
        LinearLayout c=col(); c.setPadding(15,13,10,13); c.setBackground(panel(color));
        c.addView(label(icon,25,color,true)); c.addView(label(title,14,Color.WHITE,true));
        c.addView(label(sub,10,Color.LTGRAY,false));
        c.setOnClickListener(v->action.run());
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,112,1); lp.setMargins(4,4,4,4); page.addView(c,lp);
    }
    private void section(String title){
        TextView t=label(title,16,Color.WHITE,true); t.setPadding(4,18,0,8); page.addView(t);
    }
    private void open(String name,String detail){
        new android.app.AlertDialog.Builder(this).setTitle(name).setMessage(detail)
          .setPositiveButton("رجوع",(d,w)->d.dismiss()).show();
    }
    @Override public void onCreate(Bundle b){ super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(3,7,17)); getWindow().setNavigationBarColor(Color.rgb(3,7,17));
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true);
        FrameLayout frame=new FrameLayout(this);
        ImageView bg=new ImageView(this); bg.setImageResource(R.drawable.matrix_wallpaper); bg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        frame.addView(bg,new FrameLayout.LayoutParams(-1,-1));
        View shade=new View(this); shade.setBackgroundColor(Color.argb(175,1,5,15)); frame.addView(shade,new FrameLayout.LayoutParams(-1,-1));
        page=col(); page.setPadding(13,18,13,22); frame.addView(page,new FrameLayout.LayoutParams(-1,-2));
        scroll.addView(frame); setContentView(scroll); build();
    }
    private void build(){
        LinearLayout head=row();
        TextView brand=label("♛  MATRIX",25,Color.WHITE,true); head.addView(brand);
        TextView version=label(" GAMING 5.0",15,blue,true); head.addView(version);
        page.addView(head); page.addView(label("PLAY MORE  •  ENJOY MORE",10,Color.LTGRAY,true));
        TextView hero=label("LEGENDS NEVER DIE",25,Color.WHITE,true); hero.setShadowLayer(18,0,0,blue); hero.setPadding(0,22,0,5); page.addView(hero);
        page.addView(label("عالم ألعابك… كله بمكان واحد",13,Color.LTGRAY,false));
        section("مراكز الألعاب");
        LinearLayout r1=row(); page.addView(r1); addCardTo(r1,"Ⅱ","PS2 CENTER","مركز ألعاب بلايستيشن 2",blue,"مركز PS2 هو الجهاز المدعوم حالياً داخل MATRIX. نواة تشغيل الألعاب ما زالت قيد التطوير.");
        addCardTo(r1,"✓","EMULATOR TEST","اختبار توافق الهاتف",red,"افحص مواصفات هاتفك الأولية قبل تجربة محاكي PS2.");
        LinearLayout r2=row(); page.addView(r2); addCardTo(r2,"▣","GAME LIBRARY","مكتبة الألعاب",blue,"مكتبة ألعابك وتصنيفاتها وأغلفتها."); addCardTo(r2,"★","FAVORITES","الألعاب المفضلة",red,"قائمة الألعاب المفضلة.");
        LinearLayout testRow=row(); page.addView(testRow); addCardTo(testRow,"⌁","PS2 COMPATIBILITY TEST","اختبار المحاكي والهاتف",red,"اختبار أولي لمواصفات الهاتف.");
        testRow.getChildAt(0).setOnClickListener(v->runEmulatorTest());
        section("مركز الوسائط والأدوات");
        LinearLayout r3=row(); page.addView(r3); addCardTo(r3,"▧","PHOTO CENTER","الصور والخلفيات",blue,"مركز الصور والخلفيات الفنية."); addCardTo(r3,"▶","VIDEO CENTER","الفيديوهات",red,"تنظيم فيديوهات الألعاب.");
        LinearLayout r4=row(); page.addView(r4); addCardTo(r4,"⚙","ADVANCED TOOLS","الأدوات المتقدمة",blue,"أدوات وإعدادات التطبيق."); addCardTo(r4,"⇩","DOWNLOADS","التحميلات",red,"متابعة الملفات التي تحفظها داخل التطبيق.");
        LinearLayout r5=row(); page.addView(r5); addCardTo(r5,"✦","ICON STUDIO","الأيقونات والثيمات",blue,"تخصيص مظهر التطبيق."); addCardTo(r5,"☰","FILE MANAGER","إدارة الملفات",red,"عرض ملفاتك وتنظيمها.");
        section("عالم الألعاب");
        HorizontalScrollView hs=new HorizontalScrollView(this); hs.setHorizontalScrollBarEnabled(false); LinearLayout games=row();
        String[][] items={{"GOD OF WAR","أكشن ومغامرة"},{"RED DEAD","عالم مفتوح"},{"CALL OF DUTY","تصويب"},{"UNCHARTED","مغامرات"},{"THE LAST OF US","قصة"},{"RESIDENT EVIL","رعب"}};
        for(String[] it:items){ TextView t=label(it[0]+"\n"+it[1],13,Color.WHITE,true); t.setGravity(Gravity.CENTER); t.setPadding(18,18,18,18); t.setBackground(panel(blue)); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(150,90); p.setMargins(4,4,4,4); games.addView(t,p); t.setOnClickListener(v->open(it[0],"معلومات اللعبة ستضاف ضمن مكتبة MATRIX.")); }
        hs.addView(games); page.addView(hs);
        section("التنقل السريع");
        LinearLayout nav=row(); nav.setBackground(panel(red)); nav.setPadding(8,12,8,12);
        String[] tabs={"الرئيسية","المكتبة","المفضلة","التحديثات","الملف الشخصي"};
        for(String tab:tabs){ TextView t=label(tab,10,Color.WHITE,true); t.setGravity(Gravity.CENTER); nav.addView(t,new LinearLayout.LayoutParams(0,42,1)); t.setOnClickListener(v->{ if(selected!=null)selected.setTextColor(Color.WHITE); selected=t; t.setTextColor(blue); open(tab,"قسم "+tab+" قيد التجهيز.");}); }
        page.addView(nav); TextView foot=label("MATRIX GAMING 5.0  •  BUILT FOR GAMERS",9,Color.LTGRAY,true); foot.setGravity(Gravity.CENTER); foot.setPadding(0,20,0,0); page.addView(foot);
    }
    private void runEmulatorTest(){
        StringBuilder report=new StringBuilder();
        report.append("نتيجة اختبار MATRIX PS2\n\n");
        report.append("إصدار أندرويد: ").append(Build.VERSION.RELEASE).append("\n");
        report.append("المعمارية: ");
        String[] abis=Build.SUPPORTED_ABIS;
        report.append(abis.length>0?abis[0]:"غير معروف").append("\n");
        ActivityManager am=(ActivityManager)getSystemService(ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi=new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        long totalRam=mi.totalMem/(1024L*1024L);
        long freeRam=mi.availMem/(1024L*1024L);
        report.append("RAM الكلية: ").append(totalRam).append(" MB\n");
        report.append("RAM المتاحة حالياً: ").append(freeRam).append(" MB\n");
        StatFs stat=new StatFs(Environment.getDataDirectory().getPath());
        long freeStorage=(stat.getAvailableBytes()/(1024L*1024L));
        report.append("المساحة الداخلية المتاحة: ").append(freeStorage).append(" MB\n\n");
        boolean is64=android.os.Process.is64Bit();
        report.append("دعم 64-bit: ").append(is64?"نعم":"لا").append("\n");
        report.append("\nالتقييم: ");
        if(is64 && totalRam>=3000 && freeStorage>=2000){
            report.append("مواصفات أولية مناسبة للتجربة، لكن هذا لا يضمن تشغيل كل ألعاب PS2.");
        } else {
            report.append("قد تحتاج إلى تخفيف الإعدادات أو توفير مساحة وذاكرة قبل التجربة.");
        }
        report.append("\n\nملاحظة: هذا فحص لمواصفات الهاتف فقط، وليس اختباراً لتشغيل لعبة؛ نواة المحاكي لم تُدمج بعد.");
        new android.app.AlertDialog.Builder(this).setTitle("اختبار محاكي PS2").setMessage(report.toString())
            .setPositiveButton("إعادة الاختبار",(d,w)->runEmulatorTest())
            .setNegativeButton("إغلاق",(d,w)->d.dismiss()).show();
    }
    private void addCardTo(LinearLayout parent,String icon,String title,String sub,int color,String msg){
        LinearLayout c=col(); c.setPadding(13,12,8,12); c.setBackground(panel(color)); c.addView(label(icon,24,color,true)); c.addView(label(title,13,Color.WHITE,true)); c.addView(label(sub,9,Color.LTGRAY,false));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,108,1); p.setMargins(4,4,4,4); parent.addView(c,p); c.setOnClickListener(v->open(title,msg));
    }
}
